"""Preview the actual exported V6 cameras at 16:9 on the unchanged actor."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import sys

import bpy
from mathutils import Quaternion, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from anim_codec import read, sample, sample_track

arguments = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('stem', choices=['bs01', 'bs02'])
parser.add_argument('--side', choices=['pc', 'em'], default='pc')
parser.add_argument('--keyposes', action='store_true')
args = parser.parse_args(arguments)
source = ROOT/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
scene = bpy.context.scene
arm = bpy.data.objects['chr424857']
arm.animation_data.action = bpy.data.actions['chr424857_'+args.stem]
for track in arm.animation_data.nla_tracks:
    track.mute = True
camera_path = ROOT/f'modified_v6/dsts-loader/patch/cam_chr424857_{args.stem}_{args.side}.anim'
clip = read(camera_path, expected_bones=2)
cam = scene.camera
cam.data.type = 'PERSP'
cam.data.sensor_fit = 'HORIZONTAL'
cam.rotation_mode = 'QUATERNION'
conversion = Quaternion((1., 0., 0.), math.pi/2)
scene.render.resolution_x = 768
scene.render.resolution_y = 432
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
if args.keyposes:
    out = ROOT/'work/v6/keyposes'
    frames = [119, 110, 100, 90, 0, 18, 44, 50, 59] if args.stem == 'bs01' else [0, 24, 33, 39, 42, 46, 51, 74]
else:
    out = ROOT/f'work/v6/sequence/{args.stem}_{args.side}'
    frames = list(range(0, clip._source_frame_count, 2))
    if frames[-1] != clip._source_frame_count-1:
        frames.append(clip._source_frame_count-1)
out.mkdir(parents=True, exist_ok=True)
for index, frame in enumerate(frames):
    scene.frame_set(frame+1)
    position, rotation, _ = sample(clip, 0, frame)
    cam.location = Vector((position[0], -position[2], position[1]))
    cam.rotation_quaternion = conversion @ Quaternion((rotation[3], *rotation[:3]))
    cam.data.angle = math.radians(float(sample_track(clip.float_channels[0], frame)))
    name = f'{args.stem}_{args.side}_{frame:03d}.png' if args.keyposes else f'{index:03d}.png'
    scene.render.filepath = str(out/name)
    bpy.ops.render.render(write_still=True)
if not args.keyposes:
    (out/'frames.json').write_text(json.dumps({
        'stem': args.stem, 'side': args.side, 'frames': frames, 'fps': clip.playback_rate,
        'aspect_ratio': 16/9, 'source_scene_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'actor_sha256': hashlib.sha256((ROOT/f'modified_v6/dsts-loader/patch/chr424857_{args.stem}.anim').read_bytes()).hexdigest(),
        'camera_sha256': hashlib.sha256(camera_path.read_bytes()).hexdigest(),
        'note': 'Actual exported camera; V4 native particles are not rendered in Blender.'
    }, indent=2)+'\n')
print('V6 actual camera rendered:', args.stem, args.side, len(frames), 'frames')
