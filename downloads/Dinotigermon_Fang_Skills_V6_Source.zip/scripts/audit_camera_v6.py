"""Read-only Blender audit of V6 face shots and the Ground Fang jaw ending.

Only actual evaluated mesh geometry and exported perspective cameras are used.
The face and jaw phases have separate selections and framing requirements.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Quaternion
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from anim_codec import read, sample, sample_track
from geom_preview import read_geom


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def window(value):
    pieces = value.split(':')
    if len(pieces) != 2:
        raise argparse.ArgumentTypeError('Use an inclusive first:last frame range')
    first, last = map(int, pieces)
    if first < 0 or last < first:
        raise argparse.ArgumentTypeError('Invalid frame range')
    return first, last


def world_vertices(obj, indices, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    coords = np.empty(len(evaluated.data.vertices)*3, dtype=np.float64)
    evaluated.data.vertices.foreach_get('co', coords)
    coords = coords.reshape(-1, 3)[indices]
    transform = np.asarray(evaluated.matrix_world, dtype=np.float64)
    return coords @ transform[:3, :3].T + transform[:3, 3]


def select_meshes(snapshot, geom):
    selected, details = [], []
    for record in snapshot['meshes']:
        obj = bpy.data.objects[record['name']]
        if obj.type != 'MESH':
            raise ValueError(f'Not a mesh: {record["name"]}')
        if len(record['vertex_indices']) != len(record['positions_game']):
            raise ValueError('Selection positions and original vertex indices disagree')
        # GEOM material buffers share unused vertices. The importer omits
        # unreferenced entries; they are not rendered by the game either.
        used = set(geom.meshes[record['index']].index_buffer)
        rendered_positions = [position for index, position in
                              zip(record['vertex_indices'], record['positions_game']) if index in used]
        wanted = {tuple(round(float(v), 5) for v in position)
                  for position in rendered_positions}
        index_lookup = {}
        base_points = []
        for vertex in obj.data.vertices:
            # GEOM gameY-up -> BlenderZ-up is(x,-z,y).
            key = tuple(round(float(v), 5) for v in
                        (vertex.co.x, vertex.co.z, -vertex.co.y))
            index_lookup.setdefault(key, []).append(vertex.index)
            base_points.append((vertex.co.x, vertex.co.z, -vertex.co.y))
        missing = sorted(wanted-set(index_lookup))
        # Import float32 transforms can move a coordinate across a rounding
        # boundary by less than a millionth. Match those cases to the original
        # full-precision selection position with a strict2e-6 coordinate bound.
        base_points = np.asarray(base_points, dtype=float)
        source_points = {tuple(round(float(v), 5) for v in position): np.asarray(position, dtype=float)
                         for position in rendered_positions}
        largest_fallback_error = 0.
        for key in missing:
            errors = np.max(np.abs(base_points-source_points[key]), axis=1)
            nearest_error = float(np.min(errors))
            if nearest_error > 2e-6:
                raise ValueError(f'{obj.name}: selected base position is absent: {key}, nearest error={nearest_error}')
            index_lookup[key] = np.flatnonzero(errors <= 2e-6).tolist()
            largest_fallback_error = max(largest_fallback_error, nearest_error)
        indices = sorted({index for key in wanted for index in index_lookup[key]})
        if not indices:
            raise ValueError(f'Empty selected mesh: {obj.name}')
        selected.append((obj, np.asarray(indices, dtype=int)))
        details.append({'name': obj.name, 'game_mesh_index': record['index'],
                        'input_positions': len(record['positions_game']),
                        'unindexed_source_vertices_excluded': len(record['positions_game'])-len(rendered_positions),
                        'rendered_source_positions': len(rendered_positions),
                        'unique_game_positions': len(wanted),
                        'matched_blender_vertices': len(indices),
                        'rounding_boundary_fallback_positions': len(missing),
                        'max_fallback_coordinate_error': largest_fallback_error,
                        'unmatched_positions': 0})
    return selected, details


def project(scene, camera, points, depsgraph):
    view = np.asarray(camera.matrix_world.inverted(), dtype=np.float64)
    projection = np.asarray(camera.calc_matrix_camera(
        depsgraph, x=scene.render.resolution_x, y=scene.render.resolution_y,
        scale_x=scene.render.pixel_aspect_x, scale_y=scene.render.pixel_aspect_y),
        dtype=np.float64)
    homogeneous = np.c_[points, np.ones(len(points))]
    camera_points = homogeneous @ view.T
    clip = camera_points @ projection.T
    if np.min(np.abs(clip[:, 3])) < 1e-10:
        raise ValueError('A selected face point lies on the camera plane')
    xy = .5*(clip[:, :2]/clip[:, 3:4]+1.)
    depth = -camera_points[:, 2]
    lo, hi = np.min(xy, axis=0), np.max(xy, axis=0)
    if not np.isfinite(xy).all() or not np.isfinite(depth).all():
        raise ValueError('Non-finite actual Blender projection')
    return {'bbox_ndc': {'min': lo.tolist(), 'max': hi.tolist()},
            'width_fraction': float(hi[0]-lo[0]),
            'height_fraction': float(hi[1]-lo[1]),
            'center_ndc': ((lo+hi)*.5).tolist(),
            'min_depth': float(np.min(depth)), 'max_depth': float(np.max(depth)),
            'all_points_in_image': bool(np.all(lo >= 0.) and np.all(hi <= 1.) and
                                        np.min(depth) >= camera.data.clip_start),
            'inside_two_percent_margin': bool(np.all(lo >= .02) and np.all(hi <= .98) and
                                              np.min(depth) >= camera.data.clip_start)}


def main():
    argv = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scene', type=Path, default=ROOT/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend')
    parser.add_argument('--modified', type=Path, default=ROOT/'modified_v6')
    parser.add_argument('--face-selection', type=Path, default=ROOT/'work/v6/face_selection.json')
    parser.add_argument('--jaw-selection', type=Path, default=ROOT/'work/v6/jaw_selection.json')
    parser.add_argument('--diagnostics', type=Path, default=ROOT/'work/v6/cameras.json')
    parser.add_argument('--ground-face-window', type=window, default=(42, 65))
    parser.add_argument('--highland-face-window', type=window, default=(41, 53))
    parser.add_argument('--jaw-end-window', type=window, default=(100, 119))
    parser.add_argument('--minimum-jaw-height', type=float, default=.45)
    parser.add_argument('--report', type=Path, default=ROOT/'work/v6/camera_framing_audit.json')
    args = parser.parse_args(argv)
    if not 0 < args.minimum_jaw_height < .98:
        raise ValueError('Invalid minimum ending jaw height')
    geometry_path = args.modified/'dsts-loader/patch/chr424857.geom'
    geometry_hash = digest(geometry_path)
    snapshots = {'face': json.loads(args.face_selection.read_text()),
                 'jaw': json.loads(args.jaw_selection.read_text())}
    for region, snapshot in snapshots.items():
        if snapshot.get('geometry_sha256') != geometry_hash:
            raise ValueError(f'{region} selection is for a different game geometry')
    diagnostics = json.loads(args.diagnostics.read_text())
    diagnostic_cameras = {row['path']: row for row in diagnostics['cameras']}
    expected = {f'dsts-loader/patch/cam_chr424857_{stem}_{side}.anim'
                for stem in ('bs01', 'bs02') for side in ('pc', 'em')}
    if set(diagnostic_cameras) != expected:
        raise ValueError('Authoring diagnostics have a different camera set')
    geometry = read_geom(geometry_path)
    report = {'revision': 6, 'passed': False, 'projection': {
        'aspect_ratio': '16:9', 'resolution': [1280, 720],
        'fov_convention': 'horizontal', 'ndc_convention': '0..1; bottom-left origin',
        'required_margin': .02, 'minimum_face_height_fraction': .55,
        'minimum_jaw_ending_height_fraction': args.minimum_jaw_height},
        'source_scene_sha256': digest(args.scene),
        'source_geometry_sha256': geometry_hash,
        'selection_sha256': digest(args.face_selection),
        'face_selection_sha256': digest(args.face_selection),
        'jaw_selection_sha256': digest(args.jaw_selection),
        'camera_diagnostics_sha256': digest(args.diagnostics),
        'camera_sha256': {}, 'cameras': {}, 'selection_matches': {},
        'limits': ['Actual skinned semantic bounds establish framing and depth, not self-occlusion or engine behavior.',
                   'The whole forehead may be cropped in the deliberate jaw-ending close-up.',
                   'Native particles and engine camera hand-off are not rendered or tested.']}
    bpy.ops.wm.open_mainfile(filepath=str(args.scene))
    scene = bpy.context.scene
    scene.render.resolution_x, scene.render.resolution_y = 1280, 720
    scene.render.resolution_percentage = 100
    scene.render.pixel_aspect_x = scene.render.pixel_aspect_y = 1.
    camera = scene.camera
    camera.data.type = 'PERSP'
    camera.data.sensor_fit = 'HORIZONTAL'
    camera.rotation_mode = 'QUATERNION'
    camera.data.shift_x = camera.data.shift_y = 0.
    armature = bpy.data.objects['chr424857']
    for track in armature.animation_data.nla_tracks:
        track.mute = True
    selections = {}
    for region, snapshot in snapshots.items():
        selections[region], report['selection_matches'][region] = select_meshes(snapshot, geometry)
    conversion = Quaternion((1., 0., 0.), math.pi/2)
    depsgraph = bpy.context.evaluated_depsgraph_get()
    face_windows = {'bs01': args.ground_face_window, 'bs02': args.highland_face_window}
    for stem, count in [('bs01', 120), ('bs02', 96)]:
        armature.animation_data.action = bpy.data.actions['chr424857_'+stem]
        clips = {}
        face_frames = set(range(face_windows[stem][0], face_windows[stem][1]+1))
        jaw_frames = set(range(args.jaw_end_window[0], args.jaw_end_window[1]+1)) if stem == 'bs01' else set()
        if min(face_frames) < 0 or max(face_frames) >= count or (jaw_frames and max(jaw_frames) >= count):
            raise ValueError('Framing phase is outside the clip')
        for side in ('pc', 'em'):
            relative = f'dsts-loader/patch/cam_chr424857_{stem}_{side}.anim'
            clip = read(args.modified/relative, expected_bones=2)
            if clip._source_frame_count != count:
                raise ValueError('Unexpected camera frame count')
            clips[side] = clip
            report['camera_sha256'][relative] = digest(args.modified/relative)
            samples = diagnostic_cameras[relative]['samples']
            if len(samples) != count or [s['frame'] for s in samples] != list(range(count)):
                raise ValueError('Authoring diagnostics are missing camera frames')
            report['cameras'][relative] = {'stem': stem, 'side': side, 'frames': [],
                                           'full_face_frames': sorted(face_frames),
                                           'jaw_end_frames': sorted(jaw_frames)}
        for frame in range(count):
            scene.frame_set(frame+1)
            bpy.context.view_layer.update()
            depsgraph.update()
            region_points = {region: np.concatenate([world_vertices(obj, indices, depsgraph)
                                                     for obj, indices in selected], axis=0)
                             for region, selected in selections.items()}
            for side, clip in clips.items():
                position, rotation, _ = sample(clip, 0, frame)
                camera.location = (position[0], -position[2], position[1])
                camera.rotation_quaternion = conversion @ Quaternion((rotation[3], *rotation[:3]))
                camera.data.angle = math.radians(float(sample_track(clip.float_channels[0], frame)))
                bpy.context.view_layer.update()
                result = {region: project(scene, camera, points, depsgraph)
                          for region, points in region_points.items()}
                result.update({'frame': frame, 'full_face': frame in face_frames,
                               'jaw_end': frame in jaw_frames,
                               'fov_degrees': math.degrees(camera.data.angle),
                               'camera_world_position_blender': list(camera.location)})
                relative = f'dsts-loader/patch/cam_chr424857_{stem}_{side}.anim'
                report['cameras'][relative]['frames'].append(result)
    passed = True
    for relative, record in report['cameras'].items():
        rows = record['frames']
        faces = [row for row in rows if row['full_face']]
        jaws = [row for row in rows if row['jaw_end']]
        face_failures = [row['frame'] for row in faces
                         if not row['face']['inside_two_percent_margin'] or row['face']['height_fraction'] < .55]
        jaw_failures = [row['frame'] for row in jaws
                        if not row['jaw']['inside_two_percent_margin'] or row['jaw']['height_fraction'] < args.minimum_jaw_height]
        depth_failures = [row['frame'] for row in rows
                          if min(row['face']['min_depth'], row['jaw']['min_depth']) <= camera.data.clip_start]
        record['face_summary'] = {
            'all_points_in_view': not face_failures, 'failure_frames': face_failures,
            'min_height_fraction': min(row['face']['height_fraction'] for row in faces),
            'max_height_fraction': max(row['face']['height_fraction'] for row in faces),
            'min_depth': min(row['face']['min_depth'] for row in faces)}
        record['jaw_summary'] = None if not jaws else {
            'all_points_in_view': not jaw_failures, 'failure_frames': jaw_failures,
            'min_height_fraction': min(row['jaw']['height_fraction'] for row in jaws),
            'max_height_fraction': max(row['jaw']['height_fraction'] for row in jaws),
            'min_depth': min(row['jaw']['min_depth'] for row in jaws)}
        record['all_frames_min_depth'] = min(min(row['face']['min_depth'], row['jaw']['min_depth']) for row in rows)
        record['near_plane_failure_frames'] = depth_failures
        passed = passed and not (face_failures or jaw_failures or depth_failures)
        print(relative, json.dumps({'face': record['face_summary'], 'jaw': record['jaw_summary'],
                                    'near_plane_failure_frames': depth_failures}), flush=True)
    report['passed'] = bool(passed)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print('V6 BLENDER FRAMING', 'PASS' if passed else 'FAIL', str(args.report), flush=True)
    if not passed:
        raise ValueError('Actual Blender face or jaw projection failed the phase-specific framing check')


if __name__ == '__main__':
    main()
