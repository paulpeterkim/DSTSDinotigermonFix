"""Package the hash-validated V6 camera revision and real exported-camera GIFs."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs_v6'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if not (OUT/'README_V6.md').exists():
        shutil.copyfile(ROOT/'README_V6.md', OUT/'README_V6.md')
    report = json.loads((OUT/'validation.json').read_text())
    assets = {p.relative_to(ROOT/'modified_v6').as_posix(): sha(p)
              for p in sorted((ROOT/'modified_v6').rglob('*')) if p.is_file()}
    if not report['passed'] or report['asset_sha256'] != assets:
        raise ValueError('V6 game files differ from the validated inventory')
    audit_path = ROOT/'work/v6/camera_framing_audit.json'
    audit = json.loads(audit_path.read_text())
    if not audit['passed'] or report.get('framing_audit_sha256') != sha(audit_path):
        raise ValueError('Missing, failed or stale Blender framing audit')
    for relative, expected in audit['camera_sha256'].items():
        if assets[relative] != expected:
            raise ValueError('Blender audit describes a different camera')
    for stem, title in [('bs01', 'Ground Fang'), ('bs02', 'Highland Fang')]:
        folder = ROOT/f'work/v6/sequence/{stem}_pc'
        if not (folder/'frames.json').exists():
            continue
        from PIL import Image, ImageDraw, ImageFont
        data = json.loads((folder/'frames.json').read_text())
        camera = f'dsts-loader/patch/cam_chr424857_{stem}_pc.anim'
        actor = f'dsts-loader/patch/chr424857_{stem}.anim'
        if data['camera_sha256'] != assets[camera] or data['actor_sha256'] != assets[actor]:
            raise ValueError('Preview references stale game files')
        if data['source_scene_sha256'] != audit['source_scene_sha256']:
            raise ValueError('Preview and framing audit use different actor scenes')
        paths = sorted(folder.glob('*.png'))
        if len(paths) != len(data['frames']) or data['frames'][-1] != (119 if stem == 'bs01' else 95):
            raise ValueError('Camera preview is incomplete')
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 23)
        small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 12)
        frames = []
        for path in paths:
            im = Image.open(path).convert('RGB')
            draw = ImageDraw.Draw(im)
            draw.rectangle((0, 0, 768, 44), fill='#202733')
            draw.text((14, 9), title+' V6 — left to right', font=font, fill='#f2f3f7')
            draw.rectangle((0, 409, 768, 432), fill='#202733')
            draw.text((14, 414), 'Exported camera at 16:9; native particles are not rendered.', font=small, fill='#e5be82')
            frames.append(im)
        palette_image = Image.new('RGB', (768, 432*5))
        for i, index in enumerate([0, len(frames)//4, len(frames)//2, 3*len(frames)//4, len(frames)-1]):
            palette_image.paste(frames[index], (0, 432*i))
        palette = palette_image.quantize(colors=256)
        frames = [im.quantize(palette=palette, dither=Image.Dither.NONE) for im in frames]
        stamps = [round((f-data['frames'][0])/data['fps']*100)*10 for f in data['frames']]
        durations = [b-a for a, b in zip(stamps, stamps[1:])]+[500]
        frames[0].save(OUT/(title.replace(' ', '_')+'_Camera_V6.gif'), save_all=True,
                       append_images=frames[1:], duration=durations, loop=0, disposal=2, optimize=False)
    mod = OUT/'Dinotigermon_Fang_Skills_V6_TEST.zip'
    with zipfile.ZipFile(mod, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in assets:
            z.write(ROOT/'modified_v6'/name, name)
        z.write(OUT/'README_V6.md', 'README_Fang_Skills_V6.md')
    with zipfile.ZipFile(mod) as z:
        if z.testzip() is not None:
            raise ValueError('Mod ZIP CRC failure')
        for name, expected in assets.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError(f'Packed game file mismatch: {name}')
    baseline = ROOT/'outputs_v5/validation.json'
    if not baseline.exists():
        baseline = ROOT/'baseline_v5_validation.json'
    source = OUT/'Dinotigermon_Fang_Skills_V6_Source.zip'
    scripts = ['revise_mod_v6.py', 'author_cameras_v5.py', 'render_camera_v6.py', 'audit_camera_v6.py',
               'validate_mod_v6.py', 'package_outputs_v6.py', 'anim_codec.py',
               'motion_math.py', 'geom_preview.py', 'inspect_jaw_v3.py',
               'patch_skills.py', 'validate_mod.py']
    with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in scripts:
            z.write(ROOT/'scripts'/name, 'scripts/'+name)
        z.write(OUT/'README_V6.md', 'README_V6.md')
        z.write(OUT/'validation.json', 'outputs_v6/validation.json')
        z.write(baseline, 'baseline_v5_validation.json')
        for name in ['face_selection.json', 'jaw_selection.json', 'cameras.json', 'camera_framing_audit.json']:
            z.write(ROOT/'work/v6'/name, 'work/v6/'+name)
    with zipfile.ZipFile(source) as z:
        if z.testzip() is not None:
            raise ValueError('Source ZIP CRC failure')
    manifest = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256.json'}
    (OUT/'SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('V6 ZIP CRC and all 125 packed game-asset hashes verified.')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
