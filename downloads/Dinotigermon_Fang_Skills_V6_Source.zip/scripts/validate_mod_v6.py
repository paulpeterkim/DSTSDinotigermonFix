#!/usr/bin/env python3
"""Validate left-to-right cameras, Ground's jaw ending, and automatic text.

The scope check preserves every actor, mesh, effect binding and gameplay field
except the requested description-ID reset. This is not a game-runtime test.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import traceback

import numpy as np

import anim_codec
from motion_math import fk, qinv, qrotate, normalize
from patch_skills import SKILL_TABLE, GROUND_FANG_ID, HIGHLAND_FANG_ID
from validate_mod import check, inventory, parse_typed_csv, sha256

ROOT = Path(__file__).resolve().parents[1]
CAMERAS = {Path(f"dsts-loader/patch/cam_chr424857_{stem}_{side}.anim"): stem
           for stem in ("bs01", "bs02") for side in ("pc", "em")}
COUNTS = {"bs01": 120, "bs02": 96}
CHANGED_CAMERAS = {p for p in CAMERAS if p.name != "cam_chr424857_bs02_em.anim"}
DIRECTION_FRAMES = {"bs01": list(range(9, 101)), "bs02": list(range(9, 86))}
TOLERANCE = .0001


def protected_tracks(old, new, quaternion=False):
    check(set(old) == set(new), "Protected track keys changed")
    maximum = 0.
    for frame in old:
        a, b = np.asarray(old[frame]), np.asarray(new[frame])
        if quaternion and np.dot(a, b) < 0:
            b = -b
        error = float(np.max(np.abs(a-b)))
        check(error <= TOLERANCE, f"Protected channel changed at frame{frame}: {error}")
        maximum = max(maximum, error)
    return maximum


def pose(actor, skeleton, frame):
    samples = [anim_codec.sample(actor, b, frame) for b in range(actor.bone_count)]
    return fk(skeleton, np.asarray([s[0] for s in samples]), np.asarray([s[1] for s in samples]))


def project(camera, frame, point):
    p, q, _ = anim_codec.sample(camera, 0, frame)
    local = qrotate(qinv(q), point-p)
    depth = float(-local[2])
    fov = float(anim_codec.sample_track(camera.float_channels[0], frame))
    check(depth > .05 and 5 < fov < 120, "Mouth target has invalid camera depth/FOV")
    half_width = depth*math.tan(math.radians(fov)/2)
    return {"ndc": (local[:2]/np.array([2*half_width, 2*half_width/(16/9)])+.5).tolist(),
            "depth": depth, "image_scale": half_width,
            "distance": float(np.linalg.norm(point-p)), "fov": fov}


def validate_scope(baseline, baseline_report, modified, report):
    accepted = json.loads(baseline_report.read_text())
    check(accepted.get("passed") is True and accepted.get("revision") == 5,
          "V6 needs the accepted V5 validation baseline")
    before, after = inventory(baseline), inventory(modified)
    hashes = {r.as_posix(): sha256(p) for r, p in sorted(before.items())}
    check(hashes == accepted.get("asset_sha256"), "V5 source inventory changed")
    locales = sorted((baseline/"dsts-loader").glob("patch_text*"))
    check(len(locales) == 11, "Expected all eleven original locale folders")
    removed = {(folder/"text/skill_explanation.mbe/000_Sheet1.ap.csv").relative_to(baseline)
               for folder in locales}
    check(removed <= set(before), "A baseline custom description file is missing")
    check(set(before)-set(after) == removed and not set(after)-set(before),
          "V6 removed or added files outside the eleven custom description tables")
    for relative in removed:
        _, rows = parse_typed_csv(baseline/relative)
        check({r[0] for r in rows} == {GROUND_FANG_ID, HIGHLAND_FANG_ID},
              "A removed description table contains unrelated skill text")
        check(not (modified/relative).exists(), "A custom description file remains")
    check(not list((modified/"dsts-loader").glob("patch_text*/text/skill_explanation.mbe/*.csv")),
          "A manual skill explanation CSV is still present")
    allowed = {*CHANGED_CAMERAS, SKILL_TABLE}
    changes = []
    for relative in sorted(after):
        digest = sha256(after[relative])
        if digest != hashes[relative.as_posix()]:
            check(relative in allowed, f"Unexpected V6 asset change: {relative}")
            changes.append({"path": relative.as_posix(), "v5_sha256": hashes[relative.as_posix()],
                            "v6_sha256": digest})
    check({r["path"] for r in changes} == {p.as_posix() for p in allowed},
          "Expected three revised camera clips and one skill table; Highland EM already reads left-to-right")
    report["baseline_validation_sha256"] = sha256(baseline_report)
    report["file_changes"] = changes
    report["removed_description_files"] = [r.as_posix() for r in sorted(removed)]
    report["checks"].append({"name": "validated_v5_baseline_and_exact_requested_file_scope",
                             "passed": True, "v5_files": len(before), "v6_files": len(after),
                             "changed": len(changes), "removed": len(removed),
                             "unchanged": len(after)-len(changes),
                             "note": "Actor clips, jaw geometry, textures, skill names, effects and other assets match V5 exactly."})
    return after


def validate_descriptions(baseline, modified, report):
    old_header, old_rows = parse_typed_csv(baseline/SKILL_TABLE)
    new_header, new_rows = parse_typed_csv(modified/SKILL_TABLE)
    check(old_header == new_header and old_header[5] == "int32 5", "Skill table schema changed")
    old = {r[0]: r for r in old_rows}; new = {r[0]: r for r in new_rows}
    check(set(old) == set(new) == {GROUND_FANG_ID, HIGHLAND_FANG_ID}, "Skill key inventory changed")
    for key, row in new.items():
        check(row[5] == "0", f"Skill{key} is not using automatic descriptions")
        check(all(a == b for column, (a, b) in enumerate(zip(old[key], row)) if column != 5),
              f"Skill{key} changes fields beyond description ID")
        check(row[4] == row[6] == key, "Skill name/reference IDs changed")
    report["checks"].append({"name": "automatic_description_id_zero_and_all_other_skill_columns_preserved",
                             "passed": True, "column": 5, "skills": sorted(new),
                             "documentation": "https://hyotan-dev.github.io/dstsworkshop/documentation/mbe/battle_skill/"})


def validate_cameras(baseline, modified, report):
    skeleton = anim_codec.read_embedded_skeleton(baseline/"dsts-loader/patch/chr424857.geom")
    actors = {stem: anim_codec.read(baseline/f"dsts-loader/patch/chr424857_{stem}.anim") for stem in COUNTS}
    forward = {}
    for stem, actor in actors.items():
        start, _ = pose(actor, skeleton, 0); end, _ = pose(actor, skeleton, COUNTS[stem]-1)
        vector = end[2]-start[2]; vector[1] = 0
        forward[stem] = normalize(vector)
    continuity, directions, endings, metadata = [], [], [], []
    for relative, stem in CAMERAS.items():
        old, new = anim_codec.read(baseline/relative), anim_codec.read(modified/relative)
        count = COUNTS[stem]
        check(old.bone_count == new.bone_count == 2 and old._source_frame_count == new._source_frame_count == count,
              f"Camera skeleton/frame count changed: {relative}")
        check(old.playback_rate == new.playback_rate and math.isclose(old._source_duration, new._source_duration, abs_tol=2e-6, rel_tol=0),
              f"Camera FPS/duration changed: {relative}")
        check(old.float_channel_count == new.float_channel_count, "Camera float-channel count changed")
        for field in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
            check(np.array_equal(getattr(old, field), getattr(new, field)), f"Camera metadata changed:{field}")
        maximum_protected = 0.
        for field in ("positions", "rotations", "scales", "float_channels"):
            check(set(getattr(old, field)) == set(getattr(new, field)), f"Camera channel set changed:{field}")
        for bone in range(2):
            maximum_protected = max(maximum_protected, protected_tracks(old.scales[bone], new.scales[bone]))
            if bone != 0:
                maximum_protected = max(maximum_protected,
                    protected_tracks(old.positions[bone], new.positions[bone]),
                    protected_tracks(old.rotations[bone], new.rotations[bone], quaternion=True))
        for channel in old.float_channels:
            if channel != 0:
                maximum_protected = max(maximum_protected, protected_tracks(old.float_channels[channel], new.float_channels[channel]))
        for kind in ("positions", "rotations"):
            check(set(getattr(new, kind)[0]) == set(range(count)), f"Camera root{kind} keys are sparse")
        check(set(new.float_channels[0]) == set(range(count)), "Camera FOV keys are sparse")
        samples = [anim_codec.sample(new, 0, f) for f in range(count)]
        positions, rotations = np.asarray([s[0] for s in samples]), np.asarray([s[1] for s in samples])
        fovs = np.array([float(anim_codec.sample_track(new.float_channels[0], f)) for f in range(count)])
        check(np.isfinite(positions).all() and np.isfinite(rotations).all() and np.isfinite(fovs).all(), "Nonfinite camera data")
        check(np.all((fovs > 5) & (fovs < 120)), "Camera FOV is not a normal positive perspective")
        steps = np.linalg.norm(np.diff(positions, axis=0), axis=1)
        angles = np.degrees(2*np.arccos(np.clip(np.abs(np.sum(rotations[1:]*rotations[:-1], axis=1)), 0, 1)))
        fov_steps = np.abs(np.diff(fovs))
        check(float(max(steps)) <= 1.5 and float(max(angles)) <= 28 and float(max(fov_steps)) <= 5,
              f"Camera transition exceeds broad jump bounds: {relative}")
        continuity.append({"path": relative.as_posix(), "max_position_step": float(max(steps)),
                           "max_rotation_step_degrees": float(max(angles)), "max_fov_step_degrees": float(max(fov_steps))})
        orientation = []
        for frame in DIRECTION_FRAMES[stem]:
            right = qrotate(rotations[frame], [1., 0., 0.])
            projected = float(np.dot(right, forward[stem]))
            check(projected > .025, f"Attack direction is not clearly left-to-right: {relative}, frame{frame}: {projected}")
            orientation.append({"frame": frame, "forward_dot_camera_right": projected})
        directions.append({"path": relative.as_posix(), "attack_forward": forward[stem].tolist(),
                           "minimum_positive_screen_direction": min(s["forward_dot_camera_right"] for s in orientation),
                           "samples": orientation})
        if stem == "bs01":
            jaw_frames = []
            for frame in (100, 110, 115, 119):
                wp, wq = pose(actors[stem], skeleton, frame)
                # Anatomical upper-incisor point; the jaw hinge alone lies behind the mouth.
                mouth = wp[6]+qrotate(wq[6], [0., -.216562, .377366])
                before, after = project(old, frame, mouth), project(new, frame, mouth)
                magnification = before["image_scale"]/after["image_scale"]
                ndc = np.asarray(after["ndc"])
                check(np.all((ndc >= .18) & (ndc <= .82)), f"Ground ending is not centered on the mouth: {relative}, frame{frame}")
                check(magnification >= 1.35, f"Ground ending does not close in on the jaw: {relative}, frame{frame}")
                jaw_frames.append({"frame": frame, "mouth_ndc": after["ndc"], "mouth_depth": after["depth"],
                                   "magnification_vs_v5_ending": magnification})
            endings.append({"path": relative.as_posix(), "samples": jaw_frames})
        metadata.append({"path": relative.as_posix(), "frames": count, "fps": new.playback_rate,
                         "duration": new._source_duration, "max_protected_channel_error": maximum_protected,
                         "sha256": sha256(modified/relative)})
    report["cameras"] = metadata
    report["checks"].extend([
        {"name": "camera_metadata_durations_and_protected_channels_preserved", "passed": True, "cameras": metadata},
        {"name": "normal_perspective_and_continuous_camera_tracks", "passed": True, "cameras": continuity},
        {"name": "both_skills_project_left_to_right_in_both_camera_angles", "passed": True, "cameras": directions,
         "note": "The horizontal attack vector projects positively on camera-right; no negative-scale image mirror is used."},
        {"name": "ground_final_frames_focus_on_actual_mouth_landmark", "passed": True, "cameras": endings,
         "note": "Mouth-point centering/magnification complements the independent rendered jaw-framing check."},
    ])


def validate_framing(audit_path, modified, report):
    """Bind actual rendered face phases and the final twenty jaw frames."""
    audit = json.loads(audit_path.read_text())
    check(audit.get("passed") is True and audit.get("revision") == 6, "The V6 Blender framing audit did not pass")
    check(audit["projection"]["aspect_ratio"] == "16:9" and audit["projection"]["fov_convention"] == "horizontal",
          "The Blender projection differs from the camera preview")
    expected = {r.as_posix(): sha256(modified/r) for r in CAMERAS}
    check(audit["camera_sha256"] == expected, "Blender framing audit uses different camera clips")
    check(audit["source_geometry_sha256"] == sha256(modified/"dsts-loader/patch/chr424857.geom"),
          "Blender framing audit uses different geometry")
    for field, name in [("face_selection_sha256", "face_selection.json"),
                        ("jaw_selection_sha256", "jaw_selection.json"),
                        ("camera_diagnostics_sha256", "cameras.json")]:
        check(audit[field] == sha256(audit_path.parent/name), f"Blender framing audit uses stale {name}")
        report[field] = audit[field]
    scene = ROOT/"outputs_v3/Dinotigermon_Fang_Attacks_V3.blend"
    if scene.is_file():
        check(audit["source_scene_sha256"] == sha256(scene), "Blender audit uses a different actor scene")
    check(set(audit["cameras"]) == set(expected), "Blender audit is missing or adds camera clips")
    summaries = []
    for relative, record in audit["cameras"].items():
        stem = CAMERAS[Path(relative)]
        rows = record["frames"]
        check(len(rows) == COUNTS[stem] and [r["frame"] for r in rows] == list(range(COUNTS[stem])),
              f"Blender framing audit is missing frames: {relative}")
        face_frames = set(range(42, 66)) if stem == "bs01" else set(range(41, 54))
        jaw_frames = set(range(100, 120)) if stem == "bs01" else set()
        check(set(record["full_face_frames"]) == face_frames and set(record["jaw_end_frames"]) == jaw_frames,
              f"Blender framing phases changed: {relative}")
        for region, phase, minimum in [("face", face_frames, .55), ("jaw", jaw_frames, .45)]:
            for row in rows:
                value = row[region]
                check(math.isfinite(value["min_depth"]) and value["min_depth"] > .05,
                      "Selected face/jaw geometry enters the camera near plane")
                if row["frame"] not in phase:
                    continue
                lo, hi = np.asarray(value["bbox_ndc"]["min"]), np.asarray(value["bbox_ndc"]["max"])
                check(lo.shape == hi.shape == (2,) and np.isfinite(lo).all() and np.isfinite(hi).all(),
                      "Blender framing bounds are invalid")
                check(np.all(lo >= .02) and np.all(hi <= .98),
                      f"Actual {region} leaves the image margin: {relative}, frame {row['frame']}")
                check(minimum <= value["height_fraction"] <= .96,
                      f"Actual {region} is too small or cropped: {relative}, frame {row['frame']}")
        check(record["face_summary"]["all_points_in_view"] and not record["face_summary"]["failure_frames"] and
              not record["near_plane_failure_frames"], "Blender face/near-plane summary failed")
        if jaw_frames:
            check(record["jaw_summary"]["all_points_in_view"] and not record["jaw_summary"]["failure_frames"],
                  "Blender jaw-ending summary failed")
        summaries.append({"path": relative, "face": record["face_summary"], "ending_jaw": record["jaw_summary"]})
    report["framing_audit_sha256"] = sha256(audit_path)
    report["checks"].append({"name": "independent_blender_camera_and_jaw_framing_report_bound", "passed": True,
                             "camera_sha256": expected, "cameras": summaries,
                             "note": "Actual skinned geometry is audited independently in Blender; engine handoff still needs a runtime check."})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=ROOT/"modified_v5")
    parser.add_argument("--modified", type=Path, default=ROOT/"modified_v6")
    parser.add_argument("--baseline-report", type=Path, default=ROOT/"outputs_v5/validation.json")
    parser.add_argument("--framing-audit", type=Path, default=ROOT/"work/v6/camera_framing_audit.json")
    parser.add_argument("--report", type=Path, default=ROOT/"outputs_v6/validation.json")
    args = parser.parse_args()
    report = {"revision": 6, "passed": False, "checks": [], "baseline": str(args.baseline.resolve()), "modified": str(args.modified.resolve())}
    try:
        files = validate_scope(args.baseline, args.baseline_report, args.modified, report)
        validate_descriptions(args.baseline, args.modified, report)
        validate_cameras(args.baseline, args.modified, report)
        if args.framing_audit.is_file():
            validate_framing(args.framing_audit, args.modified, report)
        report["asset_sha256"] = {r.as_posix(): sha256(p) for r, p in sorted(files.items())}
        report["passed"] = True
    except Exception as error:
        report["error"] = str(error); report["traceback"] = traceback.format_exc()
    report["limits"] = ["Camera and generated-description behavior still need an in-game check.",
                        "Native effect timing is retained from V4; this camera/text edit does not retime particles."]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report}")
    if not report['passed']:
        print(report['error'], file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
