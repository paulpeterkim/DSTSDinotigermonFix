"""Package validated game assets and separate, clearly labeled previews."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(font_path,27)
small=ImageFont.truetype(font_path,12)
for stem,title in [('bs01','Ground Fang'),('bs02','Highland Fang')]:
 paths=sorted((ROOT/'work/sequence'/stem).glob('*.png'))
 if len(paths)!=29:raise ValueError(f'Incomplete rendered sequence: {stem}')
 frames=[]
 for path in paths:
  im=Image.open(path).convert('RGB')
  draw=ImageDraw.Draw(im)
  draw.rectangle((0,0,640,53),fill='#202733')
  draw.text((20,10),title,font=font,fill='#f2f3f7')
  draw.text((20,454),'Blender attacker-motion preview - not in-game capture',font=small,fill='#c1c8d5')
  frames.append(im)
 palette_image=Image.new('RGB',(640,480*4))
 for n,index in enumerate([0,6,13,20]):palette_image.paste(frames[index],(0,480*n))
 palette=palette_image.quantize(colors=256)
 quantized=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in frames]
 durations=[67]*len(frames);durations[-1]=700
 quantized[0].save(OUT/(title.replace(' ','_')+'.gif'),save_all=True,
                   append_images=quantized[1:],duration=durations,loop=0,disposal=2,optimize=False)

modzip=OUT/'Dinotigermon_Fang_Skills_TEST.zip'
with zipfile.ZipFile(modzip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((ROOT/'modified').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(ROOT/'modified'))
 z.write(OUT/'README_Fang_Skills.md','README_Fang_Skills.md')
with zipfile.ZipFile(modzip) as z:
 if z.testzip() is not None:raise ValueError('Packaged mod CRC failure')
 for p in (ROOT/'modified').rglob('*'):
  if p.is_file() and z.read(str(p.relative_to(ROOT/'modified')))!=p.read_bytes():
   raise ValueError(f'Packaged asset mismatch: {p}')
sourcezip=OUT/'Dinotigermon_Fang_Skills_Source.zip'
with zipfile.ZipFile(sourcezip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((ROOT/'scripts').glob('*.py')):z.write(p,Path('scripts')/p.name)
 for n in ['README_Fang_Skills.md','validation.json','clearance.json']:z.write(OUT/n,n)
 z.write(ROOT/'work/choreography.json','choreography.json')
with zipfile.ZipFile(sourcezip) as z:
 if z.testzip() is not None:raise ValueError('Source archive CRC failure')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
          for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix not in ('.blend1',) and p.name!='SHA256.json'}
(OUT/'SHA256.json').write_text(json.dumps(manifest,indent=2))
print('Packaged 136 game/config assets plus README; both output archives passed CRC checks.')
print(json.dumps({n:v['bytes'] for n,v in manifest.items()},indent=2))
