import bpy,sys,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
stem=sys.argv[sys.argv.index('--')+1]
assert stem in ('bs01','bs02')
bpy.ops.wm.open_mainfile(filepath=str(root/'outputs/Dinotigermon_Fang_Attacks.blend'))
scene=bpy.context.scene;arm=bpy.data.objects['chr424857']
arm.animation_data.action=bpy.data.actions['chr424857_'+stem]
for track in arm.animation_data.nla_tracks:track.mute=True
camera=scene.camera
if stem=='bs01':
 camera.data.ortho_scale=5.4
 target=Vector((0,-.45,.95))
else:
 camera.data.ortho_scale=6.8
 target=Vector((0,-.35,1.65))
camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_x=640;scene.render.resolution_y=480
n=56 if stem=='bs01' else 57
frames=list(range(0,n,2))
if frames[-1]!=n-1:frames.append(n-1)
for i,f in enumerate(frames):
 scene.frame_set(f+1)
 scene.render.filepath=str(root/f'work/sequence/{stem}/{i:03}.png')
 bpy.ops.render.render(write_still=True)
print('RENDERED',stem,len(frames))
