import sys,os,json
from pathlib import Path
import bpy
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from anim_codec import _load_tools,_PACKAGE,read,sample
import numpy as np
import importlib
_load_tools()
from geom_preview import install_blender_preview_patch
from importlib import import_module
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'work/original.blend'))
importer=import_module(f'{_PACKAGE}.src.BlenderIO.Import.ImportTimeStrangerGeom')
ErrorLog=import_module(f'{_PACKAGE}.src.BlenderIO.Logging').ImportErrorLog
arm=bpy.data.objects['chr424857']
for track in arm.animation_data.nla_tracks:track.mute=True
for obj in bpy.data.objects:
 if obj.type=='MESH' and obj.name=='outline':obj.hide_render=True;obj.hide_set(True)
for stem in ('bs01','bs02'):
 old=bpy.data.actions.get('chr424857_'+stem)
 if old:old.name='source_'+stem
 importer.import_ts_anim(arm,str(ROOT/f'modified_v2/dsts-loader/patch/chr424857_{stem}.anim'),ErrorLog())
for track in arm.animation_data.nla_tracks:track.mute=True
scene=bpy.context.scene
scene.render.engine='BLENDER_WORKBENCH'
scene.display.shading.light='STUDIO'
scene.display.shading.studiolight_rotate_z=0.4
scene.display.shading.color_type='TEXTURE'
scene.display.shading.show_shadows=True
scene.display.shading.show_cavity=True
scene.display.shading.cavity_type='BOTH'
scene.display.shading.curvature_ridge_factor=1.4
scene.display.shading.curvature_valley_factor=1.0
scene.display.shading.show_specular_highlight=True
scene.display.shading.background_type='WORLD'
scene.world.color=(.035,.045,.065)
scene.render.resolution_x=800;scene.render.resolution_y=600;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.render.film_transparent=False
scene.render.fps=30
scene.view_settings.view_transform='Standard'
cam_data=bpy.data.cameras.new('PreviewCamera');cam=bpy.data.objects.new('PreviewCamera',cam_data);scene.collection.objects.link(cam)
cam.location=(3.2,-6.5,2.6);target=Vector((-.1,-.65,1.3));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam_data.type='ORTHO';cam_data.ortho_scale=6.1
scene.camera=cam
# A simple floor shows the height of the leap; it is not exported into the mod.
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.04));floor=bpy.context.object;floor.name='PreviewFloor';floor.color=(.12,.15,.20,1)
mat=bpy.data.materials.new('PreviewFloor');mat.diffuse_color=(.12,.15,.20,1);floor.data.materials.append(mat)
# World scale / representative joint diagnostics.
print('MESHES',[(o.name,list(o.dimensions)) for o in bpy.data.objects if o.type=='MESH' and o!=floor])
for stem,frames in [('bs01',[0,23,33,44,50,59,67,76]),('bs02',[0,16,33,39,42,44,51,76])]:
 arm.animation_data.action=bpy.data.actions['chr424857_'+stem]
 if stem=='bs02':
  cam.data.ortho_scale=8.3
  cam.rotation_euler=(Vector((-.1,-.9,2.0))-cam.location).to_track_quat('-Z','Y').to_euler()
 else:
  cam.data.ortho_scale=5.6
  cam.rotation_euler=(Vector((-.1,-.9,.95))-cam.location).to_track_quat('-Z','Y').to_euler()
 actor_clip=read(ROOT/f'modified_v2/dsts-loader/patch/chr424857_{stem}.anim')
 base_center=sample(actor_clip,2,0)[0]
 for frame in ([] if '--save-only' in sys.argv else frames):
  scene.frame_set(frame+1)
  travel=sample(actor_clip,2,frame)[0]-base_center
  cam.location=(3.2+travel[0],-6.5-travel[2],2.6)
  focus=Vector((-.1+travel[0],-.9-travel[2],2.0 if stem=='bs02' else .95))
  cam.rotation_euler=(focus-cam.location).to_track_quat('-Z','Y').to_euler()
  scene.render.filepath=str(ROOT/f'work/v2/preview/{stem}_{frame:03d}.png')
  bpy.ops.render.render(write_still=True)
arm.animation_data.action=bpy.data.actions['chr424857_bs01'];scene.frame_set(1)
scene.frame_end=120
cam.data.ortho_scale=5.6
cam.location=(3.2,-6.5,2.6)
cam.rotation_euler=(Vector((-.1,-.9,.95))-cam.location).to_track_quat('-Z','Y').to_euler()
# Save a clean editable scene containing the two authored actions and source rig.
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'outputs_v2/Dinotigermon_Fang_Attacks_V2.blend'),compress=True)
