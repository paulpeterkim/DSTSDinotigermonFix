"""Second-pass fang choreography: articulated poses, timed contacts, planted IK.

Game Y-up. Bone deltas are baked through the inspected feature/refactor codec.
Each attack has a deliberately authored length, with matching PC/EM cameras.
This file contains no victim, collision, or engine-event implementation.
"""
from pathlib import Path
from copy import deepcopy
import json,math
import numpy as np
from anim_codec import read,write,sample,sample_track,read_embedded_skeleton,slerp
from motion_math import fk,solve_leg,qmul,qinv,qrotate,euler,normalize
from author_animations import look_quat

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'original/dsts-loader/patch'
DST=ROOT/'modified_v2/dsts-loader/patch'
REPORT=ROOT/'work/v2/choreography.json'
SKEL=read_embedded_skeleton(SRC/'chr424857.geom')
NEUTRAL=read(SRC/'chr424857_bn01.anim')
P0=np.array([sample(NEUTRAL,b,0)[0] for b in range(52)])
Q0=np.array([sample(NEUTRAL,b,0)[1] for b in range(52)])
WP0,WQ0=fk(SKEL,P0,Q0)
FORWARD=qrotate(WQ0[6],[0,0,1]);FORWARD[1]=0;FORWARD=normalize(FORWARD)
RIGHT=normalize(np.cross([0,1,0],FORWARD))
LEGS=[(25,26,27),(30,31,32),(41,42,43),(46,47,48)]


def curve(keys,frame):
    """Shape-preserving cubic interpolation, with continuous key velocities.

    Unlike global smoothstep, compatible adjacent segments flow through a key.
    Impact/hold extrema intentionally stop or reverse the relevant channel.
    """
    a=np.asarray(keys,dtype=float);x=a[:,0];y=a[:,1:]
    if frame<=x[0]:return y[0].copy()
    if frame>=x[-1]:return y[-1].copy()
    h=np.diff(x);d=np.diff(y,axis=0)/h[:,None]
    m=np.zeros_like(y)
    m[0]=d[0];m[-1]=d[-1]
    for i in range(1,len(x)-1):
        same=d[i-1]*d[i]>0
        w1=2*h[i]+h[i-1];w2=h[i]+2*h[i-1]
        m[i,same]=(w1+w2)/(w1/d[i-1,same]+w2/d[i,same])
    # Zero endpoint velocity avoids popping on entry/return to idle.
    m[0]=0;m[-1]=0
    i=int(np.searchsorted(x,frame,side='right')-1)
    t=(frame-x[i])/h[i]
    return ((2*t**3-3*t*t+1)*y[i]+(t**3-2*t*t+t)*h[i]*m[i]
            +(-2*t**3+3*t*t)*y[i+1]+(t**3-t*t)*h[i]*m[i+1])


def scalar(keys,f):return float(curve(keys,f)[0])

# frame, height, travel, body pitch, body yaw, body roll,
# chest pitch, chest yaw, head pitch, head yaw, head roll, jaw opening, tuck.
GROUND=[
(0,   0,    0,   0,  0, 0,  0,  0,   0,   0, 0,  0,  0),
(9, -.19, -.14,  -5, -3, 3, -5, -3, -15,  -4, 3, 10,  0),
(15,-.16, -.12, -10, -3, 3, -4, -3, -24,  -4, 4, 22,  0),
(23, .30,  .66,   3, -1, 1, -4,  0, -19,   0, 0, 20, 34),
(28,-.11,  .96,   3,  1,-3,  1,  1, -14,   0, 0, 18,  0),
(33,-.16,  .98,   1,  0, 1,  1,  0, -10,   0, 0, 18,  0),
(39,-.12,  .97,  -2, -2, 1, -3, -2, -30,  -3, 5, 24,  0),
(44,-.08,  .99,  -3, -2, 1, -4, -2, -34,  -3, 5, 27,  0),
(48, .03, 1.04,   2,  1,-1,  4,  0,  25,   0, 0, -5,  0),
(50, .03, 1.04,   3,  1,-1,  5,  1,  33,   0, 0, -7,  0),
(53,-.01, 1.02,   2,  0, 0,  3,  0,  29,   0, 0, -6,  0),
(59,-.03,  .96,   0,-10, 4,  0, -7,   5, -34,-9, -5,  0),
(62,-.04,  .98,   1, -7, 2,  2, -4,  10, -25,-6, -5,  0),
(67,-.03,  .96,  -1, 10,-4,  1,  7,   8,  32, 9, -5,  0),
(70,-.04,  .96,  -1,  7,-2,  0,  4,   7,  22, 5, -5,  0),
(76,-.14,  .98,  -4, -2, 1, -4, -2, -32,  -7,-8,  0,  0),
(82,-.08, 1.00,  -3, -1, 0, -1, -1,  -8,  -4, 0,  8,  0),
(95, .00, 1.02,  -2,  0, 0, -1,  0,  -4,   0, 0,  4,  0),
(108,-.03,1.02,  1,  0, 0,  0,  0,   2,   0, 0,  0,  0),
(119, 0, 1.02,   0,  0, 0,  0,  0,   0,   0, 0,  0,  0),
]
HIGHLAND=[
(0,   0,    0,   0,  0, 0,  0, 0,  0,  0, 0,  0,  0),
(10,-.24,-.10,  -7, -4, 3, -6,-2,-22, -3, 2,  8,  0),
(16,-.26,-.15, -13, -6, 4, -8,-3,-30, -4, 4, 18,  0),
(21, .45, .08, -24, -6, 6,-10,-3,-22, -3, 5, 22, 36),
(28,2.22, .50, -18,-10,10, -4,-4,-15, -5, 5, 24, 63),
(33,2.80, .72, -22,-13,12, -4,-5,-18, -7, 6, 25, 68),
(36,2.70, .86, -12,-10,10, -2,-3,-20, -5, 6, 24, 58),
(39,2.12,1.03,  13, -3, 6,  3, 0,-12, -1, 1, 18, 36),
(42, .92,1.35,  37,  5,-7,  4, 2, 20,  3,-4,  2, 60),
(44, .40,1.48,  31,  8,-9,  5, 3, 23,  4,-6, -5, 40),
(47,-.04,1.50,  10,  6,-5,  4, 2, 20,  3,-3, -6,  0),
(51,-.15,1.47,   3,  3,-2,  2, 0, 17,  1,-1, -5,  0),
(57, .02,1.43,  -3,  1, 1, -4,-1, -8, -2, 0,  2,  0),
(64,-.04,1.48,  -4,  0, 0, -2, 0, -6,  0, 0,  6,  0),
(76, .00,1.49,  -3,  0, 0, -2, 0, -2,  0, 0,  3,  0),
(86,-.03,1.50,   2,  0, 0,  1, 0,  1,  0, 0,  0,  0),
(95,  0,1.50,   0,  0, 0,  0, 0,  0,  0, 0,  0,  0),
]


def foot_track(stem,index,f):
    """World-space ankle trajectories; constant runs are real foot plants."""
    base=WP0[LEGS[index][2]].copy()
    side=1 if index%2==0 else -1
    if stem=='bs01':
        land=28 if index==0 else 31 if index==1 else 33+index
        spread=.10 if index<2 else .04
        travel=1.02
        lift=.45 if index<2 else .32
        release=81 if index==0 else 84 if index==1 else 88+index
        middle=(land+16)/2
        # Outputs: forward offset, height, side spread. Front feet arrive first;
        # rear feet catch the weight later and all four then hold their anchors.
        keys=[(0,0,0,0),(15,0,0,0),(21,travel*.55,lift,spread*.6),
              (land,travel,0,spread),(release,travel,0,spread),
              (release+7,1.01,.14,spread*.5),
              (105+index*2,1.02,0,0),(119,1.02,0,0)]
    else:
        # Flight shape is authored in FK; only use target curves for ground
        # compression and the staggered landing/recovery.
        land=46 if index<2 else 50+index-2
        travel=1.48 if index<2 else 1.43
        spread=.13 if index<2 else .09
        keys=[(0,0,0,0),(17,0,0,0),(land-6,travel,.44,spread),
              (land,travel,0,spread),(63+index,travel,0,spread),
              (72+index*2,1.49,.15,spread*.6),
              (88+index,1.50,0,0),(95,1.50,0,0)]
    forward,height,spread=curve(keys,f)
    forward*=4.14/(1.02 if stem=='bs01' else 1.50)
    return base+FORWARD*forward+np.array([0,height,0])+RIGHT*side*spread


def pose(stem,phase,f):
    v=curve(phase,f)
    h,travel,pitch,yaw,roll,chest,cyaw,head,hyaw,hroll,jaw,tuck=v
    p=P0.copy();q=Q0.copy()
    travel=travel*(4.14/(1.02 if stem=='bs01' else 1.50)) if travel>0 else travel
    p[2]+=FORWARD*travel+np.array([0,h,0])
    offsets={2:(pitch,yaw,roll),3:(chest*.25,cyaw*.2,0),4:(chest*.3,cyaw*.3,0),
             5:(chest*.45,cyaw*.5,0),6:(head,hyaw,hroll),7:(jaw,0,0),
             34:(-pitch*.16,0,-roll*.35),
             24:(-tuck*.25,0,-tuck*.08),29:(-tuck*.25,0,tuck*.08),
             25:(-tuck*.20,0,0),30:(-tuck*.20,0,0),
             26:(-tuck*.70,0,0),31:(-tuck*.70,0,0),
             27:(tuck*.55,0,0),32:(tuck*.55,0,0),
             40:(tuck*.10,0,0),45:(tuck*.10,0,0),
             41:(tuck*.90,0,0),46:(tuck*.90,0,0),
             42:(-tuck*.90,0,0),47:(-tuck*.90,0,0),
             43:(tuck*.12,0,0),48:(tuck*.12,0,0)}
    lag=curve(phase,max(0,f-3));prev=curve(phase,max(0,f-1))
    # Mane, feelers, tail lag behind angular acceleration rather than moving
    # as one solid block with the head.
    head_speed=head-prev[8];turn_speed=hyaw-prev[9]
    envelope=math.sin(math.pi*f/(phase[-1][0]))**2
    for b in (8,9,10,11):offsets[b]=(-head_speed*.7*envelope, -turn_speed*.5*envelope,0)
    for chain in [(12,13,14),(15,16,17),(18,19,20),(21,22,23)]:
        sign=1 if chain[0]<18 else -1
        for n,b in enumerate(chain):
            offsets[b]=((lag[8]-head)*.20*(n+1)*envelope,-hyaw*.08*(n+1)*envelope,
                        sign*envelope*math.sin(f*.20-n*.8)*2.0)
    feeler_lift=scalar([(0,0),(10,12),(16,27),(20,22),(27,0),(95,0)],f) if stem=='bs02' else scalar([(0,0),(9,12),(15,25),(23,0),(33,0),(44,14),(50,0),(119,0)],f)
    for b in (12,15,18,21):
        angles=offsets[b];offsets[b]=(angles[0]+feeler_lift,angles[1],angles[2])
    for n,b in enumerate((35,36,37,38,39)):
        tail_lag=curve(phase,max(0,f-3-n*2))
        offsets[b]=(-tail_lag[2]*.13*envelope,-tail_lag[3]*.24*envelope,
                    envelope*math.sin(f*.11-n*.65)*2)
    for b,xyz in offsets.items():q[b]=qmul(q[b],euler(*xyz))
    errors=[]
    active=[];flight=[]
    for index,chain in enumerate(LEGS):
        is_flight=(stem=='bs02' and (19 if index<2 else 21)<=f<(43 if index<2 else 48)) or (stem=='bs01' and (17 if index<2 else 19)<=f<(26 if index<2 else 32))
        if is_flight:
            flight.append((index,chain))
            continue
        active.append((index,chain,foot_track(stem,index,f)))
    # Load the body onto its actual planted limbs. Lower the center only when
    # a stance target would otherwise require stretching a leg; feet do not
    # drift to hide the error. Flight legs are excluded from this support pass.
    wp,_=fk(SKEL,p,q)
    drop=0.
    for index,(upper,lower,end),target in active:
        length=np.linalg.norm(wp[lower]-wp[upper])+np.linalg.norm(wp[end]-wp[lower])-.005
        horizontal=np.linalg.norm((wp[upper]-target)[[0,2]])
        if horizontal<length and wp[upper,1]>target[1]:
            max_y=target[1]+math.sqrt(max(0,length*length-horizontal*horizontal))
            drop=min(drop,max_y-wp[upper,1])
    p[2,1]+=drop
    # Tuck each paw toward its shoulder/hip using joint geometry. This avoids
    # the previous straight-legged airborne pose and keeps the curl coherent
    # while the entire body rotates through the aerial fang sweep.
    wp,wq=fk(SKEL,p,q)
    body_delta=qmul(wq[2],qinv(WQ0[2]))
    for index,(upper,lower,end) in flight:
        coefficient=.15 if stem=='bs01' and index<2 else .65 if stem=='bs02' and index<2 else .52
        compression=1.-coefficient*min(1.,tuck/68.)
        vector=qrotate(body_delta,WP0[end]-WP0[upper])*compression
        target=wp[upper]+vector
        pole=qrotate(body_delta,WP0[lower]-WP0[upper])
        if stem=='bs01':
            # Airborne limbs must clear the floor even as the trunk settles.
            # A neutral-height knee pole folds the rear leg upward rather than
            # letting its fur/toes sweep through the ground before contact.
            target[1]=max(target[1],WP0[end,1]+.08)
            knee_pole=WP0[lower]+FORWARD*travel+np.array([0,max(h,0)*.5,0])
            pole=knee_pole-wp[upper]
        footq=qmul(body_delta,WQ0[end])
        if stem=='bs02' and index<2 and f>=36:
            aim=min(1.,(f-36)/6.)
            footq=slerp(footq,qmul(euler(-20,0,0),WQ0[end]),aim)
        q,_,_=solve_leg(SKEL,p,q,upper,lower,end,target,
                        pole_vector=pole,foot_world_rotation=footq)
    for index,(upper,lower,end),target in active:
        # Leave limbs curled and free in flight, then reach for the floor.
        # Existing neutral knee gives a stable anatomical pole plane.
        pole=WP0[lower]-WP0[upper]
        q,achieved,error=solve_leg(SKEL,p,q,upper,lower,end,target,
            pole_vector=pole,foot_world_rotation=WQ0[end])
        errors.append({'leg':index,'error':error,'target':target.tolist(),
                       'achieved':achieved.tolist()})
    return p,q,errors


def author(stem,phase):
    original=read(SRC/f'chr424857_{stem}.anim')
    out=deepcopy(original);n=int(phase[-1][0])+1
    for kind in ('positions','rotations','scales'):
        setattr(out,kind,{b:{} for b in range(52)})
    diagnostics=[];last=Q0.copy()
    for f in range(n):
        p,q,errors=pose(stem,phase,f)
        for b in range(50):
            if np.dot(last[b],q[b])<0:q[b]=-q[b]
            if NEUTRAL.positions[b]:out.positions[b][f]=p[b].tolist()
            # Bone 0/1 static identity rotations stay omitted.
            if NEUTRAL.rotations[b] or b in (2,7):out.rotations[b][f]=q[b].tolist()
        last=q
        diagnostics.append({'frame':f,'feet':errors})
    rebuilt=write(out,DST/f'chr424857_{stem}.anim',preserve_duration=False,expected_bones=52)
    maxerr=max((e['error'] for r in diagnostics for e in r['feet']),default=0)
    return {'stem':stem,'frames':n,'duration':rebuilt._source_duration,
            'max_ik_target_error':maxerr,'frames_diagnostics':diagnostics,
            'phase_columns':['height','travel','body_pitch','body_yaw','body_roll',
                'chest_pitch','chest_yaw','head_pitch','head_yaw','head_roll','jaw','tuck'],
            'poses':phase}


def camera(stem,side,phase):
    path=f'cam_chr424857_{stem}_{side}.anim';original=read(SRC/path)
    out=deepcopy(original);n=int(phase[-1][0])+1
    original=read(SRC/f'cam_chr424857_bs01_{side}.anim')
    out.positions[0]={};out.rotations[0]={};out.float_channels[0]={}
    sign=1 if side=='pc' else -1
    previous=None
    for f in range(n):
        v=curve(phase,f);h,travel=v[:2]
        travel=travel*(4.14/(1.02 if stem=='bs01' else 1.50)) if travel>0 else travel
        if (stem=='bs01' and f>=33) or (stem=='bs02' and f>=47):travel=4.14
        # Low three-quarter view exposes the tooth sweep. A wider/high shot
        # follows the elevated body; no constant orbit hides the contact.
        if stem=='bs01':
            cam=np.array([sign*3.5,1.85,4.8])+FORWARD*travel*.85;target=np.array([0,1.0,.50])+FORWARD*travel
            fov=44.
        else:
            cam=np.array([sign*4.0,2.5+max(h,0)*.60,6.0])+FORWARD*travel*.85
            target=np.array([0,1.10+max(h,0)*.8,.2])+FORWARD*travel
            fov=48.
        quat=look_quat(cam,target)
        # Smooth source camera entry/exit without repeatedly easing every pose.
        if f<9:
            t=f/9;t=t*t*(3-2*t)
            op,oq,_=sample(original,0,0);cam=op*(1-t)+cam*t;quat=slerp(oq,quat,t)
            fov=float(sample_track(original.float_channels[0],0))*(1-t)+fov*t
        elif f>n-10:
            t=(f-(n-10))/9;t=t*t*(3-2*t)
            op,oq,_=sample(original,0,original._source_frame_count-1)
            cam=cam*(1-t)+op*t;quat=slerp(quat,oq,t)
            fov=fov*(1-t)+float(sample_track(original.float_channels[0],original._source_frame_count-1))*t
        if previous is not None and np.dot(previous,quat)<0:quat=-quat
        previous=quat
        out.positions[0][f]=cam.tolist();out.rotations[0][f]=quat.tolist();out.float_channels[0][f]=fov
    # Retained nonanimated channels stay intact; both cameras now match actor clip.
    write(out,DST/path,preserve_duration=False)


def main():
    if not DST.exists():raise SystemExit('Create modified_v2 from the reviewed first-pass data first')
    results=[]
    for stem,phase in [('bs01',GROUND),('bs02',HIGHLAND)]:
        result=author(stem,phase);results.append(result)
        for side in ('pc','em'):camera(stem,side,phase)
        print(stem,result['frames'],'frames, max IK error',round(result['max_ik_target_error'],6),flush=True)
    REPORT.parent.mkdir(exist_ok=True,parents=True)
    REPORT.write_text(json.dumps({'revision':2,'forward':FORWARD.tolist(),'clips':results},indent=2))

if __name__=='__main__':main()
