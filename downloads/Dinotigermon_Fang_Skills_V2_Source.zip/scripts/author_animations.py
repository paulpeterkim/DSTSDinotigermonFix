"""Author two fang attack motions with the requested branch's animation codec.

All positions are game Y-up, rotations XYZW. Keep skeletons, geometry, textures,
float channels, animation masks, playback rates, and original clip durations.
The choreography controls Dinotigermon only; victim reactions are engine-owned.
"""
from pathlib import Path
from copy import deepcopy
import math
import json
import numpy as np
from anim_codec import read, write, sample_track, sample, slerp, normalize_quat

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'original/dsts-loader/patch'
DEST=ROOT/'modified/dsts-loader/patch'


def qmul(a,b):
    ax,ay,az,aw=a;bx,by,bz,bw=b
    return normalize_quat([aw*bx+ax*bw+ay*bz-az*by,
                           aw*by-ax*bz+ay*bw+az*bx,
                           aw*bz+ax*by-ay*bx+az*bw,
                           aw*bw-ax*bx-ay*by-az*bz])


def euler(x=0,y=0,z=0):
    x,y,z=np.radians([x,y,z])/2
    return qmul(qmul([math.sin(x),0,0,math.cos(x)],
                     [0,math.sin(y),0,math.cos(y)]),
                     [0,0,math.sin(z),math.cos(z)])


def keys_sample(keys,f):
    if f<=keys[0][0]:return np.array(keys[0][1:],dtype=float)
    for a,b in zip(keys,keys[1:]):
        if f<=b[0]:
            u=(f-a[0])/(b[0]-a[0]);u=u*u*(3-2*u)
            return np.array(a[1:])*(1-u)+np.array(b[1:])*u
    return np.array(keys[-1][1:],dtype=float)

# frame, body height, forward approach, crouch, head pitch, head yaw,
# jaw opening, torso pitch, foreleg reach, hindleg tuck, body yaw.
GROUND=[
(0,   0,    0,    0,   0,   0,  0,  0,   0,   0, 0),
(6, -.20, -.13,    1, -12,   0, 18, -3,  12,  20, 0),
(12, .16,  .38,  .20, -10,   0, 32, -8, -32,  30, 0),
(18,-.10,  .78,  .70,   8,   0, 30,  3, -18,  10, 0),
(23,-.04,  .84,  .85,  24,   0, -6,  5, -15,   5, 0),
(27,-.04,  .82,  .85,  18, -28, -5,  4, -15,   5,-3),
(32,-.04,  .80,  .85,  22,  25, -5,  4, -15,   5, 3),
(37,-.10,  .65,  .65,  -6,  -8,  5, -8, -10,  10, 0),
(44,-.08,  .25,  .25,  -3,   0,  5, -3,  -5,   5, 0),
(55,  0,    0,    0,   0,   0,  0,  0,   0,   0, 0),
]
HIGHLAND=[
(0,   0,    0,    0,   0, 0,  0,  0,   0,   0, 0),
(7, -.26, -.10,    1, -18, 0, 18, -8,   8,  35, 0),
(13,1.15,  .18,  .20, -26, 0, 32,-14, -30,  48, 0),
(19,1.85,  .35,    0, -30, 0, 36,-14, -35,  55, 0),
(23,1.65,  .50,    0, -12, 0, 28, -5, -22,  42, 0),
(29, .30,  .78,  .65,  32, 0, -5, 12,  -8,  12, 0),
(32,-.06,  .82,  .85,  20, 0, -6,  6, -12,   5, 0),
(37,-.06,  .67,  .55,  12, 0, -4,  4,  -5,   5, 0),
(44,-.04,  .32,  .15,  -4, 0,  7, -4,   0,   4, 0),
(56,  0,    0,    0,   0, 0,  0,  0,   0,   0, 0),
]


def author_actor(stem,phase):
    original=read(SOURCE/f'chr424857_{stem}.anim',expected_bones=52)
    neutral=read(SOURCE/'chr424857_bn01.anim',expected_bones=52)
    out=deepcopy(original)
    n=original._source_frame_count
    # Use the supplied idle stance as a coherent base for all limb chains.
    # Preserve empty channels and masked geometry bones, rather than inventing
    # scales or visibility changes for the skin.
    for kind in ('positions','rotations','scales'):
        dest=getattr(out,kind);src=getattr(neutral,kind)
        for b,track in src.items():
            if b>=50 or not track:
                dest[b]={}
            else:
                dest[b]={f:sample_track(track, f*50/(n-1),quaternion=kind=='rotations').tolist()
                         for f in range(n)}
    for f in range(n):
        h,forward,crouch,head,yaw,jaw,torso,reach,tuck,body_yaw=keys_sample(phase,f)
        # Keep travel modest and return exactly to the supplied idle position.
        out.positions[2][f]=np.asarray(out.positions[2][f])+[0,h,forward]
        changes={
            2:(0,body_yaw,0),3:(torso*.35,0,0),4:(torso*.25,0,0),
            5:(torso*.40,0,0),6:(head,yaw,0),7:(jaw,0,0),
            24:(reach*.45,0,-crouch*3),29:(reach*.45,0,crouch*3),
            25:(reach*.55,0,0),30:(reach*.55,0,0),
            26:(-crouch*28,0,0),31:(-crouch*28,0,0),
            27:(crouch*12-reach*.4,0,0),32:(crouch*12-reach*.4,0,0),
            34:(-torso*.4,0,0),
            40:(tuck*.2,0,0),45:(tuck*.2,0,0),
            41:(tuck*.8+crouch*10,0,0),46:(tuck*.8+crouch*10,0,0),
            42:(-tuck*.65-crouch*18,0,0),47:(-tuck*.65-crouch*18,0,0),
            43:(tuck*.15+crouch*5,0,0),48:(tuck*.15+crouch*5,0,0),
        }
        # Small delayed mane and tail response accompanies acceleration.
        lag=keys_sample(phase,max(0,f-2))
        for bone in (8,9,10,11):changes[bone]=(-head*.12, -yaw*.18, 0)
        for bone in (35,36,37,38,39):changes[bone]=(-lag[6]*.12, -body_yaw*.4,0)
        for bone,angles in changes.items():
            base=out.rotations[bone].get(f,[0,0,0,1])
            out.rotations[bone][f]=qmul(base,euler(*angles)).tolist()
    rebuilt=write(out,DEST/f'chr424857_{stem}.anim',expected_bones=52)
    return {'file':f'chr424857_{stem}.anim','frames':n,'fps':rebuilt.playback_rate,
            'duration':rebuilt._source_duration,'phases':phase}


def look_quat(position,target):
    back=np.asarray(position)-np.asarray(target);back/=np.linalg.norm(back)
    right=np.cross([0.,1.,0.],back);right/=np.linalg.norm(right)
    up=np.cross(back,right)
    m=np.stack((right,up,back),axis=1)
    # The chosen views never reach a 180-degree rotation; use the stable
    # positive-trace branch and validate the result through normalization.
    w=math.sqrt(max(0,1+np.trace(m)))/2
    if w<1e-6:raise ValueError('Unsupported 180-degree camera orientation')
    return normalize_quat([(m[2,1]-m[1,2])/(4*w),
                           (m[0,2]-m[2,0])/(4*w),
                           (m[1,0]-m[0,1])/(4*w),w])


def author_camera(stem,side,phase):
    path=f'cam_chr424857_{stem}_{side}.anim'
    original=read(SOURCE/path)
    out=deepcopy(original);n=original._source_frame_count
    # Keep original entry/exit poses and FOV; frame the new motion between them.
    sign=(1 if side=='pc' else -1) * (-1 if stem=='bs01' else 1)
    start_p,start_q,_=sample(original,0,0)
    end_p,end_q,_=sample(original,0,n-1)
    start_fov=sample_track(original.float_channels[0],0)
    end_fov=sample_track(original.float_channels[0],n-1)
    out.positions[0]={};out.rotations[0]={};out.float_channels[0]={}
    for f in range(n):
        h,travel,*_=keys_sample(phase,f)
        pos=np.array([sign*3.6,2.3+max(h,0)*.65,5.3])
        target=np.array([0.,1.05+max(h,0)*.75,.35+travel*.35])
        quat=look_quat(pos,target);fov=48.
        if f<10:
            t=f/10;t=t*t*(3-2*t)
            pos=start_p*(1-t)+pos*t;quat=slerp(start_q,quat,t)
            fov=float(start_fov)*(1-t)+48*t
        elif f>n-10:
            t=(f-(n-10))/9;t=t*t*(3-2*t)
            pos=pos*(1-t)+end_p*t;quat=slerp(quat,end_q,t)
            fov=48*(1-t)+float(end_fov)*t
        out.positions[0][f]=pos.tolist();out.rotations[0][f]=quat.tolist()
        out.float_channels[0][f]=fov
    write(out,DEST/path)
    return path


def main():
    if not DEST.is_dir():raise SystemExit('Run patch_skills.py --disable-highland-effect first')
    report=[]
    for stem,phase in [('bs01',GROUND),('bs02',HIGHLAND)]:
        report.append(author_actor(stem,phase))
        for side in ('pc','em'):author_camera(stem,side,phase)
    p=ROOT/'work/choreography.json';p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,indent=2))
    print('Authored and round-trip validated 2 attack clips and 4 camera clips.')

if __name__=='__main__':main()
