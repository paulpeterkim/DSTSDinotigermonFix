"""Read-only Blender diagnostics for head/jaw and approximate fang clearance.

Run with Blender --background --python scripts/check_clearance.py -- [scene.blend].
The saved scene is not changed. Geometry is evaluated using the authored actions
with all NLA strips muted, exactly as in the preview renderer. The fang subset is
a geometric proxy from neutral head/jaw weighted vertices, not a semantic mesh ID.
"""
import json
from pathlib import Path
import sys

import bpy

ROOT = Path(__file__).resolve().parents[1]
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
scene_path = Path(args[0]) if args else ROOT / "outputs/Dinotigermon_Fang_Attacks.blend"
bpy.ops.wm.open_mainfile(filepath=str(scene_path))
scene = bpy.context.scene
armature = bpy.data.objects["chr424857"]
for track in armature.animation_data.nla_tracks:
    track.mute = True
floor = bpy.data.objects.get("PreviewFloor")
floor_z = floor.location.z if floor else -0.04
meshes = [obj for obj in bpy.data.objects
          if obj.type == "MESH" and obj.parent == armature and obj.name != "outline"]
armature.animation_data.action = bpy.data.actions["chr424857_bs01"]
scene.frame_set(1)
depsgraph = bpy.context.evaluated_depsgraph_get()


def world_vertices(obj):
    evaluated = obj.evaluated_get(depsgraph)
    return [evaluated.matrix_world @ vertex.co for vertex in evaluated.data.vertices]


selected = {}
for obj in meshes:
    indices = {name: obj.vertex_groups[name].index for name in ("J_atama", "J_ago")
               if name in obj.vertex_groups}
    head, jaw = [], []
    for vertex in obj.data.vertices:
        weights = {group.group: group.weight for group in vertex.groups}
        if weights.get(indices.get("J_atama", -1), 0) >= 0.5:
            head.append(vertex.index)
        if weights.get(indices.get("J_ago", -1), 0) >= 0.5:
            jaw.append(vertex.index)
    points = world_vertices(obj)
    all_indices = sorted(set(head + jaw))
    if not all_indices:
        continue
    # In imported Blender coordinates, forward is -Y and up is +Z. Select the
    # forward/lower head region as a reproducible proxy for the fang tips.
    low_z = min(points[index].z for index in all_indices)
    high_z = max(points[index].z for index in all_indices)
    near_y = min(points[index].y for index in all_indices)
    far_y = max(points[index].y for index in all_indices)
    fang = [index for index in all_indices
            if points[index].z <= low_z + (high_z - low_z) * 0.35
            and points[index].y <= near_y + (far_y - near_y) * 0.55]
    selected[obj.name] = {"head": head, "jaw": jaw, "fang_proxy": fang}
    print("SELECTION", obj.name, {key: len(value) for key, value in selected[obj.name].items()},
          "neutral head bounds", (near_y, far_y, low_z, high_z))

report = {"scene": str(scene_path), "floor_z": floor_z,
          "note": "Fang proxy is a neutral-space geometric subset of head/jaw-weighted vertices.",
          "actions": {}}
for stem in ("bs01", "bs02"):
    action = bpy.data.actions["chr424857_" + stem]
    armature.animation_data.action = action
    results = []
    last_frame = round(action.frame_range[1]) - 1
    for frame in range(last_frame + 1):
        scene.frame_set(frame + 1)
        positions = {obj.name: world_vertices(obj) for obj in meshes if obj.name in selected}
        row = {"frame": frame}
        for region in ("head", "jaw", "fang_proxy"):
            values = [(positions[name][index].z - floor_z, name, index)
                      for name, sets in selected.items() for index in sets[region]]
            if values:
                clearance, mesh_name, vertex = min(values)
                row[region] = {"clearance": clearance, "mesh": mesh_name, "vertex": vertex}
        results.append(row)
    report["actions"][stem] = results
    print("ACTION", stem)
    for frame in ([0, 6, 12, 18, 23, 27, 32, 37, 55] if stem == "bs01"
                  else [0, 7, 13, 19, 23, 29, 32, 37, 56]):
        row = results[frame]
        print(frame, {region: round(data["clearance"], 5)
                      for region, data in row.items() if region != "frame"})
    for region in ("head", "jaw", "fang_proxy"):
        candidates = [row for row in results if region in row]
        if not candidates:
            print("UNWEIGHTED", region)
            continue
        worst = min(candidates, key=lambda row: row[region]["clearance"])
        print("WORST", region, worst["frame"], worst[region])
output = ROOT / "work/clearance.json"
output.write_text(json.dumps(report, indent=2))
print("SAVED", str(output))
