import bpy,sys,os,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
root=Path(os.environ.get('DSCS_TOOLS_ROOT','/workspace/tools/blender-dscs'))
spec=importlib.util.spec_from_file_location('dscs_tools',root/'__init__.py',submodule_search_locations=[str(root)])
m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m;spec.loader.exec_module(m)
from dscs_tools.src.BlenderIO.Import.ImportTimeStrangerGeom import import_ts_geom
from dscs_tools.src.BlenderIO.Logging import ImportErrorLog
sys.path.insert(0,str(Path(__file__).parent))
from geom_preview import install_blender_preview_patch
import_ts_geom=install_blender_preview_patch('dscs_tools')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
import_ts_geom(str(ROOT/'original/dsts-loader/patch/chr424857.geom'),ImportErrorLog())
print('OBJECTS',[(o.name,o.type) for o in bpy.data.objects])
print('ACTIONS',[(a.name,tuple(a.frame_range)) for a in bpy.data.actions])
(ROOT/'work').mkdir(exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'work/original.blend'))
