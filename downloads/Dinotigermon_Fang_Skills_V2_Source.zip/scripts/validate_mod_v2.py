#!/usr/bin/env python3
"""Offline validation of the second-pass fang choreography and game assets.

V2 intentionally extends Ground Fang to 120 frames and Highland Fang to 96.
It preserves each original playback rate, skeleton, metadata and skill data.
Structural/plant checks do not establish victim contact or runtime behavior.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import traceback
import zipfile

import numpy as np

import anim_codec
from motion_math import fk, qrotate, normalize
from patch_skills import GROUND_FANG_ID, HIGHLAND_FANG_ID, SKILL_TABLE, STATUS_TABLE, TEXT
from validate_mod import ANIMATIONS, check, sha256, inventory, parse_typed_csv

FRAMES = {"bs01": 120, "bs02": 96}
FOOT_BONES = {0: 27, 1: 32, 2: 43, 3: 48}
# Quaternions are packed to roughly4e-5 component steps. Chain FK can differ
# by a few1e-4 units between independently quantized frames, even with exactly
# fixed authored targets. Bound physical jitter to0.001 model units; report the
# actual errors instead of describing the compressed foot positions as exact.
COMPRESSION_TOLERANCE = 0.001
NEUTRAL_TOLERANCE = 0.001
FINAL_APPROACH = 4.14


def pose_arrays(anim, frame):
    sampled = [anim_codec.sample(anim, bone, frame) for bone in range(anim.bone_count)]
    positions = np.asarray([value[0] for value in sampled], dtype=float)
    rotations = np.asarray([value[1] for value in sampled], dtype=float)
    scales = np.asarray([value[2] for value in sampled], dtype=float)
    return positions, rotations, scales


def equal_tracks(left, right):
    if set(left) != set(right):
        return False
    return all(np.array_equal(left[key], right[key]) for key in left)


def validate_static_assets(source, v1, modified, report, original_zip=None):
    before, first, after = inventory(source), inventory(v1), inventory(modified)
    checks = report["checks"]
    if original_zip is not None:
        with zipfile.ZipFile(original_zip) as archive:
            check(archive.testzip() is None, "Uploaded archive CRC mismatch")
            names = {entry.filename for entry in archive.infolist() if not entry.is_dir()}
            check(names == {path.as_posix() for path in before},
                  "Original directory does not contain exactly the uploaded files")
            for relative, path in before.items():
                expected = hashlib.sha256(archive.read(relative.as_posix())).hexdigest()
                check(sha256(path) == expected, f"Original differs from upload: {relative}")
        checks.append({"name": "uploaded_archive_integrity", "passed": True,
                       "files": len(before)})
    locales = sorted(path.relative_to(source)
                     for path in (source / "dsts-loader").glob("patch_text*") if path.is_dir())
    check(len(locales) == 11, "Expected exactly the 11 original locale folders")
    text_paths = {locale / "text" / table / "000_Sheet1.ap.csv"
                  for locale in locales
                  for table in ("skill_name.mbe", "skill_explanation.mbe")}
    allowed = {SKILL_TABLE, STATUS_TABLE, *ANIMATIONS, *text_paths}
    check(not (set(before) - set(after)), "Original files were removed")
    check(set(first) == set(after), "V2 added or removed files relative to V1")
    changes = []
    preserved = 0
    for relative in sorted(set(before) | set(after)):
        old_hash = sha256(before[relative]) if relative in before else None
        new_hash = sha256(after[relative]) if relative in after else None
        if old_hash != new_hash:
            check(relative in allowed, f"Unexpected modification: {relative}")
            changes.append({"path": relative.as_posix(),
                            "status": "added" if old_hash is None else "modified",
                            "original_sha256": old_hash, "modified_sha256": new_hash})
        else:
            preserved += 1
        # This is a motion revision, not an unrelated data/balance revision.
        if relative not in ANIMATIONS:
            check(sha256(first[relative]) == new_hash,
                  f"Non-animation asset differs from reviewed V1: {relative}")
    report["file_changes"] = changes
    report["preserved_original_files"] = preserved
    report["modified_file_count"] = len(after)
    checks.append({"name": "only_allowed_assets_changed_and_v1_data_retained",
                   "passed": True, "changed": len(changes), "preserved": preserved})
    protected = [path for path in before
                 if path.suffix in (".geom", ".nlst", ".img") or "images" in path.parts]
    for relative in protected:
        check(sha256(before[relative]) == sha256(after[relative]),
              f"Model, skeleton list, or texture changed: {relative}")
    checks.append({"name": "geometry_skeleton_lists_textures_preserved", "passed": True,
                   "files": len(protected)})

    tables = {path.relative_to(modified): parse_typed_csv(path)
              for path in sorted(modified.rglob("*.ap.csv"))}
    checks.append({"name": "all_append_csv_types_widths_and_keys", "passed": True,
                   "tables": len(tables), "rows": sum(len(rows) for _, rows in tables.values())})
    skills = {row[0]: row for row in tables[SKILL_TABLE][1]}
    check(set(skills) == {GROUND_FANG_ID, HIGHLAND_FANG_ID},
          "Expected exactly two independent custom skills")
    original_rows = parse_typed_csv(source / SKILL_TABLE)[1]
    template = next(row for row in original_rows if row[0] == HIGHLAND_FANG_ID)
    for skill_id, animation, target in ((GROUND_FANG_ID, "3", "1"),
                                         (HIGHLAND_FANG_ID, "4", "5")):
        row = skills[skill_id]
        check(all(row[index] == skill_id for index in (0, 4, 5, 6)),
              f"Skill ID/name/description/internal key mismatch: {skill_id}")
        check(row[10] == animation and row[33] == target,
              f"Wrong animation or target for skill {skill_id}")
        check(row[29] == "-1" and row[54] == "0",
              f"Unrelated inherited trait bonus or buff remains: {skill_id}")
        check(all(row[index] == template[index] for index in (11, 22, 23, 34, 35, 36)),
              f"Inherited damage/hit timing/hit count/SP baseline changed: {skill_id}")
        check(row[12] == "0", f"An old main particle effect remains: {skill_id}")
    status_header, status_rows = tables[STATUS_TABLE]
    original_header, original_status_rows = parse_typed_csv(source / STATUS_TABLE)
    status = next(row for row in status_rows if row[0] == "55057")
    original_status = next(row for row in original_status_rows if row[0] == "55057")
    check(status_header == original_header, "Digimon status header changed")
    check(status[72] == status[126] == GROUND_FANG_ID and status[75] == HIGHLAND_FANG_ID,
          "Dinotigermon skill slots/default skill disagree")
    check(all(left == right for index, (left, right) in enumerate(zip(original_status, status))
              if index not in (72, 75, 126)), "Unrelated Digimon status values changed")
    checks.append({"name": "custom_skill_assignments_and_inherited_balance", "passed": True})
    for locale in locales:
        for table, value_index in (("skill_name.mbe", 1), ("skill_explanation.mbe", 2)):
            rows = tables[locale / "text" / table / "000_Sheet1.ap.csv"][1]
            check(len(rows) == 2 and dict(rows) == {entry[0]: entry[value_index] for entry in TEXT},
                  f"Skill name/description mismatch: {locale}/{table}")
    checks.append({"name": "exact_skill_names_and_descriptions", "passed": True,
                   "locales": len(locales), "language": "English fallback"})


def validate_animations(source, v1, modified, report):
    animations = {}
    results = []
    for relative, expected_bones in ANIMATIONS.items():
        original = anim_codec.read(source / relative, expected_bones=expected_bones)
        previous = anim_codec.read(v1 / relative, expected_bones=expected_bones)
        edited = anim_codec.read(modified / relative, expected_bones=expected_bones)
        stem = "bs01" if "_bs01" in relative.name else "bs02"
        frames = FRAMES[stem]
        check(edited.bone_count == original.bone_count,
              f"Animation bone count changed: {relative}")
        check(edited._source_frame_count == frames, f"Wrong V2 frame count: {relative}")
        check(edited.playback_rate == original.playback_rate,
              f"Playback rate changed: {relative}")
        expected_duration = (frames - 1) / original.playback_rate
        check(math.isclose(edited._source_duration, expected_duration, rel_tol=0, abs_tol=1e-5),
              f"Header duration disagrees with deliberate V2 frame count/rate: {relative}")
        for field in ("float_channel_count", "bone_blend_factors",
                      "float_channel_blend_factors", "unknown_section"):
            check(np.array_equal(getattr(original, field), getattr(edited, field)),
                  f"Nonanimated metadata changed ({field}): {relative}")
        anim_codec.validate(edited, expected_bones=original.bone_count, expected_frames=frames)
        check(sha256(v1 / relative) != sha256(modified / relative),
              f"V2 animation is byte-identical to V1: {relative}")
        if expected_bones == 52:
            for bone in range(edited.bone_count):
                check(equal_tracks(original.scales[bone], edited.scales[bone]),
                      f"Actor scale track changed despite unit-scale FK assumptions: {relative}, bone {bone}")
            # Compare poses at equal normalized phases as well as byte hashes;
            # a mere duration/header rewrite is not a choreography revision.
            greatest_position_change = greatest_rotation_change = 0.
            for phase in np.linspace(0, 1, 21):
                old_p, old_q, _ = pose_arrays(previous, phase * (previous._source_frame_count - 1))
                new_p, new_q, _ = pose_arrays(edited, phase * (frames - 1))
                greatest_position_change = max(greatest_position_change,
                                               float(np.max(np.linalg.norm(old_p - new_p, axis=1))))
                dots = np.clip(np.abs(np.sum(old_q * new_q, axis=1)), 0, 1)
                greatest_rotation_change = max(greatest_rotation_change,
                                               float(np.max(2 * np.arccos(dots))))
            check(greatest_position_change > 0.02 and greatest_rotation_change > 0.05,
                  f"V2 lacks a substantive transform change from V1: {relative}")
            animations[stem] = edited
        else:
            # Only the documented camera root position/rotation/FOV channels
            # may change. Retain other camera bones and scale channels exactly.
            for bone in range(original.bone_count):
                check(equal_tracks(original.scales[bone], edited.scales[bone]),
                      f"Camera scale track changed: {relative}, bone {bone}")
                if bone != 0:
                    for kind in ("positions", "rotations"):
                        check(equal_tracks(getattr(original, kind)[bone], getattr(edited, kind)[bone]),
                              f"Unexpected secondary camera track changed: {relative}")
            check(set(original.float_channels) == set(edited.float_channels),
                  f"Camera float-channel identity changed: {relative}")
            for index in original.float_channels:
                if index != 0:
                    check(equal_tracks(original.float_channels[index], edited.float_channels[index]),
                          f"Unexpected camera float channel changed: {relative}, {index}")
        results.append({"path": relative.as_posix(), "bones": edited.bone_count,
                        "frames": frames, "playback_rate": edited.playback_rate,
                        "header_span_seconds": float(edited._source_duration),
                        "frame_sequence_seconds": frames / edited.playback_rate,
                        "original_frames": original._source_frame_count,
                        "v1_frames": previous._source_frame_count,
                        "metadata_preserved": True})
    check(set(animations) == set(FRAMES), "Missing V2 actor clip")
    report["checks"].append({"name": "v2_animation_transforms_metadata_and_deliberate_timing",
                             "passed": True, "animations": results,
                             "note": "V2 durations are intentionally extended, not preserved from V1."})
    return animations


def validate_neutral_and_plants(source, animations, diagnostics_path, report):
    skeleton = anim_codec.read_embedded_skeleton(source / "dsts-loader/patch/chr424857.geom")
    neutral = anim_codec.read(source / "dsts-loader/patch/chr424857_bn01.anim", expected_bones=52)
    neutral_p, neutral_q, neutral_s = pose_arrays(neutral, 0)
    _, neutral_world_q = fk(skeleton, neutral_p, neutral_q)
    approach_direction = qrotate(neutral_world_q[6], [0, 0, 1])
    approach_direction[1] = 0
    approach_direction = normalize(approach_direction)
    endpoints = []
    world = {}
    for stem, edited in animations.items():
        for frame in (0, FRAMES[stem] - 1):
            p, q, s = pose_arrays(edited, frame)
            expected_p = neutral_p.copy()
            if frame == FRAMES[stem] - 1:
                expected_p[2] += approach_direction * FINAL_APPROACH
            position_error = float(np.max(np.abs(p - expected_p)))
            rotation_error = float(np.max(np.minimum(np.linalg.norm(q - neutral_q, axis=1),
                                                     np.linalg.norm(q + neutral_q, axis=1))))
            scale_error = float(np.max(np.abs(s - neutral_s)))
            check(max(position_error, rotation_error, scale_error) <= NEUTRAL_TOLERANCE,
                  f"V2 endpoint does not match neutral articulation/approach position: {stem}, frame {frame}")
            endpoints.append({"stem": stem, "frame": frame, "position_error": position_error,
                              "quaternion_error": rotation_error, "scale_error": scale_error})
        world[stem] = []
        for frame in range(FRAMES[stem]):
            p, q, _ = pose_arrays(edited, frame)
            wp, _ = fk(skeleton, p, q)
            check(np.isfinite(wp).all(), f"Nonfinite forward kinematics: {stem}, {frame}")
            world[stem].append(wp)
    report["checks"].append({"name": "neutral_articulation_with_original_style_close_range_endpoint", "passed": True,
                             "tolerance": NEUTRAL_TOLERANCE,
                             "final_approach_distance": FINAL_APPROACH,
                             "approach_direction": approach_direction.tolist(), "endpoints": endpoints})
    diagnostics = json.loads(diagnostics_path.read_text())
    check(diagnostics.get("revision") == 2, "IK diagnostics do not describe V2")
    clips = diagnostics.get("clips", [])
    check({clip["stem"] for clip in clips} == set(FRAMES) and len(clips) == 2,
          "IK diagnostics do not contain both V2 clips exactly once")
    ground_diagnostics = next(clip for clip in clips if clip["stem"] == "bs01")
    ground_rows = {row["frame"]: row for row in ground_diagnostics["frames_diagnostics"]}
    plants = []
    for leg, bone in ((0, FOOT_BONES[0]), (1, FOOT_BONES[1])):
        points = np.asarray([world["bs01"][frame][bone] for frame in range(33, 71)])
        targets = np.asarray([next(foot["target"] for foot in ground_rows[frame]["feet"]
                                   if foot["leg"] == leg) for frame in range(33, 71)])
        check(np.isfinite(targets).all(), f"Nonfinite pin target: leg {leg}")
        raw_target_drift = float(np.max(np.linalg.norm(targets - targets[0], axis=1)))
        check(raw_target_drift <= 1e-12, f"Authored pin target actually moves: leg {leg}")
        displacement = np.linalg.norm(points - points[0], axis=1)
        maximum = float(np.max(displacement))
        maximum_pairwise = float(np.max(np.linalg.norm(points[:, None] - points[None, :], axis=2)))
        target_error = float(np.max(np.linalg.norm(points - targets, axis=1)))
        check(maximum_pairwise <= COMPRESSION_TOLERANCE and target_error <= COMPRESSION_TOLERANCE,
              f"Compressed planted foot exceeds bounded quaternion jitter: leg {leg}")
        check(maximum <= COMPRESSION_TOLERANCE,
              f"Ground Fang front ankle slides during the pin: leg {leg}, {maximum}")
        plants.append({"leg": leg, "bone": bone, "frames_inclusive": [33, 70],
                       "anchor": targets[0].tolist(), "raw_authored_target_drift": raw_target_drift,
                       "max_world_displacement_from_first_frame": maximum,
                       "max_pairwise_world_displacement": maximum_pairwise,
                       "max_compressed_error_from_exact_target": target_error})
    report["checks"].append({"name": "ground_front_ankles_stationary_during_pin", "passed": True,
                             "compression_tolerance": COMPRESSION_TOLERANCE, "plants": plants})

    results = []
    for clip in clips:
        stem = clip["stem"]
        check(clip["frames"] == FRAMES[stem], f"IK diagnostic frame count differs: {stem}")
        rows = clip["frames_diagnostics"]
        check([row["frame"] for row in rows] == list(range(FRAMES[stem])),
              f"Missing, duplicate, or unordered IK diagnostics: {stem}")
        max_authored = max_roundtrip = max_link_error = 0.
        targets = 0
        for row in rows:
            frame = row["frame"]
            seen = set()
            for foot in row["feet"]:
                leg = foot["leg"]
                check(leg in FOOT_BONES and leg not in seen,
                      f"Duplicate/invalid leg diagnostic: {stem}, {frame}")
                seen.add(leg)
                target = np.asarray(foot["target"], dtype=float)
                achieved = np.asarray(foot["achieved"], dtype=float)
                error = float(foot["error"])
                check(target.shape == achieved.shape == (3,) and
                      np.isfinite(target).all() and np.isfinite(achieved).all() and
                      math.isfinite(error) and error >= 0,
                      f"Invalid IK diagnostic values: {stem}, {frame}, {leg}")
                check(math.isclose(float(np.linalg.norm(achieved - target)), error,
                                   rel_tol=0, abs_tol=1e-8),
                      f"Authored IK target error disagrees with coordinates: {stem}, {frame}, {leg}")
                rebuilt = world[stem][frame][FOOT_BONES[leg]]
                max_authored = max(max_authored, error)
                max_roundtrip = max(max_roundtrip, float(np.linalg.norm(rebuilt - target)))
                max_link_error = max(max_link_error, float(np.linalg.norm(rebuilt - achieved)))
                targets += 1
            # Both attacks contain authored flight. Ground paws land in order;
            # Highland front paws brace before its rear paws. Require complete
            # stance diagnostics outside those explicit flight windows.
            if stem == "bs01":
                required = {leg for leg in FOOT_BONES
                            if not (17 if leg < 2 else 19) <= frame < (26 if leg < 2 else 32)}
            else:
                required = {leg for leg in FOOT_BONES
                            if not (19 if leg < 2 else 21) <= frame < (43 if leg < 2 else 48)}
            check(seen == required,
                  f"Stance diagnostics disagree with flight/landing phases: {stem}, {frame}")
        check(targets > 0, f"No actual IK targets checked: {stem}")
        declared = float(clip["max_ik_target_error"])
        check(math.isfinite(declared) and math.isclose(declared, max_authored, rel_tol=0, abs_tol=1e-8),
              f"IK maximum is nonfinite or stale: {stem}")
        check(max_authored <= 1e-6, f"Authored leg target is unreachable: {stem}, {max_authored}")
        check(max_roundtrip <= COMPRESSION_TOLERANCE and max_link_error <= COMPRESSION_TOLERANCE,
              f"Compressed clip no longer reaches its diagnostic targets: {stem}")
        results.append({"stem": stem, "targets_checked": targets,
                        "max_authored_target_error": max_authored,
                        "max_roundtrip_target_error": max_roundtrip,
                        "max_report_to_clip_error": max_link_error})
    report["checks"].append({"name": "all_authored_leg_targets_finite_reachable_and_linked_to_clip",
                             "passed": True, "diagnostics": str(diagnostics_path),
                             "compression_tolerance": COMPRESSION_TOLERANCE, "clips": results})


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=root / "original")
    parser.add_argument("--v1", type=Path, default=root / "modified")
    parser.add_argument("--modified", type=Path, default=root / "modified_v2")
    parser.add_argument("--diagnostics", type=Path, default=root / "work/v2/choreography.json")
    parser.add_argument("--report", type=Path, default=root / "outputs_v2/validation.json")
    parser.add_argument("--original-zip", type=Path)
    args = parser.parse_args()
    report = {"passed": False, "revision": 2, "validation_scope": "offline binary/data and planted-foot consistency",
              "source": str(args.source.resolve()), "v1": str(args.v1.resolve()),
              "modified": str(args.modified.resolve()), "checks": []}
    try:
        validate_static_assets(args.source, args.v1, args.modified, report, args.original_zip)
        animations = validate_animations(args.source, args.v1, args.modified, report)
        validate_neutral_and_plants(args.source, animations, args.diagnostics, report)
        report["passed"] = True
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    report["limitations"] = [
        "V2 deliberately extends Ground Fang to 120 frames and Highland Fang to 96 at the original frame rate; original clip durations are not preserved.",
        "Offline FK and ankle plants validate Dinotigermon's motion only, not an enemy constraint or synchronized victim reaction.",
        "A Windows game runtime is unavailable; actual battle spacing, engine hit timing, loader behavior, camera framing, and collisions remain untested in game.",
        "This script does not verify rendered head/fang clearance; that is checked separately in Blender.",
        "All existing locales use the requested English text as fallback.",
    ]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report.resolve()}")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
