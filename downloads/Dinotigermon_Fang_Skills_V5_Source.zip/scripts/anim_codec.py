"""Safe Time Stranger animation IO using Romsstar's feature/refactor codec.

The addon has no enabled Blender exporter on this branch. Its Hundred Line
animation codec is, however, also the codec used by its Time Stranger importer.
Load via ``read`` rather than AnimFileHundredLine.from_file: the latter inherits
the old Cyber Sleuth binary reader. Transform dictionaries use game parent-space
coordinates and XYZW quaternions, with integer keyframe numbers starting at 0.
No Blender installation is required; numpy is the only third-party dependency.
"""

from __future__ import annotations

from bisect import bisect_right
from copy import deepcopy
import importlib
import importlib.util
import math
import os
from pathlib import Path
import struct
import sys
import tempfile
from types import SimpleNamespace

import numpy as np


TOOLS_ROOT = Path(os.environ.get("DSCS_TOOLS_ROOT", "/workspace/tools/blender-dscs"))
TOOLS_COMMIT = "dfcef08a33f67abd5b96f0f121902c27060b7c57"
_PACKAGE = "dinotigermon_dscs_tools"


def _load_tools():
    if _PACKAGE not in sys.modules:
        if not (TOOLS_ROOT / "__init__.py").is_file():
            raise FileNotFoundError(
                f"Missing Blender-Tools-for-DSCS feature/refactor at {TOOLS_ROOT}; "
                "set DSCS_TOOLS_ROOT to an inspected checkout"
            )
        spec = importlib.util.spec_from_file_location(
            _PACKAGE, TOOLS_ROOT / "__init__.py",
            submodule_search_locations=[str(TOOLS_ROOT)],
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[_PACKAGE] = module
        spec.loader.exec_module(module)
    binary = importlib.import_module(f"{_PACKAGE}.src.filetypes.Anim.BinaryHundredLine")
    interface = importlib.import_module(f"{_PACKAGE}.src.filetypes.Anim.InterfaceHundredLine")
    return binary.AnimFileBinary, interface.AnimFileHundredLine


def normalize_quat(value):
    """Return a finite unit XYZW quaternion; reject a zero quaternion."""
    q = np.asarray(value, dtype=float)
    if q.shape != (4,) or not np.isfinite(q).all():
        raise ValueError(f"Invalid quaternion: {value!r}")
    norm = float(np.linalg.norm(q))
    if norm < 1e-12:
        raise ValueError("Zero quaternion")
    return q / norm


def slerp(left, right, factor):
    """Shortest-path spherical quaternion interpolation (XYZW)."""
    a, b = normalize_quat(left), normalize_quat(right)
    dot = float(np.dot(a, b))
    if dot < 0:
        b, dot = -b, -dot
    dot = float(np.clip(dot, -1, 1))
    if dot > 0.9995:
        return normalize_quat(a + factor * (b - a))
    angle = math.acos(dot)
    return normalize_quat(
        (math.sin((1 - factor) * angle) * a + math.sin(factor * angle) * b)
        / math.sin(angle)
    )


def sample_track(track, frame, default=None, *, quaternion=False):
    """Sample sorted keys with linear translation/scale or quaternion SLERP."""
    if not track:
        return deepcopy(default)
    keys = sorted(track)
    i = bisect_right(keys, frame)
    if i == 0:
        return np.asarray(track[keys[0]], dtype=float).copy()
    if i == len(keys):
        return np.asarray(track[keys[-1]], dtype=float).copy()
    before, after = keys[i - 1], keys[i]
    t = (float(frame) - before) / (after - before)
    a, b = np.asarray(track[before], dtype=float), np.asarray(track[after], dtype=float)
    return slerp(a, b, t) if quaternion else a + t * (b - a)


def sample(anim, bone, frame, rest=None):
    """Return (position, XYZW rotation, scale) for one parent-space bone.

    Empty channels represent unanimated channels. Supply a ``rest`` tuple to use
    the skeleton rest transform; otherwise identity defaults are used. This does
    not invent engine-specific blend/mask semantics.
    """
    p, q, s = rest or ((0., 0., 0.), (0., 0., 0., 1.), (1., 1., 1.))
    return (
        sample_track(anim.positions[bone], frame, p),
        sample_track(anim.rotations[bone], frame, q, quaternion=True),
        sample_track(anim.scales[bone], frame, s),
    )


def max_frame(anim):
    return max(
        (frame for attr in ("positions", "rotations", "scales", "float_channels")
         for track in getattr(anim, attr).values() if len(track) > 1
         for frame in track), default=0,
    )


def validate(anim, *, expected_bones=None, expected_frames=None):
    if expected_bones is not None and anim.bone_count != expected_bones:
        raise ValueError(f"Expected {expected_bones} bones; got {anim.bone_count}")
    if not math.isfinite(anim.playback_rate) or anim.playback_rate <= 0:
        raise ValueError("Invalid animation playback rate")
    for attr, width in (("positions", 3), ("rotations", 4), ("scales", 3)):
        channels = getattr(anim, attr)
        if set(channels) != set(range(anim.bone_count)):
            raise ValueError(f"{attr} does not cover exactly all bone indices")
        for bone, track in channels.items():
            for frame, value in track.items():
                if not isinstance(frame, (int, np.integer)) or not 0 <= frame < 65535:
                    raise ValueError(f"Invalid {attr} frame {frame!r}")
                a = np.asarray(value)
                if a.shape != (width,) or not np.isfinite(a).all():
                    raise ValueError(f"Invalid {attr} bone {bone} frame {frame}")
                if attr == "rotations" and abs(float(np.linalg.norm(a)) - 1) > 1e-3:
                    raise ValueError(f"Non-unit rotation bone {bone} frame {frame}")
    for channel, track in anim.float_channels.items():
        for frame, value in track.items():
            if not isinstance(frame, (int, np.integer)) or not 0 <= frame < 65535:
                raise ValueError(f"Invalid float-channel frame {frame!r}")
            if not np.isfinite(value).all():
                raise ValueError(f"Non-finite float channel {channel}")
    if not np.isfinite(anim.unknown_section).all():
        raise ValueError("Non-finite unknown animation section")
    if expected_frames is not None and max_frame(anim) + 1 != expected_frames:
        raise ValueError(f"Expected {expected_frames} frames; got {max_frame(anim) + 1}")


def read(path, *, expected_bones=None):
    Binary, Interface = _load_tools()
    binary = Binary()
    binary.read(str(path))
    anim = Interface.from_binary(binary)
    anim._source_frame_count = binary.frame_count
    anim._source_duration = binary.animation_duration
    anim._source_path = str(path)
    validate(anim, expected_bones=expected_bones, expected_frames=binary.frame_count)
    return anim


def validate_roundtrip(expected, actual, *, atol=8e-5):
    """Check meaningful transform and metadata preservation after compression."""
    for attr in ("bone_count", "float_channel_count", "playback_rate"):
        if getattr(expected, attr) != getattr(actual, attr):
            raise ValueError(f"Roundtrip changed {attr}")
    for attr in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
        if not np.array_equal(getattr(expected, attr), getattr(actual, attr)):
            raise ValueError(f"Roundtrip changed {attr}")
    if max_frame(expected) != max_frame(actual):
        raise ValueError("Roundtrip changed animation duration")
    for attr in ("positions", "rotations", "scales", "float_channels"):
        left, right = getattr(expected, attr), getattr(actual, attr)
        if set(left) != set(right):
            raise ValueError(f"Roundtrip changed {attr} channel indices")
        for idx in left:
            if set(left[idx]) != set(right[idx]):
                raise ValueError(f"Roundtrip changed {attr} channel {idx} keyframes")
            for frame, value in left[idx].items():
                a, b = np.asarray(value), np.asarray(right[idx][frame])
                if attr == "rotations" and np.dot(a, b) < 0:
                    b = -b
                if not np.allclose(a, b, rtol=0, atol=atol):
                    raise ValueError(f"Roundtrip changed {attr} channel {idx} frame {frame}")


def write(anim, path, *, preserve_duration=True, expected_bones=None):
    """Write atomically after parsing and validating the compressed result.

    By default preserve a read animation's frame count. Original authoring data
    is not modified: key dictionaries are sorted on a deep copy before encoding.
    """
    data = deepcopy(anim)
    for attr in ("positions", "rotations", "scales", "float_channels"):
        setattr(data, attr, {idx: dict(sorted(track.items()))
                            for idx, track in sorted(getattr(data, attr).items())})
    frames = getattr(anim, "_source_frame_count", None) if preserve_duration else None
    validate(data, expected_bones=expected_bones, expected_frames=frames)
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=target.name + ".", dir=target.parent,
                                     delete=False) as temp:
        temp_path = Path(temp.name)
    try:
        data.to_file(str(temp_path))
        rebuilt = read(temp_path, expected_bones=data.bone_count)
        validate_roundtrip(data, rebuilt)
        if frames is not None and rebuilt._source_frame_count != frames:
            raise ValueError("Roundtrip changed source frame count")
        if preserve_duration and hasattr(anim, "_source_duration"):
            if not math.isclose(anim._source_duration, rebuilt._source_duration,
                                rel_tol=2e-6, abs_tol=2e-6):
                raise ValueError("Roundtrip changed source duration in seconds")
        os.replace(temp_path, target)
    finally:
        temp_path.unlink(missing_ok=True)
    return rebuilt


def read_embedded_skeleton(path):
    """Read only a Time Stranger GEOM's declared skeleton, avoiding materials.

    Useful when strict material padding validation rejects an unrelated model
    material. The original GEOM is never altered and skeleton validation remains
    enabled. Returns a namespace with tool-compatible transform fields and a
    ``hierarchy_parents`` list derived from the explicit parent pairs. The
    source's misleadingly named ``bone_parents`` array is an index lookup in
    this model and is retained verbatim for callers that need it.
    """
    _load_tools()
    geom_module = importlib.import_module(f"{_PACKAGE}.src.filetypes.Geom.Binary.TimeStranger")
    raw = Path(path).read_bytes()
    size = struct.unpack_from("<Q", raw, 0x38)[0]
    start = struct.unpack_from("<Q", raw, 0x98)[0]
    if start <= 0 or size <= 0 or start + size != len(raw):
        raise ValueError("GEOM skeleton range is inconsistent with file size")
    block = raw[start:start + size]
    if block[:4] != b"60SE":
        raise ValueError("Expected embedded Time Stranger skeleton 60SE")
    declared_size = struct.unpack_from("<Q", block, 4)[0]
    bones, floats, vector_size = struct.unpack_from("<HHI", block, 0x10)
    if declared_size != size or vector_size != 2:
        raise ValueError("Invalid embedded skeleton header")
    pairs = struct.unpack_from("<I", block, 0x3C)[0]
    transform_offset = 0x18 + struct.unpack_from("<I", block, 0x18)[0]
    parent_offset = 0x1C + struct.unpack_from("<I", block, 0x1C)[0]
    hashes_offset = 0x20 + struct.unpack_from("<I", block, 0x20)[0]
    for offset, byte_count in ((0x40, pairs * 4),
                               (transform_offset, bones * 48),
                               (parent_offset, bones * 2),
                               (hashes_offset, bones * 4)):
        if not 0 <= offset <= offset + byte_count <= size:
            raise ValueError("Skeleton section is outside its declared block")
    transforms = []
    for index in range(bones):
        values = struct.unpack_from("<12f", block, transform_offset + index * 48)
        if not np.isfinite(values).all():
            raise ValueError("Non-finite skeleton transform")
        normalize_quat(values[:4])
        transforms.append(geom_module.BoneTransforms.from_transforms(
            list(values[:4]), list(values[4:8]), list(values[8:12])))
    vectors = [list(struct.unpack_from("<HH", block, 0x40 + i * 4))
               for i in range(pairs)]
    parents = list(struct.unpack_from(f"<{bones}h", block, parent_offset))
    hashes = list(struct.unpack_from(f"<{bones}I", block, hashes_offset))
    for parent in parents:
        if parent != -1 and not 0 <= parent < bones:
            raise ValueError("Invalid skeleton parent index")
    hierarchy = [-1] * bones
    seen = set()
    for child, parent in vectors:
        if child in seen or not 0 <= child < bones:
            raise ValueError("Duplicate or invalid skeleton child index")
        seen.add(child)
        parent = parent & 0x7FFF
        if parent != 0x7FFF:
            if not 0 <= parent < bones or parent == child:
                raise ValueError("Invalid skeleton hierarchy parent")
            hierarchy[child] = parent
    for child in range(bones):
        ancestors = set()
        while child != -1:
            if child in ancestors:
                raise ValueError("Cyclic skeleton hierarchy")
            ancestors.add(child)
            child = hierarchy[child]
    if floats:
        raise NotImplementedError("Standalone skeleton helper only supports zero float channels")
    return SimpleNamespace(bone_count=bones, float_channel_count=floats,
                           bone_parent_vectors=vectors, bone_parents=parents,
                           hierarchy_parents=hierarchy,
                           bone_name_hashes=hashes, bone_transforms=transforms,
                           float_channel_flags=[], float_channel_array_indices=[],
                           float_channel_object_name_hashes=[])
