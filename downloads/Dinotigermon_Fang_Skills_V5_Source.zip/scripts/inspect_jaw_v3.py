"""Inspect actual jaw weights/topology; optional Blender colored head closeups."""
from pathlib import Path
import collections
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'work/v3'
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT/'scripts'))
from geom_preview import read_geom


def components(mesh):
    vertices = mesh.unpack_vertices()
    points = np.array([v.position[:3] for v in vertices])
    keys = [tuple(np.round(p, 5)) for p in points]
    lookup = {}; canonical = [lookup.setdefault(k, i) for i, k in enumerate(keys)]
    parent = list(range(len(points)))
    def find(index):
        while parent[index] != index:
            parent[index] = parent[parent[index]]; index = parent[index]
        return index
    def union(a,b): parent[find(a)] = find(b)
    indices = list(mesh.index_buffer)
    for a,b,c in zip(indices[::3], indices[1::3], indices[2::3]):
        union(canonical[a], canonical[b]); union(canonical[a], canonical[c])
    groups = collections.defaultdict(set)
    for index in set(indices): groups[find(canonical[index])].add(index)
    return vertices, points, sorted(groups.values(), key=len, reverse=True)


def analyze():
    geom = read_geom(ROOT/'original/dsts-loader/patch/chr424857.geom')
    result = {'meshes': [], 'jaw_bone': 7, 'head_bone': 6}
    for mi, mesh in enumerate(geom.meshes):
        vertices, points, groups = components(mesh)
        jaw = []
        for i,v in enumerate(vertices):
            for index, weight in zip(v.indices, v.weights):
                if mesh.matrix_palette[int(index)] == 7 and weight > 0:
                    jaw.append({'vertex':i, 'weight':float(weight)})
        comp_report = []
        for group in groups:
            p = points[list(group)]
            comp_report.append({'id':min(group), 'vertex_count':len(group),
                                'bounds_min':p.min(0).tolist(), 'bounds_max':p.max(0).tolist(),
                                'mean':p.mean(0).tolist(), 'vertices':sorted(group)})
        result['meshes'].append({'index':mi, 'palette':list(mesh.matrix_palette),
                                 'positive_jaw_influences':jaw, 'components':comp_report})
    result['jaw_pivot_game'] = (-np.array(geom.ibpms[7]).reshape(3,4)[:,3]).tolist()
    (OUT/'jaw_inspection.json').write_text(json.dumps(result, indent=2))
    return geom, result


def render_components(geom, report):
    import bpy
    from mathutils import Vector
    bpy.ops.wm.open_mainfile(filepath=str(ROOT/'work/original.blend'))
    arm = bpy.data.objects['chr424857']
    arm.animation_data.action = None
    for t in arm.animation_data.nla_tracks:t.mute=True
    for bone in arm.pose.bones:bone.matrix_basis.identity()
    bpy.context.scene.frame_set(1)
    colors = [(0.48,.42,.34,1),(1,.13,.08,1),(1,.9,.02,1),(.02,.8,1,1),(1,.1,.85,1),
              (.2,1,.2,1),(1,.5,.03,1),(.35,.1,1,1)]
    # Annotate independent topology regions: redmainmuzzle, yellowteeth,
    # cyanlongfangs, magentatongue. Color assignment is preview-only.
    for obj, mesh, info in zip([bpy.data.objects['chr135'],bpy.data.objects['chr344']],geom.meshes,report['meshes']):
        points = np.array([v.position[:3] for v in mesh.unpack_vertices()])
        palette = {}
        for comp in info['components']:
            ci = 0; lo=np.array(comp['bounds_min']);hi=np.array(comp['bounds_max'])
            if comp['id']==2682:ci=1
            if comp['vertex_count'] in (6,8) and lo[1]>.9 and hi[1]<1.02 and lo[2]>1.18:ci=2
            if lo[1]<.40 and hi[1]>.90 and lo[2]>.70:ci=3
            if comp['id']==22291:ci=4
            if comp['id']==20732:ci=5
            if comp['id'] in (2193,5488):ci=6
            if comp['id'] in (2308,5605):ci=7
            for index in comp['vertices']:palette[tuple(np.round(points[index],5))]=colors[ci]
        attr = obj.data.color_attributes.new(name='JawDiagnostic',type='FLOAT_COLOR',domain='CORNER')
        for loop in obj.data.loops:
            v = obj.data.vertices[loop.vertex_index].co
            key = tuple(np.round([v.x,v.z,-v.y],5))
            attr.data[loop.index].color = palette.get(key,colors[0])
    outline=bpy.data.objects.get('outline')
    if outline:outline.hide_render=True
    scene=bpy.context.scene;scene.render.engine='BLENDER_WORKBENCH'
    scene.display.shading.color_type='VERTEX';scene.display.shading.light='STUDIO'
    scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH'
    scene.display.shading.background_type='WORLD';scene.world.color=(.04,.05,.07)
    scene.render.resolution_x=1000;scene.render.resolution_y=900;scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard'
    data=bpy.data.cameras.new('JawInspect');cam=bpy.data.objects.new('JawInspect',data);scene.collection.objects.link(cam)
    data.type='ORTHO';data.ortho_scale=1.7;scene.camera=cam
    target=Vector((0,-1.05,1.02))
    for label,location in [('front',(1.8,-3.8,1.4)),('side',(3.5,-1.05,1.15)),('underside',(1.2,-3.5,.65))]:
        cam.location=location;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
        scene.render.filepath=str(OUT/f'jaw_components_{label}.png');bpy.ops.render.render(write_still=True)


if __name__=='__main__':
    geom, result=analyze()
    print('JAW_POSITIVE_COUNTS',[len(m['positive_jaw_influences']) for m in result['meshes']])
    if '--render' in sys.argv:render_components(geom,result)
