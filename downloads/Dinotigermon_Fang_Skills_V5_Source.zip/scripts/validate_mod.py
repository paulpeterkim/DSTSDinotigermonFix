#!/usr/bin/env python3
"""Validate the rebuilt mod and write a byte comparison/readiness report.

This is an offline structural check. It does not claim combat, target contact,
camera framing, or presentation have been tested in the Windows game engine.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import traceback
import zipfile

import anim_codec
from patch_skills import GROUND_FANG_ID, HIGHLAND_FANG_ID, SKILL_TABLE, STATUS_TABLE, TEXT


ANIMATIONS = {
    Path("dsts-loader/patch/chr424857_bs01.anim"): 52,
    Path("dsts-loader/patch/chr424857_bs02.anim"): 52,
    **{
        Path(f"dsts-loader/patch/cam_chr424857_bs{skill:02}_{side}.anim"): None
        for skill in (1, 2) for side in ("pc", "em")
    },
}


def check(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inventory(root: Path) -> dict[Path, Path]:
    check(root.is_dir(), f"Missing mod directory: {root}")
    entries = {}
    for path in root.rglob("*"):
        check(not path.is_symlink(), f"Unexpected symlink in mod: {path}")
        if path.is_file():
            entries[path.relative_to(root)] = path
    check(bool(entries), f"Mod directory is empty: {root}")
    return entries


def parse_typed_csv(path: Path) -> tuple[list[str], list[list[str]]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        contents = list(csv.reader(stream, strict=True))
    check(bool(contents), f"Empty CSV: {path}")
    header = contents[0]
    rows = [row for row in contents[1:] if row]
    kinds = []
    for index, title in enumerate(header):
        match = re.fullmatch(r"(empty|bool|float|double|string[23]?|u?int(?:8|16|32|64)) (\d+)", title)
        check(match is not None, f"Unsupported CSV field declaration {title!r}: {path}")
        check(int(match.group(2)) == index, f"Misnumbered CSV field {title!r}: {path}")
        kinds.append(match.group(1))
    for row_index, row in enumerate(rows, start=2):
        check(len(row) == len(header), f"Wrong CSV width at {path}, record {row_index}")
        for column, (kind, value) in enumerate(zip(kinds, row)):
            location = f"{path}, record {row_index}, column {column}"
            if kind == "empty":
                check(value == "", f"Nonempty padding field: {location}")
            elif kind == "bool":
                check(value in ("true", "false"), f"Invalid bool {value!r}: {location}")
            elif kind in ("float", "double"):
                check(math.isfinite(float(value)), f"Invalid finite float: {location}")
            elif "int" in kind:
                check(re.fullmatch(r"[+-]?\d+", value) is not None, f"Invalid integer {value!r}: {location}")
                bits = int(re.search(r"\d+", kind).group())
                minimum, maximum = (0, 2 ** bits - 1) if kind.startswith("u") else (-2 ** (bits - 1), 2 ** (bits - 1) - 1)
                check(minimum <= int(value) <= maximum, f"Integer outside {kind}: {location}")
    check(len({row[0] for row in rows}) == len(rows), f"Duplicate primary key: {path}")
    return header, rows


def validate(source: Path, modified: Path, report: dict, *, original_zip: Path | None = None) -> None:
    before, after = inventory(source), inventory(modified)
    checks = report["checks"]

    if original_zip is not None:
        with zipfile.ZipFile(original_zip) as archive:
            corrupt = archive.testzip()
            check(corrupt is None, f"Original archive CRC mismatch: {corrupt}")
            names = {item.filename for item in archive.infolist() if not item.is_dir()}
            check(names == {p.as_posix() for p in before}, "Extracted original does not contain exactly the uploaded archive files")
            for relative, path in before.items():
                expected = hashlib.sha256(archive.read(relative.as_posix())).hexdigest()
                check(sha256(path) == expected, f"Original differs from uploaded archive: {relative}")
        checks.append({"name": "uploaded_archive_integrity", "passed": True, "files": len(before)})

    locales = sorted(path.relative_to(source) for path in (source / "dsts-loader").glob("patch_text*") if path.is_dir())
    check(len(locales) == 11, f"Expected the 11 supplied locales, got {len(locales)}")
    text_paths = {
        locale / "text" / table / "000_Sheet1.ap.csv"
        for locale in locales for table in ("skill_name.mbe", "skill_explanation.mbe")
    }
    allowed = {SKILL_TABLE, STATUS_TABLE, *ANIMATIONS, *text_paths}
    check(not (set(before) - set(after)), f"Original files removed: {sorted(str(p) for p in set(before) - set(after))}")
    changed = []
    preserved = 0
    for relative in sorted(set(before) | set(after)):
        old_hash = sha256(before[relative]) if relative in before else None
        new_hash = sha256(after[relative]) if relative in after else None
        if old_hash != new_hash:
            entry = {"path": relative.as_posix(), "status": "added" if old_hash is None else "modified", "original_sha256": old_hash, "modified_sha256": new_hash}
            changed.append(entry)
            check(relative in allowed, f"Unexpected modification: {relative}")
        else:
            preserved += 1
    report["file_changes"] = changed
    report["preserved_original_files"] = preserved
    report["modified_file_count"] = len(after)
    checks.append({"name": "only_allowed_assets_changed", "passed": True, "changed": len(changed), "preserved": preserved})
    protected = [path for path in before if path.suffix in (".geom", ".nlst", ".img") or "images" in path.parts]
    for path in protected:
        check(sha256(before[path]) == sha256(after[path]), f"Geometry, skeleton list, or image changed: {path}")
    checks.append({"name": "geometry_skeleton_lists_textures_preserved", "passed": True, "files": len(protected)})

    tables = {}
    for path in sorted(modified.rglob("*.ap.csv")):
        tables[path.relative_to(modified)] = parse_typed_csv(path)
    checks.append({"name": "all_append_csv_types_widths_and_keys", "passed": True, "tables": len(tables), "rows": sum(len(rows) for _, rows in tables.values())})

    _, skill_rows = tables[SKILL_TABLE]
    skills = {row[0]: row for row in skill_rows}
    check(set(skills) == {GROUND_FANG_ID, HIGHLAND_FANG_ID}, "Expected exactly two independent custom skills")
    _, original_skill_rows = parse_typed_csv(source / SKILL_TABLE)
    original_highland = next(row for row in original_skill_rows if row[0] == HIGHLAND_FANG_ID)
    for skill_id, animation, target in ((GROUND_FANG_ID, "3", "1"), (HIGHLAND_FANG_ID, "4", "5")):
        row = skills[skill_id]
        check(all(row[index] == skill_id for index in (0, 4, 5, 6)), f"Skill ID/name/description/internal key mismatch: {skill_id}")
        check(row[10] == animation and row[33] == target, f"Incorrect animation or target for skill {skill_id}")
        check(row[29] == "-1" and row[54] == "0", f"Unrelated inherited trait bonus or buff remains: {skill_id}")
        for index in (11, 22, 23, 34, 35, 36):
            check(row[index] == original_highland[index], f"Original damage/timing/hit count/SP baseline changed: skill {skill_id}, column {index}")
    check(skills[GROUND_FANG_ID][12] == "0", "Ground Fang unexpectedly uses a main effect")
    check(skills[HIGHLAND_FANG_ID][12] in ("0", original_highland[12]), "Highland Fang effect is neither disabled nor original")
    _, status_rows = tables[STATUS_TABLE]
    status = next(row for row in status_rows if row[0] == "55057")
    check(status[72] == status[126] == GROUND_FANG_ID and status[75] == HIGHLAND_FANG_ID, "Dinotigermon's skill slots/default skill disagree")
    original_header, original_status_rows = parse_typed_csv(source / STATUS_TABLE)
    check(tables[STATUS_TABLE][0] == original_header, "Dinotigermon status header changed")
    original_status = next(row for row in original_status_rows if row[0] == "55057")
    check(all(a == b for index, (a, b) in enumerate(zip(original_status, status)) if index not in (72, 75, 126)), "Unrelated Dinotigermon status fields changed")
    checks.append({"name": "custom_skill_assignments_and_inherited_balance", "passed": True})

    for locale in locales:
        for table, value_index in (("skill_name.mbe", 1), ("skill_explanation.mbe", 2)):
            _, entries = tables[locale / "text" / table / "000_Sheet1.ap.csv"]
            check(len(entries) == 2, f"Expected two localized skill entries: {locale}/{table}")
            check(dict(entries) == {entry[0]: entry[value_index] for entry in TEXT}, f"Skill name or description mismatch: {locale}/{table}")
    checks.append({"name": "exact_skill_names_and_descriptions", "passed": True, "locales": len(locales), "language": "English fallback"})

    animation_results = []
    for relative, expected_bones in ANIMATIONS.items():
        original_anim = anim_codec.read(source / relative, expected_bones=expected_bones)
        edited_anim = anim_codec.read(modified / relative, expected_bones=expected_bones)
        check(edited_anim.bone_count == original_anim.bone_count, f"Animation bone count changed: {relative}")
        check(edited_anim._source_frame_count == original_anim._source_frame_count, f"Animation frame count changed: {relative}")
        # Some source headers round duration to five decimal places. The
        # serializer computes (frames - 1) / playback_rate, so allow only that
        # subframe rounding discrepancy; exact frame count/rate remain required.
        check(math.isclose(edited_anim._source_duration, original_anim._source_duration, rel_tol=0, abs_tol=1e-5), f"Animation duration changed beyond source-header rounding: {relative}")
        check(edited_anim.playback_rate == original_anim.playback_rate, f"Animation playback rate changed: {relative}")
        # The reader already validates every channel's finite values, sorted
        # legal frame indices, complete bone coverage, and unit quaternions.
        anim_codec.validate(edited_anim, expected_bones=original_anim.bone_count, expected_frames=original_anim._source_frame_count)
        different = sha256(source / relative) != sha256(modified / relative)
        if expected_bones == 52:
            check(different, f"Special-skill character animation was not changed: {relative}")
        animation_results.append({"path": relative.as_posix(), "bones": edited_anim.bone_count, "frames": edited_anim._source_frame_count, "duration": float(edited_anim._source_duration), "original_duration": float(original_anim._source_duration), "duration_difference_seconds": float(edited_anim._source_duration - original_anim._source_duration), "changed": different})
    checks.append({"name": "animation_parse_finite_transforms_and_original_timing", "passed": True, "animations": animation_results})
    report["limitations"] = [
        "No Windows game runtime is available; combat and loader behavior are untested in game.",
        "Character/camera animation validation does not verify victim contact, enemy pinning, collisions, or damage timing inside the engine.",
        "Names and descriptions use English fallback in all existing locale folders.",
    ]


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=root / "original")
    parser.add_argument("--modified", type=Path, default=root / "modified")
    parser.add_argument("--report", type=Path, default=root / "outputs/validation.json")
    parser.add_argument("--original-zip", type=Path, help="Also validate uploaded ZIP CRCs and compare the extracted original")
    args = parser.parse_args()
    source, modified = args.source.resolve(), args.modified.resolve()
    report = {"passed": False, "validation_scope": "offline binary/data consistency", "source": str(source), "modified": str(modified), "checks": []}
    try:
        validate(source, modified, report, original_zip=args.original_zip)
        report["passed"] = True
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report.resolve()}")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
