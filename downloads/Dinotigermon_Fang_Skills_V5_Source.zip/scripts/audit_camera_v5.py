"""Read-only Blender audit of exported V5 cameras and skinned face framing.

Run with Blender --background --python-exit-code 1 --python
scripts/audit_camera_v5.py. Frame numbers are zero-based. Projection uses
Blender's actual perspective camera at16:9 with horizontal FOV; native game
particles and engine camera hand-off behavior are outside this audit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import bpy
from mathutils import Quaternion
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from anim_codec import read, sample, sample_track
from geom_preview import read_geom


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def window(value):
    pieces = value.split(':')
    if len(pieces) != 2:
        raise argparse.ArgumentTypeError('Use an inclusive first:last frame range')
    first, last = map(int, pieces)
    if first < 0 or last < first:
        raise argparse.ArgumentTypeError('Invalid frame range')
    return first, last


def world_vertices(obj, indices, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    coords = np.empty(len(evaluated.data.vertices)*3, dtype=np.float64)
    evaluated.data.vertices.foreach_get('co', coords)
    coords = coords.reshape(-1, 3)[indices]
    transform = np.asarray(evaluated.matrix_world, dtype=np.float64)
    return coords @ transform[:3, :3].T + transform[:3, 3]


def select_meshes(snapshot, geom):
    selected, details = [], []
    for record in snapshot['meshes']:
        obj = bpy.data.objects[record['name']]
        if obj.type != 'MESH':
            raise ValueError(f'Not a mesh: {record["name"]}')
        if len(record['vertex_indices']) != len(record['positions_game']):
            raise ValueError('Selection positions and original vertex indices disagree')
        # GEOM material buffers share unused vertices. The importer omits
        # unreferenced entries; they are not rendered by the game either.
        used = set(geom.meshes[record['index']].index_buffer)
        rendered_positions = [position for index, position in
                              zip(record['vertex_indices'], record['positions_game']) if index in used]
        wanted = {tuple(round(float(v), 5) for v in position)
                  for position in rendered_positions}
        index_lookup = {}
        base_points = []
        for vertex in obj.data.vertices:
            # GEOM gameY-up -> BlenderZ-up is(x,-z,y).
            key = tuple(round(float(v), 5) for v in
                        (vertex.co.x, vertex.co.z, -vertex.co.y))
            index_lookup.setdefault(key, []).append(vertex.index)
            base_points.append((vertex.co.x, vertex.co.z, -vertex.co.y))
        missing = sorted(wanted-set(index_lookup))
        # Import float32 transforms can move a coordinate across a rounding
        # boundary by less than a millionth. Match those cases to the original
        # full-precision selection position with a strict2e-6 coordinate bound.
        base_points = np.asarray(base_points, dtype=float)
        source_points = {tuple(round(float(v), 5) for v in position): np.asarray(position, dtype=float)
                         for position in rendered_positions}
        largest_fallback_error = 0.
        for key in missing:
            errors = np.max(np.abs(base_points-source_points[key]), axis=1)
            nearest_error = float(np.min(errors))
            if nearest_error > 2e-6:
                raise ValueError(f'{obj.name}: selected base position is absent: {key}, nearest error={nearest_error}')
            index_lookup[key] = np.flatnonzero(errors <= 2e-6).tolist()
            largest_fallback_error = max(largest_fallback_error, nearest_error)
        indices = sorted({index for key in wanted for index in index_lookup[key]})
        if not indices:
            raise ValueError(f'Empty selected mesh: {obj.name}')
        selected.append((obj, np.asarray(indices, dtype=int)))
        details.append({'name': obj.name, 'game_mesh_index': record['index'],
                        'input_positions': len(record['positions_game']),
                        'unindexed_source_vertices_excluded': len(record['positions_game'])-len(rendered_positions),
                        'rendered_source_positions': len(rendered_positions),
                        'unique_game_positions': len(wanted),
                        'matched_blender_vertices': len(indices),
                        'rounding_boundary_fallback_positions': len(missing),
                        'max_fallback_coordinate_error': largest_fallback_error,
                        'unmatched_positions': 0})
    return selected, details


def project(scene, camera, points, depsgraph):
    view = np.asarray(camera.matrix_world.inverted(), dtype=np.float64)
    projection = np.asarray(camera.calc_matrix_camera(
        depsgraph, x=scene.render.resolution_x, y=scene.render.resolution_y,
        scale_x=scene.render.pixel_aspect_x, scale_y=scene.render.pixel_aspect_y),
        dtype=np.float64)
    homogeneous = np.c_[points, np.ones(len(points))]
    camera_points = homogeneous @ view.T
    clip = camera_points @ projection.T
    if np.min(np.abs(clip[:, 3])) < 1e-10:
        raise ValueError('A selected face point lies on the camera plane')
    xy = .5*(clip[:, :2]/clip[:, 3:4]+1.)
    depth = -camera_points[:, 2]
    lo, hi = np.min(xy, axis=0), np.max(xy, axis=0)
    if not np.isfinite(xy).all() or not np.isfinite(depth).all():
        raise ValueError('Non-finite actual Blender projection')
    return {'bbox_ndc': {'min': lo.tolist(), 'max': hi.tolist()},
            'width_fraction': float(hi[0]-lo[0]),
            'height_fraction': float(hi[1]-lo[1]),
            'center_ndc': ((lo+hi)*.5).tolist(),
            'min_depth': float(np.min(depth)), 'max_depth': float(np.max(depth)),
            'all_points_in_image': bool(np.all(lo >= 0.) and np.all(hi <= 1.) and
                                        np.min(depth) >= camera.data.clip_start),
            'inside_two_percent_margin': bool(np.all(lo >= .02) and np.all(hi <= .98) and
                                              np.min(depth) >= camera.data.clip_start)}


def main():
    argv = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scene', type=Path, default=ROOT/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend')
    parser.add_argument('--modified', type=Path, default=ROOT/'modified_v5')
    parser.add_argument('--selection', type=Path, default=ROOT/'work/v5/face_selection.json')
    parser.add_argument('--diagnostics', type=Path, default=ROOT/'work/v5/cameras.json')
    parser.add_argument('--ground-full-zoom', type=window)
    parser.add_argument('--highland-full-zoom', type=window)
    parser.add_argument('--report', type=Path, default=ROOT/'work/v5/camera_framing_audit.json')
    args = parser.parse_args(argv)
    snapshot = json.loads(args.selection.read_text())
    geometry_path = args.modified/'dsts-loader/patch/chr424857.geom'
    geometry_hash = digest(geometry_path)
    if snapshot.get('geometry_sha256') != geometry_hash:
        raise ValueError('Face selection is for a different game geometry')
    geometry = read_geom(geometry_path)
    report = {'revision': 5, 'passed': False, 'projection': {
        'aspect_ratio': '16:9', 'resolution': [1280, 720],
        'fov_convention': 'horizontal', 'ndc_convention': '0..1; bottom-left origin',
        'full_zoom_required_margin': .02},
        'source_scene_sha256': digest(args.scene),
        'source_geometry_sha256': geometry_hash,
        'selection_sha256': digest(args.selection),
        'camera_sha256': {}, 'cameras': {},
        'limits': ['Semantic bounds establish framing and depth, not self-occlusion or engine behavior.',
                   'Native particles and camera hand-off are not rendered or tested.']}
    diagnostics = None
    if args.diagnostics.is_file():
        diagnostics = json.loads(args.diagnostics.read_text())
        report['camera_diagnostics_sha256'] = digest(args.diagnostics)
    diagnostic_cameras = {row['path']: row for row in diagnostics['cameras']} if diagnostics else {}
    bpy.ops.wm.open_mainfile(filepath=str(args.scene))
    scene = bpy.context.scene
    scene.render.resolution_x, scene.render.resolution_y = 1280, 720
    scene.render.resolution_percentage = 100
    scene.render.pixel_aspect_x = scene.render.pixel_aspect_y = 1.
    camera = scene.camera
    camera.data.type = 'PERSP'
    camera.data.sensor_fit = 'HORIZONTAL'
    camera.rotation_mode = 'QUATERNION'
    camera.data.shift_x = camera.data.shift_y = 0.
    armature = bpy.data.objects['chr424857']
    for track in armature.animation_data.nla_tracks:
        track.mute = True
    selected, report['selection_matches'] = select_meshes(snapshot, geometry)
    conversion = Quaternion((1., 0., 0.), math.pi/2)
    depsgraph = bpy.context.evaluated_depsgraph_get()
    windows = {'bs01': args.ground_full_zoom, 'bs02': args.highland_full_zoom}
    full_frames = {}
    for stem, count in [('bs01', 120), ('bs02', 96)]:
        armature.animation_data.action = bpy.data.actions['chr424857_'+stem]
        clips = {}
        for side in ('pc', 'em'):
            relative = f'dsts-loader/patch/cam_chr424857_{stem}_{side}.anim'
            path = args.modified/relative
            clip = read(path, expected_bones=2)
            if clip._source_frame_count != count:
                raise ValueError('Unexpected actor/camera frame count')
            clips[side] = clip
            report['camera_sha256'][relative] = digest(path)
            if windows[stem] is not None:
                full_frames[relative] = set(range(windows[stem][0], windows[stem][1]+1))
            else:
                authored = diagnostic_cameras[relative]['samples']
                full_frames[relative] = {row['frame'] for row in authored if row['zoom_weight'] >= .9999}
            if not full_frames[relative] or min(full_frames[relative]) < 0 or max(full_frames[relative]) >= count:
                raise ValueError(f'Invalid or empty full-zoom frame selection: {relative}')
            report['cameras'][relative] = {'stem': stem, 'side': side, 'frames': [],
                                           'full_zoom_frames': sorted(full_frames[relative]),
                                           'full_zoom_definition': 'authored zoom_weight>=.9999 unless CLI override supplied'}
        for frame in range(count):
            scene.frame_set(frame+1)
            bpy.context.view_layer.update()
            depsgraph.update()
            points = np.concatenate([world_vertices(obj, indices, depsgraph)
                                     for obj, indices in selected], axis=0)
            for side, clip in clips.items():
                position, rotation, _ = sample(clip, 0, frame)
                camera.location = (position[0], -position[2], position[1])
                camera.rotation_quaternion = conversion @ Quaternion((rotation[3], *rotation[:3]))
                camera.data.angle = math.radians(float(sample_track(clip.float_channels[0], frame)))
                bpy.context.view_layer.update()
                result = project(scene, camera, points, depsgraph)
                relative = f'dsts-loader/patch/cam_chr424857_{stem}_{side}.anim'
                result.update({'frame': frame, 'full_zoom': frame in full_frames[relative],
                               'fov_degrees': math.degrees(camera.data.angle),
                               'camera_world_position_blender': list(camera.location)})
                report['cameras'][relative]['frames'].append(result)
    passed = True
    for relative, camera_report in report['cameras'].items():
        rows = camera_report['frames']
        zoom = [row for row in rows if row['full_zoom']]
        failures = [row['frame'] for row in zoom if not row['inside_two_percent_margin']]
        camera_report['summary'] = {
            'full_zoom_all_points_in_view': not failures,
            'full_zoom_failure_frames': failures,
            'full_zoom_min_height_fraction': min(row['height_fraction'] for row in zoom),
            'full_zoom_max_height_fraction': max(row['height_fraction'] for row in zoom),
            'full_zoom_min_depth': min(row['min_depth'] for row in zoom),
            'all_frames_min_depth': min(row['min_depth'] for row in rows)}
        passed = passed and not failures
        print(relative, json.dumps(camera_report['summary']), flush=True)
    report['passed'] = bool(passed)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print('V5 BLENDER FRAMING', 'PASS' if passed else 'FAIL', str(args.report), flush=True)
    if not passed:
        raise ValueError('Actual Blender face/eye/fang points leave the full-zoom image margin')


if __name__ == '__main__':
    main()
