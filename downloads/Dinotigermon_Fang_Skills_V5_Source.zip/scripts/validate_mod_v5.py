#!/usr/bin/env python3
"""Validate face-closeup cameras while preserving the accepted V4 mod assets.

Binary/FK checks establish the intended dolly/zoom and preservation scope.
Rendered framing and the game engine still need their own visual review.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import traceback

import numpy as np

import anim_codec
from motion_math import fk, qinv, qrotate
from validate_mod import check, inventory, sha256

ROOT = Path(__file__).resolve().parents[1]
CAMERAS = {Path(f"dsts-loader/patch/cam_chr424857_{stem}_{side}.anim"): stem
           for stem in ("bs01", "bs02") for side in ("pc", "em")}
COUNTS = {"bs01": 120, "bs02": 96}
OPENING_END = {"bs01": 30, "bs02": 27}
CONTACT = {"bs01": [44, 48, 50, 59, 67], "bs02": [41, 44, 46, 47, 50]}
TOLERANCE = 0.0001


def equal_tracks(old, new, *, quaternion=False, tolerance=TOLERANCE):
    check(set(old) == set(new), "Protected animation track keys changed")
    largest = 0.
    for frame in old:
        a, b = np.asarray(old[frame]), np.asarray(new[frame])
        if quaternion and np.dot(a, b) < 0:
            b = -b
        error = float(np.max(np.abs(a-b)))
        check(error <= tolerance, f"Protected channel changed at frame {frame}: {error}")
        largest = max(largest, error)
    return largest


def pose(anim, frame):
    samples = [anim_codec.sample(anim, bone, frame) for bone in range(anim.bone_count)]
    return np.asarray([s[0] for s in samples]), np.asarray([s[1] for s in samples])


def head_projection(camera, frame, point):
    position, rotation, _ = anim_codec.sample(camera, 0, frame)
    local = qrotate(qinv(rotation), point-position)
    depth = float(-local[2])
    fov = float(anim_codec.sample_track(camera.float_channels[0], frame))
    check(depth > .05 and 5 < fov < 120, "Head/camera depth or field of view is invalid")
    radius = depth*math.tan(math.radians(fov)/2)
    return {"distance": float(np.linalg.norm(point-position)), "depth": depth,
            "fov": fov, "image_scale": radius,
            "ndc": [float(local[0]/radius), float(local[1]/(radius/(16/9)))]}


def validate_baseline(baseline, baseline_report, modified, report):
    accepted = json.loads(baseline_report.read_text())
    check(accepted.get("passed") is True and accepted.get("revision") == 4,
          "Baseline must have a passing V4 validation report")
    before, after = inventory(baseline), inventory(modified)
    hashes = {relative.as_posix(): sha256(path) for relative, path in sorted(before.items())}
    check(hashes == accepted.get("asset_sha256"), "V4 baseline hash inventory changed")
    check(set(before) == set(after), "V5 added or removed game assets")
    changed = []
    for relative in sorted(before):
        digest = sha256(after[relative])
        if hashes[relative.as_posix()] != digest:
            check(relative in CAMERAS, f"V5 changed an asset outside the four camera clips: {relative}")
            changed.append({"path": relative.as_posix(), "v4_sha256": hashes[relative.as_posix()],
                            "v5_sha256": digest})
    check({r["path"] for r in changed} == {p.as_posix() for p in CAMERAS},
          "Expected all four face-closeup camera clips to change")
    report["baseline_validation_sha256"] = sha256(baseline_report)
    report["file_changes"] = changed
    report["checks"].append({"name": "accepted_v4_hash_inventory_and_exact_four_camera_change_scope",
                              "passed": True, "files": len(before), "changed": len(changed),
                              "unchanged": len(before)-len(changed)})
    report["checks"].append({"name": "v4_actor_jaw_effects_balance_text_and_other_assets_byte_identical",
                              "passed": True,
                              "note": "Exact identity inherits V4 actor/jaw/effect checks; it does not establish runtime effect synchronization."})
    return after


def validate_cameras(baseline, modified, report):
    skeleton = anim_codec.read_embedded_skeleton(baseline/"dsts-loader/patch/chr424857.geom")
    actors = {stem: anim_codec.read(baseline/f"dsts-loader/patch/chr424857_{stem}.anim")
              for stem in COUNTS}
    cameras, protected, continuity, closeups = [], [], [], []
    for relative, stem in CAMERAS.items():
        old, new = anim_codec.read(baseline/relative), anim_codec.read(modified/relative)
        count = COUNTS[stem]
        check(old.bone_count == new.bone_count == 2 and
              old._source_frame_count == new._source_frame_count == count,
              f"Camera bones/frame count changed: {relative}")
        check(old.playback_rate == new.playback_rate and
              math.isclose(old._source_duration, new._source_duration, abs_tol=2e-6, rel_tol=0),
              f"Camera playback rate/duration changed: {relative}")
        for field in ("float_channel_count",):
            check(getattr(old, field) == getattr(new, field), f"Camera {field} changed")
        for field in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
            check(np.array_equal(getattr(old, field), getattr(new, field)), f"Camera metadata changed: {field}")
        maximum_protected_error = 0.
        for field in ("positions", "rotations", "scales", "float_channels"):
            check(set(getattr(old, field)) == set(getattr(new, field)), f"Camera channel inventory changed: {field}")
        for bone in range(2):
            maximum_protected_error = max(maximum_protected_error, equal_tracks(old.scales[bone], new.scales[bone]))
            if bone != 0:
                maximum_protected_error = max(maximum_protected_error,
                    equal_tracks(old.positions[bone], new.positions[bone]),
                    equal_tracks(old.rotations[bone], new.rotations[bone], quaternion=True))
        for channel in old.float_channels:
            if channel != 0:
                maximum_protected_error = max(maximum_protected_error,
                    equal_tracks(old.float_channels[channel], new.float_channels[channel]))
        for field in ("positions", "rotations"):
            check(set(getattr(old, field)[0]) == set(getattr(new, field)[0]) == set(range(count)),
                  f"Camera root track became sparse: {field}")
        check(set(old.float_channels[0]) == set(new.float_channels[0]) == set(range(count)),
              "Camera FOV keys changed")
        protected_frames = list(range(OPENING_END[stem]+1))+list(range(count-10, count))
        pos_error, rot_error, fov_error = 0., 0., 0.
        for frame in protected_frames:
            before_p, before_q, _ = anim_codec.sample(old, 0, frame)
            after_p, after_q, _ = anim_codec.sample(new, 0, frame)
            if np.dot(before_q, after_q) < 0:
                after_q = -after_q
            pos_error = max(pos_error, float(np.max(np.abs(before_p-after_p))))
            rot_error = max(rot_error, float(np.max(np.abs(before_q-after_q))))
            fov_error = max(fov_error, abs(old.float_channels[0][frame]-new.float_channels[0][frame]))
        check(max(pos_error, rot_error, fov_error) <= TOLERANCE,
              f"Existing opening or final ten camera frames changed: {relative}")
        protected.append({"path": relative.as_posix(), "opening_frames": [0, OPENING_END[stem]],
                          "return_frames": [count-10, count-1], "max_position_error": pos_error,
                          "max_rotation_component_error": rot_error, "max_fov_error": fov_error,
                          "max_other_protected_channel_error": maximum_protected_error})
        positions, rotations, fovs = [], [], []
        for frame in range(count):
            p, q, _ = anim_codec.sample(new, 0, frame)
            positions.append(p); rotations.append(q); fovs.append(new.float_channels[0][frame])
        positions, rotations, fovs = np.asarray(positions), np.asarray(rotations), np.asarray(fovs)
        check(np.all((fovs > 5) & (fovs < 120)), f"Camera FOV is outside a valid perspective range: {relative}")
        steps = np.linalg.norm(np.diff(positions, axis=0), axis=1)
        angles = np.degrees(2*np.arccos(np.clip(np.abs(np.sum(rotations[1:]*rotations[:-1], axis=1)), 0, 1)))
        fov_steps = np.abs(np.diff(fovs))
        check(float(max(steps)) <= 1.3 and float(max(angles)) <= 25 and float(max(fov_steps)) <= 5,
              f"Camera transition exceeds the broad continuity gate: {relative}")
        continuity.append({"path": relative.as_posix(), "max_adjacent_position_step": float(max(steps)),
                           "max_adjacent_rotation_degrees": float(max(angles)),
                           "max_adjacent_fov_degrees": float(max(fov_steps)),
                           "note": "These bounds reject jumps; visual review determines cinematic quality."})
        contacts = []
        for frame in CONTACT[stem]:
            p, q = pose(actors[stem], frame)
            world, _ = fk(skeleton, p, q)
            before, after = head_projection(old, frame, world[6]), head_projection(new, frame, world[6])
            gain = before["image_scale"]/after["image_scale"]
            contacts.append({"frame": frame, "v4": before, "v5": after,
                             "head_image_magnification": gain,
                             "camera_distance_ratio": after["distance"]/before["distance"]})
        strong = [r for r in contacts if r["head_image_magnification"] >= 1.5]
        report.setdefault("closeup_diagnostics", []).append({"path": relative.as_posix(), "contacts": contacts,
                          "contact_samples_with_at_least_1_5x_magnification": len(strong)})
        check(len(strong) >= 3, f"Camera does not substantially magnify the face during contact: {relative}")
        closeups.append({"path": relative.as_posix(), "contacts": contacts,
                         "contact_samples_with_at_least_1_5x_magnification": len(strong),
                         "note": "FK head-point image scale is a closeup measurement, not a mesh-visibility proof."})
        cameras.append({"path": relative.as_posix(), "frames": count, "fps": new.playback_rate,
                        "duration": new._source_duration, "sha256": sha256(modified/relative)})
    report["cameras"] = cameras
    report["checks"].extend([
        {"name": "camera_metadata_channels_lengths_and_actor_timing_preserved", "passed": True},
        {"name": "current_opening_and_final_ten_frames_preserved", "passed": True, "cameras": protected},
        {"name": "finite_continuous_dolly_aim_and_fov_curves", "passed": True, "cameras": continuity},
        {"name": "face_closeup_magnification_at_bite_and_downward_strike", "passed": True, "cameras": closeups},
    ])


def validate_framing(audit_path, modified, report):
    """Bind the independent Blender mesh projection to these exported clips."""
    audit = json.loads(audit_path.read_text())
    check(audit.get("passed") is True and audit.get("revision") == 5,
          "The independent Blender framing audit did not pass")
    check(audit["projection"]["aspect_ratio"] == "16:9" and
          audit["projection"]["fov_convention"] == "horizontal",
          "Blender projection convention differs from the preview")
    expected = {relative.as_posix(): sha256(modified/relative) for relative in CAMERAS}
    check(audit["camera_sha256"] == expected, "Blender framing audit uses stale camera clips")
    check(audit["source_geometry_sha256"] == sha256(modified/"dsts-loader/patch/chr424857.geom"),
          "Blender framing audit uses different character geometry")
    selection_path, diagnostics_path = audit_path.parent/"face_selection.json", audit_path.parent/"cameras.json"
    check(audit["selection_sha256"] == sha256(selection_path), "Blender framing audit uses a different face selection")
    check(audit["camera_diagnostics_sha256"] == sha256(diagnostics_path), "Blender framing audit uses stale camera diagnostics")
    diagnostics = json.loads(diagnostics_path.read_text())
    authored = {camera["path"]: camera for camera in diagnostics["cameras"]}
    scene_path = ROOT/"outputs_v3/Dinotigermon_Fang_Attacks_V3.blend"
    scene_verified = scene_path.is_file()
    if scene_verified:
        check(audit["source_scene_sha256"] == sha256(scene_path), "Blender framing audit uses a different scene")
    check(set(audit["cameras"]) == set(expected), "Blender framing audit camera set changed")
    summaries = []
    for relative, camera in audit["cameras"].items():
        stem = CAMERAS[Path(relative)]
        frames = camera["frames"]
        check(len(frames) == COUNTS[stem] and [f["frame"] for f in frames] == list(range(COUNTS[stem])),
              f"Blender audit is missing camera frames: {relative}")
        full_zoom = {row["frame"] for row in authored[relative]["samples"] if row["zoom_weight"] >= .9999}
        check(set(camera["full_zoom_frames"]) == full_zoom and len(full_zoom) >= 10,
              f"Blender audit full-zoom frame selection changed: {relative}")
        zoom = [row for row in frames if row["frame"] in full_zoom]
        for row in zoom:
            lo, hi = np.asarray(row["bbox_ndc"]["min"]), np.asarray(row["bbox_ndc"]["max"])
            check(lo.shape == hi.shape == (2,) and np.isfinite(lo).all() and np.isfinite(hi).all(),
                  "Blender audit contains invalid face bounds")
            check(np.all(lo >= .02) and np.all(hi <= .98) and row["min_depth"] > .05,
                  f"Face/eye/fang geometry leaves the closeup image margin: {relative}, frame {row['frame']}")
            check(.55 <= row["height_fraction"] <= .96,
                  f"Actual mesh face closeup is too small or cropped: {relative}, frame {row['frame']}")
        check(all(row["min_depth"] > .05 for row in frames), "Face geometry intersects the camera near plane")
        summary = camera["summary"]
        check(summary["full_zoom_all_points_in_view"] and not summary["full_zoom_failure_frames"],
              "Blender summary reports closeup clipping")
        summaries.append({"path": relative, "full_zoom_frames": [min(full_zoom), max(full_zoom)],
                          "min_face_height_fraction": min(r["height_fraction"] for r in zoom),
                          "max_face_height_fraction": max(r["height_fraction"] for r in zoom),
                          "min_face_depth": min(r["min_depth"] for r in zoom)})
    report["framing_audit_sha256"] = sha256(audit_path)
    report["camera_diagnostics_sha256"] = sha256(diagnostics_path)
    report["face_selection_sha256"] = sha256(selection_path)
    report["checks"].append({"name": "independent_blender_actual_face_eye_and_fang_projection",
                              "passed": True, "aspect_ratio": "16:9", "image_margin": .02,
                              "scene_file_hash_verified_here": scene_verified, "cameras": summaries,
                              "note": "Actual skinned mesh bounds establish framing; self-occlusion and game camera handoff remain visual/runtime checks."})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=ROOT/"modified_v4")
    parser.add_argument("--modified", type=Path, default=ROOT/"modified_v5")
    parser.add_argument("--baseline-report", type=Path, default=ROOT/"outputs_v4/validation.json")
    parser.add_argument("--framing-audit", type=Path, default=ROOT/"work/v5/camera_framing_audit.json")
    parser.add_argument("--report", type=Path, default=ROOT/"outputs_v5/validation.json")
    args = parser.parse_args()
    report = {"revision": 5, "passed": False, "checks": [],
              "baseline": str(args.baseline.resolve()), "modified": str(args.modified.resolve())}
    try:
        files = validate_baseline(args.baseline, args.baseline_report, args.modified, report)
        validate_cameras(args.baseline, args.modified, report)
        if args.framing_audit.is_file():
            validate_framing(args.framing_audit, args.modified, report)
        report["asset_sha256"] = {p.as_posix(): sha256(file) for p, file in sorted(files.items())}
        report["passed"] = True
    except Exception as error:
        report["error"] = str(error)
        report["traceback"] = traceback.format_exc()
    report["limits"] = ["FK magnification checks do not replace rendered mesh framing review.",
                        "Game camera handoff and native effect synchronization remain untested in the engine."]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report}")
    if not report['passed']:
        print(report['error'], file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
