"""Read-only Blender preview compatibility for the supplied Dinotigermon GEOM.

The source model uses a material layout unsupported by the selected addon branch.
This module explicitly treats that material region as opaque for preview only;
it keeps the original mesh/vertex parser and uses the declared embedded skeleton.
It never writes GEOMs and must not be used as a model exporter.
"""

from __future__ import annotations

import importlib
from pathlib import Path
from types import SimpleNamespace

from anim_codec import _load_tools, _PACKAGE, read_embedded_skeleton


def preview_geom_class(package_name=_PACKAGE):
    _load_tools()
    module = importlib.import_module(f"{package_name}.src.filetypes.Geom.Binary.TimeStranger")
    parser = importlib.import_module(f"{package_name}.src.serialization.DSCSParsers")

    class PreviewMesh(module.MeshBinaryHundredLine):
        def rw_data(self, rw):
            # The upstream reader assumes contiguous arrays, but this model
            # aligns some index/attribute blocks to 8 bytes. Honor the explicit
            # header offsets instead of misreading alignment as vertex formats.
            def advance(offset):
                if offset < rw.tell():
                    raise ValueError("Overlapping preview mesh sections")
                rw.rw_bytestring(None, offset - rw.tell())

            advance(self.vertices_offset)
            self.vertex_buffer = rw.rw_bytestring(None, self.vertex_count * self.bytes_per_vertex)
            advance(self.matrix_palette_offset)
            self.matrix_palette = rw.rw_uint32s([], self.matrix_palette_count)
            advance(self.indices_offset)
            if self.index_type == 0:
                self.index_buffer = rw.rw_uint16s([], self.index_count)
            elif self.index_type == 1:
                self.index_buffer = rw.rw_uint32s([], self.index_count)
            else:
                raise ValueError(f"Unsupported preview index type {self.index_type}")
            advance(self.attributes_offset)
            self.attributes = rw.rw_dynamic_objs([], module.VertexAttributeBinary,
                                                self.attribute_count)
            if self.unknown_mesh_data_offset:
                advance(self.unknown_mesh_data_offset)
                self.unknown_mesh_data = rw.rw_dynamic_obj(None, module.UnknownMeshData)

    class PreviewGeom(module.GeomFileBinaryTimeStranger):
        def read(self, filepath):
            # Parse only fields whose formats are known. The zero-float-channel
            # skeleton parser in the addon incorrectly validates absent pointers.
            self.skel = read_embedded_skeleton(filepath)
            reader = parser.DSCSReader()
            with reader.FileIO(str(filepath)) as rw:
                old_dynamic = rw.rw_dynamic_objs
                old_obj = rw.rw_obj

                def dynamic(objects, obj_type, count, *args, **kwargs):
                    if obj_type is module.MeshBinaryHundredLine:
                        return old_dynamic(objects, PreviewMesh, count, *args, **kwargs)
                    if obj_type is module.MaterialBinaryHundredLine:
                        start = rw.tell()
                        candidates = [self.skel_offset, self.strings_offset]
                        if self.camera_count:
                            candidates.append(self.cameras_offset)
                        if self.ibpm_count:
                            candidates.append(self.ibpms_offset)
                        if self.extra_clut_offset:
                            candidates.append(self.extra_clut_offset)
                        end = min(offset for offset in candidates if offset > start)
                        if start > self.materials_offset or end > self.skel_offset:
                            raise ValueError(f"Invalid opaque material block boundaries: "
                                             f"start={start:#x} declared={self.materials_offset:#x} "
                                             f"end={end:#x} skeleton={self.skel_offset:#x}")
                        self.preview_opaque_material_bytes = rw.rw_bytestring(None, end - start)
                        return [SimpleNamespace(preview_only=True) for _ in range(count)]
                    return old_dynamic(objects, obj_type, count, *args, **kwargs)

                def obj(value, *args, **kwargs):
                    if value is self.skel:
                        rw.rw_bytestring(None, self.skel_size)
                        return value
                    return old_obj(value, *args, **kwargs)

                rw.rw_dynamic_objs = dynamic
                rw.rw_obj = obj
                # All mesh, string, camera, IBPM, and EOF validations remain in
                # the original reader. Only material interpretation is skipped.
                self.exbip_rw(rw)

    return PreviewGeom


def read_geom(path, package_name=_PACKAGE):
    result = preview_geom_class(package_name)()
    result.read(str(path))
    return result


def install_blender_preview_patch(package_name=_PACKAGE):
    """Patch one imported Blender module for a read-only, base-texture preview.

    Return its import_ts_geom function. No addon source or user asset is changed.
    Render materials deliberately approximate the unsupported game shader.
    """
    import bpy

    importer = importlib.import_module(
        f"{package_name}.src.BlenderIO.Import.ImportTimeStrangerGeom")
    importer.GeomFileBinaryTimeStranger = preview_geom_class(package_name)

    def import_materials(geom, directory, errorlog, rename_imgs, use_custom_nodes):
        names = [geom.get_string(offset).decode("utf8", errors="replace")
                 for offset in geom.name_offsets.material_name_offsets]
        image_path = Path(directory) / "images" / "dino057_base.img"
        texture = None
        if image_path.is_file():
            texture = bpy.data.images.load(str(image_path), check_existing=True)
            texture.pack()
        materials = []
        for index in range(geom.material_count):
            material = bpy.data.materials.new(
                (names[index] if index < len(names) else f"DinoMaterial{index}") + "_preview")
            material.use_nodes = True
            bsdf = material.node_tree.nodes.get("Principled BSDF")
            bsdf.inputs["Base Color"].default_value = (0.55, 0.29, 0.10, 1)
            bsdf.inputs["Roughness"].default_value = 0.55
            if texture:
                node = material.node_tree.nodes.new("ShaderNodeTexImage")
                node.image = texture
                material.node_tree.links.new(node.outputs["Color"], bsdf.inputs["Base Color"])
            materials.append(material)
        return materials

    importer.import_materials = import_materials
    return importer.import_ts_geom
