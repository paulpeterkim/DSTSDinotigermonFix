#!/usr/bin/env python3
"""Copy the supplied Dinotigermon mod and give its skills independent IDs.

Only the two skill rows, Dinotigermon's own skill references, and new localized
name/description rows change. Character animations are authored separately.
The original directory is never changed and the destination must not exist.

The original custom second skill is the only full skill definition supplied in
the archive. Its basic combat parameters are used for both new rows; this is an
explicit inherited baseline, not a reconstruction of vanilla skill 24241.
Ground Fang targets one enemy. The unrelated Bird damage bonus and undocumented
buff set inherited from the source skill are removed from both attacks.

Column semantics: https://hyotan-dev.github.io/dstsworkshop/documentation/mbe/battle_skill/
Skill assignments: https://hyotan-dev.github.io/dstsworkshop/documentation/mbe/digimon_status/
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
import shutil


GROUND_FANG_ID = "5505710"
HIGHLAND_FANG_ID = "5505720"
SKILL_TABLE = Path("dsts-loader/patch/data/battle_skill.mbe/000_battle_skill_list.ap.csv")
STATUS_TABLE = Path("dsts-loader/patch/data/digimon_status.mbe/000_digimon_status_data.ap.csv")
TEXT = (
    (GROUND_FANG_ID, "Ground Fang", "Pins down the enemy, then stabs and tears through them with its fangs."),
    (HIGHLAND_FANG_ID, "Highland Fang", "Swings down its fangs from an elevation, instantly cutting them to pieces."),
)


def read_csv(path: Path) -> tuple[list[str], list[list[str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.reader(stream))
    if not rows:
        raise ValueError(f"Empty CSV: {path}")
    header, entries = rows[0], [row for row in rows[1:] if row]
    if any(len(row) != len(header) for row in entries):
        raise ValueError(f"CSV row width does not match the header: {path}")
    return header, entries


def write_csv(path: Path, header: list[str], rows: list[list[str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\r\n")
        writer.writerow(header)
        writer.writerows(rows)


def require_columns(header: list[str], expected: dict[int, str], path: Path) -> None:
    for index, kind in expected.items():
        if index >= len(header) or header[index] != f"{kind} {index}":
            raise ValueError(f"Unexpected column {index} in {path}")


def patch(source: Path, destination: Path, *, disable_highland_effect: bool = False) -> list[Path]:
    source, destination = source.resolve(), destination.resolve()
    if not source.is_dir():
        raise ValueError(f"Source mod directory does not exist: {source}")
    if destination.exists():
        raise ValueError(f"Destination already exists; refusing to overwrite it: {destination}")
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError("Source and destination must be separate directories")

    # Validate all assumptions before creating an output copy.
    skill_header, skills = read_csv(source / SKILL_TABLE)
    require_columns(skill_header, {0: "int32", 4: "int32", 5: "int32", 6: "int32", 10: "int32", 12: "int32", 29: "int32", 33: "int32", 54: "int32"}, SKILL_TABLE)
    matches = [row for row in skills if row[0] == HIGHLAND_FANG_ID]
    if len(matches) != 1 or any(row[0] == GROUND_FANG_ID for row in skills):
        raise ValueError("Expected one original skill 5505720 and no skill 5505710")
    template = matches[0]

    status_header, statuses = read_csv(source / STATUS_TABLE)
    require_columns(status_header, {0: "int32", 72: "int32", 75: "int32", 126: "int32"}, STATUS_TABLE)
    digimon_rows = [row for row in statuses if row[0] == "55057"]
    if len(digimon_rows) != 1:
        raise ValueError("Expected exactly one Dinotigermon (55057) status row")
    dinotigermon = digimon_rows[0]
    if (dinotigermon[72], dinotigermon[75], dinotigermon[126]) != ("24241", HIGHLAND_FANG_ID, "24241"):
        raise ValueError("Dinotigermon's original skill assignments differ from the supplied archive")
    locales = sorted((source / "dsts-loader").glob("patch_text*"))
    if not locales:
        raise ValueError("No locale folders found in source mod")
    for locale in locales:
        for table in ("skill_name.mbe", "skill_explanation.mbe"):
            if (locale / "text" / table / "000_Sheet1.ap.csv").exists():
                raise ValueError("Source already contains custom skill text; review before merging")

    ground, highland = template.copy(), template.copy()
    for row, skill_id, animation in ((ground, GROUND_FANG_ID, "3"), (highland, HIGHLAND_FANG_ID, "4")):
        for column in (0, 4, 5, 6):
            row[column] = skill_id
        row[10] = animation
        row[29] = "-1"  # No special damage bonus against the Bird trait.
        row[54] = "0"  # No unrelated, undocumented inherited buff set.
    ground[33] = "1"  # Single Enemy, per workshop's target-ID table.
    # The supplied effect is tied to the old second animation. Do not attach it
    # to the new first attack or guess a vanilla skill effect that is absent.
    ground[12] = "0"
    if disable_highland_effect:
        highland[12] = "0"
    patched_skills = [row for row in skills if row is not template] + [ground, highland]
    dinotigermon[72] = dinotigermon[126] = GROUND_FANG_ID
    dinotigermon[75] = HIGHLAND_FANG_ID

    shutil.copytree(source, destination, copy_function=shutil.copy2)
    write_csv(destination / SKILL_TABLE, skill_header, patched_skills)
    write_csv(destination / STATUS_TABLE, status_header, statuses)
    changed = [SKILL_TABLE, STATUS_TABLE]
    # The supplied mod already uses English names in every locale. Keep this
    # explicit English fallback rather than claiming unreviewed translations.
    for locale in locales:
        relative = locale.relative_to(source)
        for table, position in (("skill_name.mbe", 1), ("skill_explanation.mbe", 2)):
            relative_file = relative / "text" / table / "000_Sheet1.ap.csv"
            write_csv(destination / relative_file, ["string2 0", "string 1"], [[entry[0], entry[position]] for entry in TEXT])
            changed.append(relative_file)
    return changed


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=root / "original")
    parser.add_argument("--destination", type=Path, default=root / "modified")
    parser.add_argument("--disable-highland-effect", action="store_true", help="Suppress the original skill-2 particle effect if it conflicts with the new animation")
    args = parser.parse_args()
    changed = patch(args.source, args.destination, disable_highland_effect=args.disable_highland_effect)
    print(f"Wrote {args.destination.resolve()} with {len(changed)} changed/new data and text files.")
    print("Ground Fang: 5505710, bs01; Highland Fang: 5505720, bs02.")
    print("Basic balance inherits skill 2; Ground Fang targets one enemy. Animation files are unchanged.")


if __name__ == "__main__":
    main()
