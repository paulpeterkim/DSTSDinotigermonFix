"""Quaternion/FK and analytic joint-head IK for authored DSTS animation deltas.

The imported visual Blender bones need not point their tails at child joints.
Solve from the actual skeleton hierarchy and joint heads instead. Coordinates
are game Y-up; quaternions use XYZW; local transforms are
T(rest_position + additive_position) R(rest_rotation * delta_rotation).
This rig uses unit scales; scale animation is intentionally not handled here.
"""
from __future__ import annotations
import math
import numpy as np

IDENTITY = np.array([0., 0., 0., 1.])


def normalize(v, fallback=None):
    a = np.asarray(v, dtype=float)
    n = float(np.linalg.norm(a))
    if not np.isfinite(a).all() or n < 1e-12:
        if fallback is None:
            raise ValueError('Cannot normalize zero/nonfinite vector')
        return normalize(fallback)
    return a / n


def quat_normalize(q):
    q = np.asarray(q, dtype=float)
    if q.shape != (4,):
        raise ValueError('Expected one XYZW quaternion')
    return normalize(q)


def quat_conjugate(q):
    x, y, z, w = quat_normalize(q)
    return np.array([-x, -y, -z, w])


def quat_multiply(a, b):
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return quat_normalize([
        aw*bx + ax*bw + ay*bz - az*by,
        aw*by - ax*bz + ay*bw + az*bx,
        aw*bz + ax*by - ay*bx + az*bw,
        aw*bw - ax*bx - ay*by - az*bz,
    ])


def quat_rotate(q, vector):
    q = quat_normalize(q)
    v = np.asarray(vector, dtype=float)
    return v + 2*np.cross(q[:3], np.cross(q[:3], v) + q[3]*v)


def quat_axis_angle(axis, radians):
    return np.r_[normalize(axis)*math.sin(radians/2), math.cos(radians/2)]


def quat_euler(x=0., y=0., z=0., *, degrees=True):
    """XYZ product, matching v1 authoring: qx * qy * qz."""
    if degrees:
        x, y, z = np.radians([x, y, z])
    return quat_multiply(quat_multiply(quat_axis_angle([1,0,0],x),
                                      quat_axis_angle([0,1,0],y)),
                         quat_axis_angle([0,0,1],z))


def quat_between(source, target):
    """Shortest rotation aligning two vectors, with stable antiparallel case."""
    a, b = normalize(source), normalize(target)
    dot = float(np.clip(np.dot(a,b), -1., 1.))
    if dot > 1 - 1e-12:
        return IDENTITY.copy()
    if dot < -1 + 1e-10:
        axis = np.cross(a, np.eye(3)[int(np.argmin(np.abs(a)))])
        return np.r_[normalize(axis), 0.]
    return quat_normalize(np.r_[np.cross(a,b), 1+dot])


def quat_to_matrix(q):
    x,y,z,w = quat_normalize(q)
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
        [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
        [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)],
    ])


def matrix_to_quat(matrix):
    """Convert an orthonormal3x3/4x4 rotation matrix to a unit XYZW quat."""
    m = np.asarray(matrix, dtype=float)[:3,:3]
    if m.shape != (3,3) or not np.isfinite(m).all():
        raise ValueError('Invalid rotation matrix')
    trace = float(np.trace(m))
    if trace > 0:
        s=2*math.sqrt(trace+1)
        q=[(m[2,1]-m[1,2])/s, (m[0,2]-m[2,0])/s,
           (m[1,0]-m[0,1])/s, .25*s]
    else:
        i=int(np.argmax(np.diag(m)))
        if i==0:
            s=2*math.sqrt(max(0,1+m[0,0]-m[1,1]-m[2,2]))
            q=[.25*s,(m[0,1]+m[1,0])/s,(m[0,2]+m[2,0])/s,(m[2,1]-m[1,2])/s]
        elif i==1:
            s=2*math.sqrt(max(0,1+m[1,1]-m[0,0]-m[2,2]))
            q=[(m[0,1]+m[1,0])/s,.25*s,(m[1,2]+m[2,1])/s,(m[0,2]-m[2,0])/s]
        else:
            s=2*math.sqrt(max(0,1+m[2,2]-m[0,0]-m[1,1]))
            q=[(m[0,2]+m[2,0])/s,(m[1,2]+m[2,1])/s,.25*s,(m[1,0]-m[0,1])/s]
    return quat_normalize(q)


def skeleton_arrays(skeleton):
    p=np.array([b.pos[:3] for b in skeleton.bone_transforms],dtype=float)
    q=np.array([b.quat.data for b in skeleton.bone_transforms],dtype=float)
    parent=np.asarray(skeleton.hierarchy_parents,dtype=int)
    return p,q,parent


def fk(skeleton, positions, rotations):
    """Return all global joint-head positions and rotations from local deltas."""
    restp,restq,parents=skeleton_arrays(skeleton)
    p=np.asarray(positions,dtype=float);q=np.asarray(rotations,dtype=float)
    if p.shape!=restp.shape or q.shape!=restq.shape:
        raise ValueError(f'Pose shapes {p.shape}/{q.shape} disagree with skeleton')
    if not np.isfinite(p).all() or not np.isfinite(q).all():
        raise ValueError('Nonfinite pose')
    wp=np.empty_like(restp);wq=np.empty_like(restq)
    for i,parent in enumerate(parents):
        localq=quat_multiply(restq[i],q[i])
        localp=restp[i]+p[i]
        if parent<0:
            wp[i]=localp;wq[i]=localq
        elif parent<i:
            wp[i]=wp[parent]+quat_rotate(wq[parent],localp)
            wq[i]=quat_multiply(wq[parent],localq)
        else:
            raise ValueError('Skeleton is not ordered parents before children')
    return wp,wq


def _set_world_rotation(skeleton, rotations, world_rotations, bone, desired):
    _,restq,parents=skeleton_arrays(skeleton)
    parent=parents[bone]
    parentq=world_rotations[parent] if parent>=0 else IDENTITY
    # desiredWorld = parentWorld * restLocal * deltaLocal
    rotations[bone]=quat_multiply(quat_conjugate(restq[bone]),
                                quat_multiply(quat_conjugate(parentq),desired))


def solve_leg(skeleton, positions, rotations, upper, lower, end, target, *,
              pole_vector=None, pole_point=None, foot_world_rotation=None):
    """Solve a2-segment chain and optionally hold the ankle's world rotation.

    Return (new_rotation_array, achieved_world_endpoint, target_error). Input
    arrays are never mutated. ``target`` is a world joint-head point. Supply a
    world bend direction in ``pole_vector`` or a point in ``pole_point``; the
    existing knee direction is the default. Unreachable goals are clamped to the
    chain's reachable sphere, and returned error reveals the remaining distance.
    No segment stretches or animates its scale.
    """
    _,_,parents=skeleton_arrays(skeleton)
    if parents[lower]!=upper or parents[end]!=lower:
        raise ValueError('Expected consecutive upper/lower/end chain')
    if pole_vector is not None and pole_point is not None:
        raise ValueError('Supply either pole_vector or pole_point')
    q=np.asarray(rotations,dtype=float).copy()
    target=np.asarray(target,dtype=float)
    if target.shape!=(3,) or not np.isfinite(target).all():
        raise ValueError('Invalid IK target')
    wp,wq=fk(skeleton,positions,q)
    start,knee,ankle=wp[upper],wp[lower],wp[end]
    a=float(np.linalg.norm(knee-start));b=float(np.linalg.norm(ankle-knee))
    if min(a,b)<1e-8:
        raise ValueError('Zero-length IK segment')
    delta=target-start;distance=float(np.linalg.norm(delta))
    direction=normalize(delta,fallback=ankle-start)
    lo=abs(a-b)+1e-9;hi=a+b-1e-9
    reach=float(np.clip(distance,lo,hi))
    endpoint=start+direction*reach
    rawpole=(np.asarray(pole_point,dtype=float)-start if pole_point is not None
             else np.asarray(pole_vector,dtype=float) if pole_vector is not None
             else knee-start)
    bend=rawpole-direction*np.dot(rawpole,direction)
    if np.linalg.norm(bend)<1e-9:
        axis=np.eye(3)[int(np.argmin(np.abs(direction)))]
        bend=axis-direction*np.dot(axis,direction)
    bend=normalize(bend)
    along=(a*a-b*b+reach*reach)/(2*reach)
    off=math.sqrt(max(0,a*a-along*along))
    desired_knee=start+direction*along+bend*off
    upper_world=quat_multiply(quat_between(knee-start,desired_knee-start),wq[upper])
    _set_world_rotation(skeleton,q,wq,upper,upper_world)
    wp,wq=fk(skeleton,positions,q)
    lower_world=quat_multiply(quat_between(wp[end]-wp[lower],endpoint-wp[lower]),wq[lower])
    _set_world_rotation(skeleton,q,wq,lower,lower_world)
    wp,wq=fk(skeleton,positions,q)
    if foot_world_rotation is not None:
        _set_world_rotation(skeleton,q,wq,end,quat_normalize(foot_world_rotation))
        wp,wq=fk(skeleton,positions,q)
    achieved=wp[end].copy()
    return q,achieved,float(np.linalg.norm(achieved-target))

# Short aliases convenient for the motion authoring script.
qmul=quat_multiply
qinv=quat_conjugate
qrotate=quat_rotate
euler=quat_euler
