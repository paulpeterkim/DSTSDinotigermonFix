"""Keep V4 openings, then push into the face for the fang strikes.

Only four exported camera clips change. The face target follows the actual
skinned muzzle, eyes, jaw and fangs; the view does not orbit with the head yaw.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import shutil

import numpy as np

from anim_codec import read, write, sample, sample_track, read_embedded_skeleton, slerp
from geom_preview import read_geom
from inspect_jaw_v3 import components
from motion_math import fk, qrotate, qinv, normalize, matrix_to_quat

ROOT = Path(__file__).resolve().parents[1]
ASPECT = 16/9
CLOSE_FOV = 40.
ZOOM_KEYS = {
    'bs01': [(0, 0), (30, 0), (42, 1), (70, 1), (90, 0), (119, 0)],
    'bs02': [(0, 0), (27, 0), (41, 1), (53, 1), (74, 0), (95, 0)],
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(folder):
    return {p.relative_to(folder).as_posix(): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}


def zoom_weight(stem, frame):
    keys = ZOOM_KEYS[stem]
    for (a, x), (b, y) in zip(keys, keys[1:]):
        if a <= frame <= b:
            t = (frame-a)/(b-a)
            # Quintic easing avoids velocity/acceleration discontinuities at keys.
            t = t*t*t*(10+t*(-15+6*t))
            return x+(y-x)*t
    return 0.


def look_at(position, target):
    back = normalize(np.asarray(position)-target)
    right = normalize(np.cross([0., 1., 0.], back))
    up = normalize(np.cross(back, right))
    return matrix_to_quat(np.stack((right, up, back), axis=1))


def face_points(geom, skeleton):
    count = len(skeleton.bone_transforms)
    bindp, bindq = fk(skeleton, np.zeros((count, 3)), np.tile([0., 0., 0., 1.], (count, 1)))
    chosen_components = {0: {2682, 2193, 5488, 2264, 5560, 2308, 5605}, 1: {2924, 6183, 22291}}
    positions, influences, selection = [], [], []
    for mi, object_name in [(0, 'chr135'), (1, 'chr344')]:
        mesh = geom.meshes[mi]
        vertices, points, groups = components(mesh)
        by_id = {min(group): group for group in groups}
        ids = set().union(*(by_id[c] for c in chosen_components[mi]))
        ids.update(i for i, vertex in enumerate(vertices)
                   if any(mesh.matrix_palette[int(b)] == 7 and w > .05
                          for b, w in zip(vertex.indices, vertex.weights)))
        ids = sorted(ids)
        selection.append({'name': object_name, 'index': mi, 'vertex_indices': ids,
                          'positions_game': points[ids].tolist()})
        for i in ids:
            vertex = vertices[i]
            weights = np.zeros(count)
            for index, weight in zip(vertex.indices, vertex.weights):
                weights[int(mesh.matrix_palette[int(index)])] += weight
            weights /= weights.sum()
            positions.append(points[i]); influences.append(weights)
    positions, influences = np.array(positions), np.array(influences)
    bindings = []
    for bone in range(count):
        ids = np.flatnonzero(influences[:, bone] > 0)
        if len(ids):
            bindings.append((bone, ids, qrotate(qinv(bindq[bone]), positions[ids]-bindp[bone]), influences[ids, bone]))
    return bindings, len(positions), {'coordinate_system': 'game Y-up', 'meshes': selection}


def skinned_face(bindings, count, positions, rotations):
    result = np.zeros((count, 3))
    for bone, ids, local, weights in bindings:
        result[ids] += (positions[bone]+qrotate(rotations[bone], local))*weights[:, None]
    return result


def projected_bounds(points, camera, rotation, fov):
    local = qrotate(qinv(rotation), points-camera)
    depth = -local[:, 2]
    tanx = math.tan(math.radians(fov)/2)
    ndc = local[:, :2]/depth[:, None]/np.array([2*tanx, 2*tanx/ASPECT])+.5
    return {'min': ndc.min(axis=0).tolist(), 'max': ndc.max(axis=0).tolist(),
            'min_depth': float(depth.min()), 'height': float(np.ptp(ndc[:, 1])),
            'width': float(np.ptp(ndc[:, 0]))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT/'modified_v4')
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v5')
    parser.add_argument('--baseline-report', type=Path, default=ROOT/'outputs_v4/validation.json')
    parser.add_argument('--v4-effects', type=Path, default=ROOT/'work/v4/effects.json')
    args = parser.parse_args()
    baseline = json.loads(args.baseline_report.read_text())
    if not baseline['passed'] or inventory(args.source) != baseline['asset_sha256']:
        raise ValueError('Source is not the validated V4 mod')
    if sha(args.v4_effects) != baseline['effects_diagnostics_sha256']:
        raise ValueError('V4 landing shake provenance differs from the baseline')
    if args.destination.exists():
        raise FileExistsError('Destination exists; preserve older builds and use a new folder')
    patch = args.source/'dsts-loader/patch'
    skeleton = read_embedded_skeleton(patch/'chr424857.geom')
    geom = read_geom(patch/'chr424857.geom')
    bindings, count, selection = face_points(geom, skeleton)
    out = ROOT/'work/v5'; out.mkdir(parents=True, exist_ok=True)
    selection_path = out/'face_selection.json'
    selection['geometry_sha256'] = sha(patch/'chr424857.geom')
    selection_path.write_text(json.dumps(selection, indent=2)+'\n')
    shake = {Path(c['path']).name: {s['frame']: np.array(s['local_offset']) for s in c['samples']}
             for c in json.loads(args.v4_effects.read_text())['shake']['cameras']}
    shutil.copytree(args.source, args.destination, copy_function=shutil.copy2)
    diagnostics = []
    for stem in ('bs01', 'bs02'):
        actor = read(patch/f'chr424857_{stem}.anim', expected_bones=52)
        faces, head_forward = [], []
        for f in range(actor._source_frame_count):
            transforms = [sample(actor, bone, f) for bone in range(52)]
            wp, wq = fk(skeleton, np.array([t[0] for t in transforms]), np.array([t[1] for t in transforms]))
            faces.append(skinned_face(bindings, count, wp, wq))
            head_forward.append(qrotate(wq[6], [0., 0., 1.]))
        for side in ('pc', 'em'):
            name = f'cam_chr424857_{stem}_{side}.anim'
            old = read(patch/name, expected_bones=2); new = deepcopy(old)
            sign = 1 if side == 'pc' else -1
            samples = []
            last = None
            for f, points in enumerate(faces):
                weight = zoom_weight(stem, f)
                bp, bq, _ = sample(old, 0, f)
                bfov = float(sample_track(old.float_channels[0], f))
                # Lower the eye line as the face tips down, keeping the mouth
                # readable and the camera above the floor. Yaw stays frontal.
                elevation = max(-.18, .22+.6*min(0., float(head_forward[f][1])))
                for _ in range(8):
                    direction = normalize([sign*math.sin(math.radians(12)), elevation, math.cos(math.radians(12))])
                    closeq = look_at(direction, np.zeros(3))
                    oriented = qrotate(qinv(closeq), points)
                    center = (oriented.min(axis=0)+oriented.max(axis=0))/2
                    relative = oriented-center
                    tanx = math.tan(math.radians(CLOSE_FOV)/2)
                    distance = max(2.15, float(np.max(relative[:, 2]+np.abs(relative[:, 0])/(.82*tanx))),
                                   float(np.max(relative[:, 2]+np.abs(relative[:, 1])/(.74*tanx/ASPECT))))
                    target = qrotate(closeq, center)
                    closep = target+direction*distance
                    if closep[1] >= .20:
                        break
                    required_y = float(np.clip((.205-target[1])/distance, -.8, .8))
                    elevation = required_y/math.sqrt(1-required_y*required_y)
                if closep[1] < .199:
                    raise ValueError('Close camera went below its floor clearance')
                local_shake = shake[name][f] if stem == 'bs02' else np.zeros(3)
                q = slerp(bq, closeq, weight)
                p = (bp-qrotate(bq, local_shake))*(1-weight)+closep*weight+qrotate(q, local_shake)
                fov = bfov*(1-weight)+CLOSE_FOV*weight
                if weight > 0:
                    if last is not None and np.dot(last, q) < 0: q = -q
                    new.positions[0][f] = p.tolist()
                    new.rotations[0][f] = q.tolist()
                    new.float_channels[0][f] = fov
                last = q
                samples.append({'frame': f, 'zoom_weight': weight, 'face_target': target.tolist(),
                                'close_distance': distance, 'fov': fov,
                                'baseline_face_bounds': projected_bounds(points, bp, bq, bfov),
                                'face_bounds': projected_bounds(points, p, q, fov)})
            rebuilt = write(new, args.destination/'dsts-loader/patch'/name, preserve_duration=True, expected_bones=2)
            diagnostics.append({'path': 'dsts-loader/patch/'+name, 'stem': stem, 'side': side,
                                'frames': rebuilt._source_frame_count, 'fps': rebuilt.playback_rate,
                                'samples': samples})
            print(name, 'face close-up authored; opening and final handoff preserved', flush=True)
    report = {'revision': 5, 'source_asset_sha256': inventory(args.source),
              'baseline_report_sha256': sha(args.baseline_report), 'face_selection_sha256': sha(selection_path),
              'v4_shake_sha256': sha(args.v4_effects), 'aspect_ratio': ASPECT,
              'close_fov_degrees': CLOSE_FOV, 'zoom_keys': ZOOM_KEYS, 'cameras': diagnostics,
              'notes': ['Only camera clips change; V4 effects, balance, actor motion and jaw binding are retained.',
                        'Face bounds use the actual skinned muzzle, cheek plates, eyes, lower jaw and upper fangs.',
                        'The close view keeps a fixed near-frontal yaw, rather than orbiting with head turns.']}
    (out/'cameras.json').write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
