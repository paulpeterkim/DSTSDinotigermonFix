"""Third-pass fang choreography with independent limb actions: articulated poses, timed contacts, planted IK.

Game Y-up. Bone deltas are baked through the inspected feature/refactor codec.
Each attack has a deliberately authored length, with matching PC/EM cameras.
This file contains no victim, collision, or engine-event implementation.
"""
from pathlib import Path
from copy import deepcopy
import json,math
import numpy as np
from anim_codec import read,write,sample,sample_track,read_embedded_skeleton,slerp
from motion_math import fk,solve_leg,qmul,qinv,qrotate,euler,normalize,matrix_to_quat
from author_animations import look_quat

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'original/dsts-loader/patch'
DST=ROOT/'modified_v3/dsts-loader/patch'
REPORT=ROOT/'work/v3/choreography.json'
SKEL=read_embedded_skeleton(SRC/'chr424857.geom')
NEUTRAL=read(SRC/'chr424857_bn01.anim')
P0=np.array([sample(NEUTRAL,b,0)[0] for b in range(52)])
Q0=np.array([sample(NEUTRAL,b,0)[1] for b in range(52)])
WP0,WQ0=fk(SKEL,P0,Q0)
FORWARD=qrotate(WQ0[6],[0,0,1]);FORWARD[1]=0;FORWARD=normalize(FORWARD)
RIGHT=normalize(np.cross([0,1,0],FORWARD))
LEGS=[(25,26,27),(30,31,32),(41,42,43),(46,47,48)]


def curve(keys,frame):
    """Shape-preserving cubic interpolation, with continuous key velocities.

    Unlike global smoothstep, compatible adjacent segments flow through a key.
    Impact/hold extrema intentionally stop or reverse the relevant channel.
    """
    a=np.asarray(keys,dtype=float);x=a[:,0];y=a[:,1:]
    if frame<=x[0]:return y[0].copy()
    if frame>=x[-1]:return y[-1].copy()
    h=np.diff(x);d=np.diff(y,axis=0)/h[:,None]
    m=np.zeros_like(y)
    m[0]=d[0];m[-1]=d[-1]
    for i in range(1,len(x)-1):
        same=d[i-1]*d[i]>0
        w1=2*h[i]+h[i-1];w2=h[i]+2*h[i-1]
        m[i,same]=(w1+w2)/(w1/d[i-1,same]+w2/d[i,same])
    # Zero endpoint velocity avoids popping on entry/return to idle.
    m[0]=0;m[-1]=0
    i=int(np.searchsorted(x,frame,side='right')-1)
    t=(frame-x[i])/h[i]
    return ((2*t**3-3*t*t+1)*y[i]+(t**3-2*t*t+t)*h[i]*m[i]
            +(-2*t**3+3*t*t)*y[i+1]+(t**3-t*t)*h[i]*m[i+1])


def scalar(keys,f):return float(curve(keys,f)[0])

# frame, height, travel, body pitch, body yaw, body roll,
# chest pitch, chest yaw, head pitch, head yaw, head roll, jaw opening, tuck.
GROUND=[
(0,   0,    0,   0,  0, 0,  0,  0,   0,   0, 0,  0,  0),
(9, -.19, -.14,  -5, -3, 3, -5, -3, -15,  -4, 3, 10,  0),
(15,-.16, -.12, -10, -3, 3, -4, -3, -24,  -4, 4, 22,  0),
(23, .30,  .66,   3, -1, 1, -4,  0, -19,   0, 0, 20, 34),
(28,-.11,  .96,   3,  1,-3,  1,  1, -14,   0, 0, 18,  0),
(33,-.16,  .98,   1,  0, 1,  1,  0, -10,   0, 0, 18,  0),
(39,-.12,  .97,  -2, -2, 1, -3, -2, -30,  -3, 5, 24,  0),
(44,-.08,  .99,  -3, -2, 1, -4, -2, -34,  -3, 5, 27,  0),
(48, .03, 1.04,   2,  1,-1,  4,  0,  25,   0, 0, -5,  0),
(50, .03, 1.04,   3,  1,-1,  5,  1,  33,   0, 0, -7,  0),
(53,-.01, 1.02,   2,  0, 0,  3,  0,  29,   0, 0, -6,  0),
(59,-.03,  .96,   0,-10, 4,  0, -7,   5, -34,-9, -5,  0),
(62,-.04,  .98,   1, -7, 2,  2, -4,  10, -25,-6, -5,  0),
(67,-.03,  .96,  -1, 10,-4,  1,  7,   8,  32, 9, -5,  0),
(70,-.04,  .96,  -1,  7,-2,  0,  4,   7,  22, 5, -5,  0),
(76,-.14,  .98,  -4, -2, 1, -4, -2, -32,  -7,-8,  0,  0),
(82,-.08, 1.00,  -3, -1, 0, -1, -1,  -8,  -4, 0,  8,  0),
(95, .00, 1.02,  -2,  0, 0, -1,  0,  -4,   0, 0,  4,  0),
(108,-.03,1.02,  1,  0, 0,  0,  0,   2,   0, 0,  0,  0),
(119, 0, 1.02,   0,  0, 0,  0,  0,   0,   0, 0,  0,  0),
]
HIGHLAND=[
(0,   0,    0,   0,  0, 0,  0, 0,  0,  0, 0,  0,  0),
(10,-.24,-.10,  -7, -4, 3, -6,-2,-22, -3, 2,  8,  0),
(16,-.26,-.15, -13, -6, 4, -8,-3,-30, -4, 4, 18,  0),
(21, .15, .08, -24, -6, 6,-10,-3,-22, -3, 5, 22, 36),
(28,2.22, .50, -18,-10,10, -4,-4,-15, -5, 5, 24, 63),
(33,2.80, .72, -22,-13,12, -4,-5,-18, -7, 6, 25, 68),
(36,2.70, .86, -12,-10,10, -2,-3,-20, -5, 6, 24, 58),
(39,2.12,1.03,  13, -3, 6,  3, 0,-12, -1, 1, 18, 36),
(42, .92,1.35,  37,  5,-7,  4, 2, 20,  3,-4,  2, 60),
(44, .40,1.48,  31,  8,-9,  5, 3, 23,  4,-6, -5, 40),
(47,-.04,1.50,  10,  6,-5,  4, 2, 20,  3,-3, -6,  0),
(51,-.15,1.47,   3,  3,-2,  2, 0, 17,  1,-1, -5,  0),
(57, .02,1.43,  -3,  1, 1, -4,-1, -8, -2, 0,  2,  0),
(64,-.04,1.48,  -4,  0, 0, -2, 0, -6,  0, 0,  6,  0),
(76, .00,1.49,  -3,  0, 0, -2, 0, -2,  0, 0,  3,  0),
(86,-.03,1.50,   2,  0, 0,  1, 0,  1,  0, 0,  0,  0),
(95,  0,1.50,   0,  0, 0,  0, 0,  0,  0, 0,  0,  0),
]


def foot_track(stem,index,f):
    """World-space ankle trajectories; constant runs are real foot plants."""
    base=WP0[LEGS[index][2]].copy()
    side=1 if index%2==0 else -1
    if stem=='bs01':
        land=28 if index==0 else 31 if index==1 else 33+index
        spread=.10 if index<2 else .04
        travel=1.02
        lift=.45 if index<2 else .32
        release=81 if index==0 else 84 if index==1 else 88+index
        middle=(land+16)/2
        # Outputs: forward offset, height, side spread. Front feet arrive first;
        # rear feet catch the weight later and all four then hold their anchors.
        keys=[(0,0,0,0),(FLIGHT_WINDOWS[stem][index][0]-1,0,0,0),(21,travel*.55,lift,spread*.6),
              (land,travel,0,spread),(release,travel,0,spread),
              (release+7,1.01,.14,spread*.5),
              (105+index*2,1.02,0,0),(119,1.02,0,0)]
    else:
        # Flight shape is authored in FK; only use target curves for ground
        # compression and the staggered landing/recovery.
        land=46 if index==0 else 47 if index==1 else 50+index-2
        travel=1.48 if index<2 else 1.43
        spread=.13 if index<2 else .09
        keys=[(0,0,0,0),(FLIGHT_WINDOWS[stem][index][0]-1,0,0,0),(land-6,travel,.44,spread),
              (land,travel,0,spread),(63+index,travel,0,spread),
              (72+index*2,1.49,.15,spread*.6),
              (88+index,1.50,0,0),(95,1.50,0,0)]
    forward,height,spread=curve(keys,f)
    forward*=4.14/(1.02 if stem=='bs01' else 1.50)
    return base+FORWARD*forward+np.array([0,height,0])+RIGHT*side*spread


# V3 uses authored per-limb actions instead of one common tuck scalar. The
# shoulder/hip tracks change the elbow/knee silhouette while world-space paw
# contacts remain constrained. Air reach and paw-roll tracks are phase-specific.
TOES=[28,33,44,49]
FLIGHT_WINDOWS={
    'bs01':[(17,26),(17,26),(18,32),(18,32)],
    'bs02':[(19,43),(19,43),(21,48),(21,48)],
}

GROUND_FRONT=[
 [(0,0,0,0),(9,5,-2,3),(15,10,-3,5),(19,-14,4,-5),(23,-18,-2,-7),
  (28,-3,0,2),(33,8,-4,4),(39,12,-3,6),(44,9,-3,3),
  (48,-9,1,-4),(53,-4,1,0),(59,10,5,5),(64,2,0,1),
  (67,-8,-4,-3),(73,5,2,2),(81,-7,0,-3),(91,3,0,1),(106,0,0,0),(119,0,0,0)],
 [(0,0,0,0),(9,2,1,-1),(15,3,1,-3),(19,2,-3,5),(23,-10,3,4),
  (28,-7,2,-3),(33,1,3,-2),(39,-5,3,-4),(44,4,2,-3),
  (48,10,-2,4),(53,6,-2,2),(59,-7,-4,-5),(64,3,1,-2),
  (67,9,5,4),(73,4,-1,-2),(81,3,0,2),(94,-6,0,-3),(108,0,0,0),(119,0,0,0)],
]
GROUND_HIND=[
 [(0,0,0,0),(10,-5,-2,3),(16,-10,-3,4),(20,15,3,-4),(24,8,1,-2),
  (32,-3,0,2),(39,3,-1,2),(48,-3,1,-2),(59,4,2,2),(67,-3,-2,-2),
  (76,2,0,1),(90,-5,0,3),(105,0,0,0),(119,0,0,0)],
 [(0,0,0,0),(10,-2,2,-2),(16,-7,3,-3),(20,9,-2,3),(25,13,-1,4),
  (32,1,0,-1),(39,-2,1,-2),(48,4,-1,2),(59,-3,-2,-2),(67,4,2,2),
  (76,-1,0,-1),(94,-6,0,-3),(107,0,0,0),(119,0,0,0)],
]
HIGH_FRONT=[
 [(0,0,0,0),(10,8,-3,5),(16,14,-5,7),(21,-17,4,-7),(27,-12,-3,-9),
  (33,-6,4,-5),(37,4,1,2),(39,0,0,0),(42,0,0,0),
  (44,9,-3,5),(48,-10,2,-5),(52,6,-2,3),(58,-3,1,-2),
  (65,3,0,2),(75,-5,0,-2),(87,0,0,0),(95,0,0,0)],
 [(0,0,0,0),(10,4,2,-3),(16,9,4,-5),(23,-12,-3,6),(29,-18,4,8),
  (33,-10,-3,6),(37,2,-1,-2),(39,0,0,0),(42,0,0,0),
  (44,3,2,-3),(48,11,-2,5),(53,-7,2,-4),(60,4,-1,2),
  (66,-2,0,-1),(78,-5,0,2),(89,0,0,0),(95,0,0,0)],
]
HIGH_HIND=[
 [(0,0,0,0),(10,-7,-2,4),(17,-12,-4,5),(22,18,3,-5),(28,10,1,-3),
  (34,4,-2,2),(39,0,0,0),(42,0,0,0),(47,7,-2,4),
  (51,-8,2,-4),(57,5,-1,3),(64,-2,0,-1),(77,-4,0,2),(90,0,0,0),(95,0,0,0)],
 [(0,0,0,0),(10,-4,2,-3),(17,-9,4,-4),(23,13,-2,4),(30,16,-2,5),
  (35,6,2,-2),(39,0,0,0),(42,0,0,0),(48,3,2,-2),
  (52,9,-2,4),(59,-5,1,-3),(66,3,0,1),(79,-4,0,-2),(91,0,0,0),(95,0,0,0)],
]


def is_flight(stem,index,f):
    start,end=FLIGHT_WINDOWS[stem][index]
    return start<=f<end


def shoulder_angles(stem,index,f):
    tracks=(GROUND_FRONT if index<2 else GROUND_HIND) if stem=='bs01' else (HIGH_FRONT if index<2 else HIGH_HIND)
    return curve(tracks[index%2],f)


def air_detail(stem,index,f):
    """Return reach(up/forward/side), elbow flare, paw pitch/roll and toe curl.

    All additions vanish by Highland f39, protecting the verified fang-first
    descent at f41-42. Ground's last airborne pose lifts the toes rather than
    allowing full idle limb extension to sweep below the floor.
    """
    side=1 if index%2==0 else -1
    delay=0 if index%2==0 else 1.5
    t=f-delay
    if stem=='bs01':
        if index<2:
            data=curve([(0,0,0,0,0,0,0,0),(17,0,0,0,0,0,0,0),
                        (20,.09,.13,.035,14,-13,8,-15),
                        (23,.05,.09,.045,8,-9,5,-10),
                        (25,0,.04,0,0,-4,0,-3),(26,0,0,0,0,0,0,0),
                        (119,0,0,0,0,0,0,0)],t)
        else:
            data=curve([(0,0,0,0,0,0,0,0),(19,0,0,0,0,0,0,0),
                        (23,-.09,.13,.025,10,-10,6,-12),
                        (27,-.04,.10,.02,7,-7,4,-7),
                        (31,0,.06,0,0,-3,0,-2),(32,0,0,0,0,0,0,0),
                        (119,0,0,0,0,0,0,0)],t)
    elif index<2:
        data=curve([(0,0,0,0,0,0,0,0),(19,0,0,0,0,0,0,0),
                    (24,.08,.10,.045,18,-17,10,-18),
                    (30,-.07,.16,.05,10,-24,15,-22),
                    (34,-.02,.11,.025,13,-14,7,-13),
                    (37,.03,.04,.01,5,-5,2,-4),
                    (39,0,0,0,0,0,0,0),(95,0,0,0,0,0,0,0)],t)
    else:
        data=curve([(0,0,0,0,0,0,0,0),(21,0,0,0,0,0,0,0),
                    (25,-.11,.10,.03,11,-12,8,-15),
                    (31,-.03,.15,.045,17,-18,10,-20),
                    (35,.03,.08,.02,8,-10,4,-10),
                    (39,0,0,0,0,0,0,0),(42,0,0,0,0,0,0,0),
                    (45,.03,.06,.02,5,-5,3,-5),(48,0,0,0,0,0,0,0),
                    (95,0,0,0,0,0,0,0)],t)
    # delay applies only within the flourish, never to the critical cut boundary.
    if stem=='bs02' and 39<=f<=42:
        data=np.zeros(7)
    forward,up,lateral,flare,paw_pitch,paw_roll,toe=data
    return np.array([forward,up,lateral*side]),flare*side,paw_pitch,paw_roll*side,toe


def heel_roll(stem,index,f):
    """Positive heel angle; the toe's world position/orientation remains fixed."""
    if stem=='bs01':
        if index<2:
            keys=[(0,0),(12,0),(15,7),(16,14),(17,0),
                  (26,7 if index==0 else 11),(28 if index==0 else 31,0),
                  (76,0),(80+index*3,12),(84+index*3,0),(119,0)]
        else:
            keys=[(0,0),(10,0),(15,7),(18,22),(19,0),
                  (32,8),(35+index-2,0),(82,0),(89+index*2,13),
                  (95+index*2,0),(119,0)]
    else:
        if index<2:
            keys=[(0,0),(11,0),(16,9),(18,19),(19,0),
                  (43,9 if index==0 else 13),(46 if index==0 else 47,0),
                  (60,0),(66+index,10),(71+index,0),(95,0)]
        else:
            keys=[(0,0),(13,0),(17,9),(20,24),(21,0),
                  (48,10),(50+index-2,0),(64,0),(70+index,11),(76+index,0),(95,0)]
    return scalar(keys,f)


def stance_target(stem,index,f):
    """Roll the heel about a fixed toe; the claw itself keeps a flat plant."""
    target=foot_track(stem,index,f)
    end=LEGS[index][2];toe=TOES[index]
    angle=heel_roll(stem,index,f)
    footq=qmul(WQ0[end],euler(angle,0,0))
    toe_local=np.asarray(SKEL.bone_transforms[toe].pos[:3])+P0[toe]
    target=target+qrotate(WQ0[end],toe_local)-qrotate(footq,toe_local)
    return target,footq,angle


def bounded_flight_target(wp,upper,lower,end,target):
    """Artist target inside the unstretched two-bone reach envelope."""
    a=np.linalg.norm(wp[lower]-wp[upper]);b=np.linalg.norm(wp[end]-wp[lower])
    vector=target-wp[upper];length=np.linalg.norm(vector)
    clamped=np.clip(length,abs(a-b)+.01,a+b-.008)
    return wp[upper]+normalize(vector)*clamped


JAW_NEUTRAL_ANGLE=float(np.degrees(2*np.arctan2(Q0[7,0],Q0[7,3])))
JAW_OPEN_ANGLE=30.
JAW_CLOSED_ANGLE=-6.


def jaw_angle(stem,f):
    """Absolute parent-X jaw angle, isolated for the new skinning calibration.

    Head-fixed review of the repaired binding established a safe close at -6
    degrees and a clear open at +30 degrees. Upper fangs remain head-bound.
    """
    n,o,c=JAW_NEUTRAL_ANGLE,JAW_OPEN_ANGLE,JAW_CLOSED_ANGLE
    if stem=='bs01':
        keys=[(0,n),(9,n),(15,n+(o-n)*.65),(23,n+(o-n)*.55),
              (33,n+(o-n)*.65),(39,o),(44,o),(48,c),(50,c),(53,c),
              (59,c),(67,c),(70,c),(76,n+(o-n)*.30),(82,n),(119,n)]
    else:
        keys=[(0,n),(10,n+(o-n)*.5),(16,o),(21,o),(28,o),(33,o),(36,o),
              (39,n+(o-n)*.75),(42,c),(44,c),(47,c),(51,c),
              (57,n+(o-n)*.25),(64,n),(95,n)]
    return scalar(keys,f)


# Stable, anatomically oriented two-bone IK. A segment direction alone leaves
# its axial twist undetermined. Canonical joint-plane frames fix that twist and
# avoid the old shortest-vector solver's branch flips near antiparallel poses.
RESTP=np.array([b.pos[:3] for b in SKEL.bone_transforms])
RESTQ=np.array([b.quat.data for b in SKEL.bone_transforms])
PARENTS=np.array(SKEL.hierarchy_parents)
NORMALS=[normalize(np.cross(WP0[e]-WP0[u],WP0[l]-WP0[u])) for u,l,e in LEGS]


def joint_frame(direction,normal):
    x=normalize(direction)
    z=normal-x*np.dot(normal,x)
    if np.linalg.norm(z)<1e-7:
        fallback=np.eye(3)[int(np.argmin(np.abs(x)))]
        z=fallback-x*np.dot(fallback,x)
    z=normalize(z);y=normalize(np.cross(z,x))
    return np.stack((x,y,z),axis=1)


def set_world_rotation(q,wq,bone,wanted):
    parent=PARENTS[bone]
    parentq=wq[parent] if parent>=0 else np.array([0.,0.,0.,1.])
    q[bone]=qmul(qinv(RESTQ[bone]),qmul(qinv(parentq),wanted))


def solve_limb(p,q,index,target,normal,footq):
    upper,lower,end=LEGS[index]
    q=q.copy();wp,wq=fk(SKEL,p,q)
    start=wp[upper];requested=np.asarray(target)
    a=np.linalg.norm(wp[lower]-start);b=np.linalg.norm(wp[end]-wp[lower])
    vector=requested-start;length=np.linalg.norm(vector);direction=normalize(vector)
    reach=float(np.clip(length,abs(a-b)+1e-8,a+b-1e-8))
    endpoint=start+direction*reach
    projected=normal-direction*np.dot(normal,direction)
    if np.linalg.norm(projected)<1e-7:
        fallback=np.eye(3)[int(np.argmin(np.abs(direction)))]
        projected=fallback-direction*np.dot(fallback,direction)
    normal=normalize(projected)
    bend=normalize(np.cross(normal,direction))
    along=(a*a-b*b+reach*reach)/(2*reach)
    side=math.sqrt(max(0,a*a-along*along))
    knee=start+direction*along+bend*side
    # Map each neutral anatomical frame to the desired frame. This specifies
    # both the long axis AND its twist without relying on the current FK tuck.
    for bone,neutral_vector,desired_vector in [
        (upper,WP0[lower]-WP0[upper],knee-start),
        (lower,WP0[end]-WP0[lower],endpoint-knee),
    ]:
        mapping=joint_frame(desired_vector,normal) @ joint_frame(neutral_vector,NORMALS[index]).T
        wanted=qmul(matrix_to_quat(mapping),WQ0[bone])
        set_world_rotation(q,wq,bone,wanted)
        wp,wq=fk(SKEL,p,q)
    set_world_rotation(q,wq,end,footq)
    wp,wq=fk(SKEL,p,q)
    achieved=wp[end].copy()
    return q,achieved,float(np.linalg.norm(achieved-requested))


def contact_frame(stem,index):
    return ([28,31,35,36] if stem=='bs01' else [46,47,50,51])[index]


def flight_weight(stem,index,f):
    """Smooth heel release and landing reach in IK target space, never q-space."""
    start,end=FLIGHT_WINDOWS[stem][index];land=contact_frame(stem,index)
    if f<start-1 or f>=land:return 0.
    release_frames=6 if stem=='bs02' else 4
    if f<start+release_frames-1:
        t=(f-(start-1))/release_frames
        return t*t*(3-2*t)
    if f<end-1:return 1.
    t=(f-(end-1))/(land-(end-1))
    return 1.-t*t*(3-2*t)


def blend_reachable_target(wp,index,stance,airborne,weight):
    """Blend an unloaded reach by knee flex, avoiding full-extension clamp pops.

    Cartesian interpolation toward a distant former support point can stay on
    the reach boundary until the last frame, then fold an elbow abruptly. Here
    the endpoint radius follows the explicitly interpolated internal knee angle.
    A planted foot (weight0) still uses its exact original world target.
    """
    if weight<1e-10:return stance
    upper,lower,end=LEGS[index]
    a=np.linalg.norm(wp[lower]-wp[upper]);b=np.linalg.norm(wp[end]-wp[lower])
    lo=abs(a-b)+.01;hi=a+b-.008
    vs=stance-wp[upper];va=airborne-wp[upper]
    ds=float(np.clip(np.linalg.norm(vs),lo,hi));da=float(np.clip(np.linalg.norm(va),lo,hi))
    ks=math.acos(float(np.clip((a*a+b*b-ds*ds)/(2*a*b),-1,1)))
    ka=math.acos(float(np.clip((a*a+b*b-da*da)/(2*a*b),-1,1)))
    knee=ks*(1-weight)+ka*weight
    distance=math.sqrt(max(0,a*a+b*b-2*a*b*math.cos(knee)))
    direction=normalize(normalize(vs)*(1-weight)+normalize(va)*weight)
    return wp[upper]+direction*distance


def leg_spec(stem,index,f,p,q,wp,wq,h,travel,tuck):
    upper,lower,end=LEGS[index];toe=TOES[index]
    stance,stanceq,heel=stance_target(stem,index,f)
    weight=flight_weight(stem,index,f)
    body_delta=qmul(wq[2],qinv(WQ0[2]))
    coefficient=.15 if stem=='bs01' and index<2 else .65 if stem=='bs02' and index<2 else .52
    compression=1.-coefficient*min(1.,tuck/68.)
    vector=qrotate(body_delta,WP0[end]-WP0[upper])*compression
    detail,flare,paw_pitch,paw_roll,toe_curl=air_detail(stem,index,f)
    extra=FORWARD*detail[0]+np.array([0,detail[1],0])+RIGHT*detail[2]
    airborne=wp[upper]+vector+qrotate(body_delta,extra)
    if stem=='bs01':airborne[1]=max(airborne[1],WP0[end,1]+.14)
    airq=qmul(body_delta,WQ0[end])
    if stem=='bs02' and index<2 and f>=36:
        aim=min(1.,(f-36)/6.)
        airq=slerp(airq,qmul(euler(-20,0,0),WQ0[end]),aim)
    airq=qmul(airq,euler(paw_pitch,0,paw_roll))
    target=blend_reachable_target(wp,index,stance,airborne,weight)
    footq=slerp(stanceq,airq,weight)
    # Continuous anatomical knee-plane normals. Entry/exit does not replace one
    # projected knee vector with another and cannot flip the elbow plane.
    stance_normal=qrotate(euler(0,0,float(shoulder_angles(stem,index,f)[2])*.55),NORMALS[index])
    air_normal=qrotate(euler(0,0,flare),qrotate(body_delta,NORMALS[index]))
    normal=normalize(stance_normal*(1-weight)+air_normal*weight)
    toe_local=qmul(RESTQ[toe],qmul(Q0[toe],euler(toe_curl,0,0)))
    air_toe_world=qmul(airq,toe_local)
    toe_world=slerp(WQ0[toe],air_toe_world,weight)
    mode=('stance' if weight<1e-10 else 'release' if f<FLIGHT_WINDOWS[stem][index][0]+(6 if stem=='bs02' else 4)
          else 'flight' if f<FLIGHT_WINDOWS[stem][index][1] else 'landing_reach')
    return {'target':target,'footq':footq,'toe_world':toe_world,'normal':normal,
            'weight':weight,'heel':heel,'mode':mode,'stance_target':stance}


def pose(stem,phase,f):
    v=curve(phase,f)
    h,travel,pitch,yaw,roll,chest,cyaw,head,hyaw,hroll,jaw,tuck=v
    p=P0.copy();q=Q0.copy()
    travel=travel*(4.14/(1.02 if stem=='bs01' else 1.50)) if travel>0 else travel
    p[2]+=FORWARD*travel+np.array([0,h,0])
    offsets={2:(pitch,yaw,roll),3:(chest*.25,cyaw*.2,0),4:(chest*.3,cyaw*.3,0),
             5:(chest*.45,cyaw*.5,0),6:(head,hyaw,hroll),7:(jaw,0,0),
             34:(-pitch*.16,0,-roll*.35),
             24:(-tuck*.25,0,-tuck*.08),29:(-tuck*.25,0,tuck*.08),
             25:(-tuck*.20,0,0),30:(-tuck*.20,0,0),
             26:(-tuck*.70,0,0),31:(-tuck*.70,0,0),
             27:(tuck*.55,0,0),32:(tuck*.55,0,0),
             40:(tuck*.10,0,0),45:(tuck*.10,0,0),
             41:(tuck*.90,0,0),46:(tuck*.90,0,0),
             42:(-tuck*.90,0,0),47:(-tuck*.90,0,0),
             43:(tuck*.12,0,0),48:(tuck*.12,0,0)}
    lag=curve(phase,max(0,f-3));prev=curve(phase,max(0,f-1))
    # Mane, feelers, tail lag behind angular acceleration rather than moving
    # as one solid block with the head.
    head_speed=head-prev[8];turn_speed=hyaw-prev[9]
    envelope=math.sin(math.pi*f/(phase[-1][0]))**2
    for b in (8,9,10,11):offsets[b]=(-head_speed*.7*envelope, -turn_speed*.5*envelope,0)
    for chain in [(12,13,14),(15,16,17),(18,19,20),(21,22,23)]:
        sign=1 if chain[0]<18 else -1
        for n,b in enumerate(chain):
            offsets[b]=((lag[8]-head)*.20*(n+1)*envelope,-hyaw*.08*(n+1)*envelope,
                        sign*envelope*math.sin(f*.20-n*.8)*2.0)
    feeler_lift=scalar([(0,0),(10,12),(16,27),(20,22),(27,0),(95,0)],f) if stem=='bs02' else scalar([(0,0),(9,12),(15,25),(23,0),(33,0),(44,14),(50,0),(119,0)],f)
    for b in (12,15,18,21):
        angles=offsets[b];offsets[b]=(angles[0]+feeler_lift,angles[1],angles[2])
    for n,b in enumerate((35,36,37,38,39)):
        tail_lag=curve(phase,max(0,f-3-n*2))
        offsets[b]=(-tail_lag[2]*.13*envelope,-tail_lag[3]*.24*envelope,
                    envelope*math.sin(f*.11-n*.65)*2)
    for index,base in enumerate((24,29,40,45)):
        offsets[base]=np.asarray(offsets[base])+shoulder_angles(stem,index,f)
    for b,xyz in offsets.items():q[b]=qmul(q[b],euler(*xyz))
    q[7]=euler(jaw_angle(stem,f),0,0)
    # Toe-supported push-off and landing reaches are blended as reachable world
    # IK targets. No local joint quaternion is blended after the solve.
    wp,wq=fk(SKEL,p,q)
    drop=0.
    for index,(upper,lower,end) in enumerate(LEGS):
        target,_,_=stance_target(stem,index,f)
        # A reaching/releasing foot is not a support contact. In particular,
        # do not lower the trunk toward its ghost stance target during launch.
        support=1. if flight_weight(stem,index,f)<1e-10 else 0.
        if support<=1e-10:continue
        length=np.linalg.norm(wp[lower]-wp[upper])+np.linalg.norm(wp[end]-wp[lower])-.005
        horizontal=np.linalg.norm((wp[upper]-target)[[0,2]])
        if horizontal<length and wp[upper,1]>target[1]:
            max_y=target[1]+math.sqrt(max(0,length*length-horizontal*horizontal))
            drop=min(drop,(max_y-wp[upper,1])*support)
    p[2,1]+=drop
    wp,wq=fk(SKEL,p,q)
    specs=[leg_spec(stem,i,f,p,q,wp,wq,h,travel,tuck) for i in range(4)]
    errors=[]
    for index,spec in enumerate(specs):
        q,achieved,error=solve_limb(p,q,index,spec['target'],spec['normal'],spec['footq'])
        toe=TOES[index]
        q[toe]=qmul(qinv(RESTQ[toe]),qmul(qinv(spec['footq']),spec['toe_world']))
        errors.append({'leg':index,'error':error,'target':spec['target'].tolist(),
                       'achieved':achieved.tolist(),'heel_roll':spec['heel'],
                       'mode':spec['mode'],'flight_weight':spec['weight']})
    return p,q,errors


def author(stem,phase):
    original=read(SRC/f'chr424857_{stem}.anim')
    out=deepcopy(original);n=int(phase[-1][0])+1
    for kind in ('positions','rotations','scales'):
        setattr(out,kind,{b:{} for b in range(52)})
    diagnostics=[];last=Q0.copy()
    for f in range(n):
        p,q,errors=pose(stem,phase,f)
        for b in range(50):
            if np.dot(last[b],q[b])<0:q[b]=-q[b]
            if NEUTRAL.positions[b]:out.positions[b][f]=p[b].tolist()
            # Bone 0/1 static identity rotations stay omitted.
            if NEUTRAL.rotations[b] or b in (2,7,*TOES):out.rotations[b][f]=q[b].tolist()
        last=q
        diagnostics.append({'frame':f,'feet':[e for e in errors if e['mode']=='stance'],
                            'all_leg_solutions':errors,
                            'stance_legs':[e['leg'] for e in errors if e['mode']=='stance'],
                            'flight_legs':[e['leg'] for e in errors if e['mode']!='stance'],
                            'jaw_angle':jaw_angle(stem,f)})
    rebuilt=write(out,DST/f'chr424857_{stem}.anim',preserve_duration=False,expected_bones=52)
    maxerr=max((e['error'] for r in diagnostics for e in r['all_leg_solutions']),default=0)
    return {'stem':stem,'frames':n,'duration':rebuilt._source_duration,
            'max_ik_target_error':maxerr,'frames_diagnostics':diagnostics,
            'phase_columns':['height','travel','body_pitch','body_yaw','body_roll',
                'chest_pitch','chest_yaw','head_pitch','head_yaw','head_roll','jaw','tuck'],
            'poses':phase}


def camera(stem,side,phase):
    path=f'cam_chr424857_{stem}_{side}.anim';original=read(SRC/path)
    out=deepcopy(original);n=int(phase[-1][0])+1
    original=read(SRC/f'cam_chr424857_bs01_{side}.anim')
    out.positions[0]={};out.rotations[0]={};out.float_channels[0]={}
    sign=1 if side=='pc' else -1
    previous=None
    for f in range(n):
        v=curve(phase,f);h,travel=v[:2]
        travel=travel*(4.14/(1.02 if stem=='bs01' else 1.50)) if travel>0 else travel
        if (stem=='bs01' and f>=33) or (stem=='bs02' and f>=47):travel=4.14
        # Low three-quarter view exposes the tooth sweep. A wider/high shot
        # follows the elevated body; no constant orbit hides the contact.
        if stem=='bs01':
            cam=np.array([sign*3.5,1.85,4.8])+FORWARD*travel*.85;target=np.array([0,1.0,.50])+FORWARD*travel
            fov=44.
        else:
            cam=np.array([sign*4.0,2.5+max(h,0)*.60,6.0])+FORWARD*travel*.85
            target=np.array([0,1.10+max(h,0)*.8,.2])+FORWARD*travel
            fov=48.
        quat=look_quat(cam,target)
        # Smooth source camera entry/exit without repeatedly easing every pose.
        if f<9:
            t=f/9;t=t*t*(3-2*t)
            op,oq,_=sample(original,0,0);cam=op*(1-t)+cam*t;quat=slerp(oq,quat,t)
            fov=float(sample_track(original.float_channels[0],0))*(1-t)+fov*t
        elif f>n-10:
            t=(f-(n-10))/9;t=t*t*(3-2*t)
            op,oq,_=sample(original,0,original._source_frame_count-1)
            cam=cam*(1-t)+op*t;quat=slerp(quat,oq,t)
            fov=fov*(1-t)+float(sample_track(original.float_channels[0],original._source_frame_count-1))*t
        if previous is not None and np.dot(previous,quat)<0:quat=-quat
        previous=quat
        out.positions[0][f]=cam.tolist();out.rotations[0][f]=quat.tolist();out.float_channels[0][f]=fov
    # Retained nonanimated channels stay intact; both cameras now match actor clip.
    write(out,DST/path,preserve_duration=False)


def main():
    if not DST.exists():raise SystemExit('Create modified_v3 from the reviewed V2 mod first')
    results=[]
    for stem,phase in [('bs01',GROUND),('bs02',HIGHLAND)]:
        result=author(stem,phase);results.append(result)
        for side in ('pc','em'):camera(stem,side,phase)
        print(stem,result['frames'],'frames, max IK error',round(result['max_ik_target_error'],6),flush=True)
    REPORT.parent.mkdir(exist_ok=True,parents=True)
    REPORT.write_text(json.dumps({'revision':3,'forward':FORWARD.tolist(),'flight_windows':FLIGHT_WINDOWS,'jaw_mechanical_angles':{'neutral':JAW_NEUTRAL_ANGLE,'open':JAW_OPEN_ANGLE,'closed':JAW_CLOSED_ANGLE},'clips':results},indent=2))

if __name__=='__main__':main()
