"""Render actual V3 attacker actions; camera tracks approach, holds for contact."""
import bpy,sys,json,math
from pathlib import Path
from mathutils import Vector
import numpy as np
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from anim_codec import read,sample
stem=sys.argv[sys.argv.index('--')+1]
assert stem in ('bs01','bs02')
bpy.ops.wm.open_mainfile(filepath=str(root/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend'))
scene=bpy.context.scene;arm=bpy.data.objects['chr424857']
arm.animation_data.action=bpy.data.actions['chr424857_'+stem]
for track in arm.animation_data.nla_tracks:track.mute=True
actor=read(root/f'modified_v3/dsts-loader/patch/chr424857_{stem}.anim')
n=actor._source_frame_count
p0=sample(actor,2,0)[0]
end=sample(actor,2,n-1)[0]-p0
frames=list(range(0,n,2))
if frames[-1]!=n-1:frames.append(n-1)
# Preview-only world grid: gives approach and planted paws a visible reference.
verts=[];faces=[];z=-.0375;w=.009
for x in range(-10,11):
 i=len(verts);verts.extend([(x-w,-14,z),(x+w,-14,z),(x+w,8,z),(x-w,8,z)]);faces.append(tuple(range(i,i+4)))
for y in range(-14,9):
 i=len(verts);verts.extend([(-10,y-w,z),(10,y-w,z),(10,y+w,z),(-10,y+w,z)]);faces.append(tuple(range(i,i+4)))
mesh=bpy.data.meshes.new('PreviewGrid');mesh.from_pydata(verts,[],faces);mesh.update()
obj=bpy.data.objects.new('PreviewGrid',mesh);scene.collection.objects.link(obj)
mat=bpy.data.materials.new('PreviewGrid');mat.diffuse_color=(.18,.21,.27,1);obj.data.materials.append(mat)
scene.render.resolution_x=640;scene.render.resolution_y=480
cam=scene.camera
cam.data.ortho_scale=5.6 if stem=='bs01' else 8.3
folder=root/'work/v3/sequence'/stem;folder.mkdir(exist_ok=True,parents=True)
only=set(map(int,sys.argv[sys.argv.index('--only')+1].split(','))) if '--only' in sys.argv else None
for i,f in enumerate(frames):
 if only is not None and f not in only:continue
 scene.frame_set(f+1)
 travel=sample(actor,2,f)[0]-p0
 hold_start,hold_end=(25,33) if stem=='bs01' else (41,47)
 if f>=hold_start:
  t=min(1.,(f-hold_start)/(hold_end-hold_start));t=t*t*(3-2*t)
  travel=travel*(1-t)+end*t
 cam.location=(3.2+travel[0],-6.5-travel[2],2.6)
 target=Vector((-.1+travel[0],-.9-travel[2],.95 if stem=='bs01' else 2.0))
 cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
 scene.render.filepath=str(folder/f'{i:03d}.png')
 bpy.ops.render.render(write_still=True)
(folder/'frames.json').write_text(json.dumps({'stem':stem,'frames':frames,'fps':actor.playback_rate}))
print('RENDERED',stem,len(frames),flush=True)
