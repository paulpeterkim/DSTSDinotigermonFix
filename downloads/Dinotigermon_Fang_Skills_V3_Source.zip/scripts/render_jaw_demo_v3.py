"""Head-fixed, jaw-only deformation proof using the patched in-game GEOM."""
from pathlib import Path
import importlib
import json
import math
import sys
from hashlib import sha256

import bpy
import numpy as np
from mathutils import Quaternion, Vector

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'work/v3';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'scripts'))
from anim_codec import _load_tools,_PACKAGE
from geom_preview import install_blender_preview_patch
_load_tools()
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
importer=install_blender_preview_patch()
Log=importlib.import_module(f'{_PACKAGE}.src.BlenderIO.Logging').ImportErrorLog
importer(str(ROOT/'modified_v3/dsts-loader/patch/chr424857.geom'),Log())
arm=bpy.data.objects['chr424857'];arm.animation_data.action=None
for track in arm.animation_data.nla_tracks:track.mute=True
for bone in arm.pose.bones:bone.matrix_basis.identity()
bpy.context.scene.frame_set(1)
meshes=[o for o in bpy.data.objects if o.type=='MESH' and o.parent==arm and o.name!='outline']
outline=bpy.data.objects.get('outline')
if outline:outline.hide_render=True
jaw=arm.pose.bones['J_ago'];jaw.rotation_mode='QUATERNION'
report=json.loads((OUT/'jaw_patch_report.json').read_text())
source_geom=importlib.import_module('geom_preview').read_geom(ROOT/'modified_v2/dsts-loader/patch/chr424857.geom')
source_points=[v.position[:3] for v in source_geom.meshes[0].unpack_vertices()]
fang_keys={tuple(np.round(source_points[i],5)) for i in report['protected_upper_fang_vertices']}
selected={};fang_selected={}
for obj in meshes:
    group=obj.vertex_groups['J_ago'].index
    selected[obj.name]=[v.index for v in obj.data.vertices
                        if any(w.group==group and w.weight>.05 for w in v.groups)]
    fang_selected[obj.name]=[v.index for v in obj.data.vertices
                             if tuple(np.round([v.co.x,v.co.z,-v.co.y],5)) in fang_keys]
scene=bpy.context.scene;scene.render.engine='BLENDER_WORKBENCH'
scene.display.shading.color_type='TEXTURE';scene.display.shading.light='STUDIO'
scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH'
scene.display.shading.background_type='WORLD';scene.world.color=(.035,.045,.065)
scene.render.resolution_x=960;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard'
data=bpy.data.cameras.new('JawOnlyProof');cam=bpy.data.objects.new('JawOnlyProof',data);scene.collection.objects.link(cam)
cam.location=(2.7,-3.5,1.16);focus=Vector((0,-1.1,1.0))
cam.rotation_euler=(focus-cam.location).to_track_quat('-Z','Y').to_euler()
data.type='ORTHO';data.ortho_scale=1.55;scene.camera=cam
depsgraph=bpy.context.evaluated_depsgraph_get()


def positions():
    depsgraph.update()
    return {o.name:np.array([list(o.evaluated_get(depsgraph).matrix_world@v.co)
                            for v in o.evaluated_get(depsgraph).data.vertices]) for o in meshes}


geometry_path=ROOT/'modified_v3/dsts-loader/patch/chr424857.geom'
geometry_hash=sha256(geometry_path.read_bytes()).hexdigest()
neutral=positions();data_report={'fixed_head':True,'neutral_other_bones':True,
                                'geometry_sha256':geometry_hash,
                                'patched_geometry_sha256':geometry_hash,'angles':[]}
for angle in [-6,0,12,25,30]:
    jaw.rotation_quaternion=Quaternion((1,0,0),math.radians(angle));bpy.context.view_layer.update()
    current=positions();lower=[];upper=[]
    for obj in meshes:
        d=np.linalg.norm(current[obj.name]-neutral[obj.name],axis=1)
        lower.extend(d[selected[obj.name]].tolist());upper.extend(d[fang_selected[obj.name]].tolist())
    data_report['angles'].append({'degrees':angle,'moving_lowerjaw_vertices':len(lower),
                                  'lowerjaw_max_displacement':max(lower),'lowerjaw_mean_displacement':float(np.mean(lower)),
                                  'upperfang_max_displacement':max(upper),'upperfang_vertices':len(upper)})
    scene.render.filepath=str(OUT/f'jaw_probe_{angle:+03d}.png');bpy.ops.render.render(write_still=True)
(OUT/'jaw_deformation_probe.json').write_text(json.dumps(data_report,indent=2))
print('JAW_PROBE',json.dumps(data_report))

# A second, head-fixed 15-frame loop demonstrates closure and opening without
# relying on a moving head or edited animation channel labels as evidence.
def landmark(source_index):
    key=tuple(np.round(source_points[source_index],5))
    for obj in meshes:
        for vertex in obj.data.vertices:
            if tuple(np.round([vertex.co.x,vertex.co.z,-vertex.co.y],5))==key:
                return obj.name,vertex.index
    raise ValueError(f'Missing jaw landmark {source_index}')

lip=landmark(22705);upper_tooth=landmark(2669)
demo={'geometry_sha256':geometry_hash,'patched_geometry_sha256':geometry_hash,
      'fixed_head':True,'neutral_other_bones':True,'fps':15,
      'angle_range_degrees':[-6,30], 'frames':[],
      'landmark_note':'Projected vertical opening is upper incisor tip Z minus lower front lip Z, clamped to zero; it is not a collision solver.'}
angles=[-6,-6,-2,5,13,22,28,30,30,28,22,13,5,-2,-6]
demo_paths=[]
for index,angle in enumerate(angles):
    jaw.rotation_quaternion=Quaternion((1,0,0),math.radians(angle));bpy.context.view_layer.update()
    current=positions();lower=[];upper=[]
    for obj in meshes:
        d=np.linalg.norm(current[obj.name]-neutral[obj.name],axis=1)
        lower.extend(d[selected[obj.name]].tolist());upper.extend(d[fang_selected[obj.name]].tolist())
    lp=current[lip[0]][lip[1]];ut=current[upper_tooth[0]][upper_tooth[1]]
    demo['frames'].append({'frame':index,'degrees':angle,
                           'lowerjaw_max_displacement':max(lower),
                           'upperfang_max_displacement':max(upper),
                           'lower_lip_position':lp.tolist(),'upper_incisor_position':ut.tolist(),
                           'projected_front_opening':max(0.,float(ut[2]-lp[2]))})
    path=OUT/f'jaw_demo_{index:02d}.png';demo_paths.append(path)
    scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
demo['mouth_opening_change']=max(f['projected_front_opening'] for f in demo['frames'])-min(f['projected_front_opening'] for f in demo['frames'])
(OUT/'jaw_demo_report.json').write_text(json.dumps(demo,indent=2))
print('JAW_DEMO_REPORT',json.dumps(demo))
