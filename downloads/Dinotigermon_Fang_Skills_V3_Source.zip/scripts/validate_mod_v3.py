#!/usr/bin/env python3
"""Offline validation of the third-pass fang choreography and jaw rig and game assets.

V3 retains the reviewed120/96-frame timing and skill data while revising
limb articulation and repairing lower-jaw skin weights only.
Structural/plant checks do not establish victim contact or runtime behavior.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import traceback
import zipfile

import numpy as np

import anim_codec
from motion_math import fk, qrotate, normalize
from patch_skills import GROUND_FANG_ID, HIGHLAND_FANG_ID, SKILL_TABLE, STATUS_TABLE, TEXT
from validate_mod import ANIMATIONS, check, sha256, inventory, parse_typed_csv

JAW_GEOM = Path("dsts-loader/patch/chr424857.geom")
FRAMES = {"bs01": 120, "bs02": 96}
FOOT_BONES = {0: 27, 1: 32, 2: 43, 3: 48}
# Quaternions are packed to roughly4e-5 component steps. Chain FK can differ
# by a few1e-4 units between independently quantized frames, even with exactly
# fixed authored targets. Bound physical jitter to0.001 model units; report the
# actual errors instead of describing the compressed foot positions as exact.
COMPRESSION_TOLERANCE = 0.001
NEUTRAL_TOLERANCE = 0.001
FINAL_APPROACH = 4.14


def pose_arrays(anim, frame):
    sampled = [anim_codec.sample(anim, bone, frame) for bone in range(anim.bone_count)]
    positions = np.asarray([value[0] for value in sampled], dtype=float)
    rotations = np.asarray([value[1] for value in sampled], dtype=float)
    scales = np.asarray([value[2] for value in sampled], dtype=float)
    return positions, rotations, scales


def equal_tracks(left, right):
    if set(left) != set(right):
        return False
    return all(np.array_equal(left[key], right[key]) for key in left)


def validate_static_assets(source, previous, modified, report, original_zip=None):
    before, first, after = inventory(source), inventory(previous), inventory(modified)
    checks = report["checks"]
    if original_zip is not None:
        with zipfile.ZipFile(original_zip) as archive:
            check(archive.testzip() is None, "Uploaded archive CRC mismatch")
            names = {entry.filename for entry in archive.infolist() if not entry.is_dir()}
            check(names == {path.as_posix() for path in before},
                  "Original directory does not contain exactly the uploaded files")
            for relative, path in before.items():
                expected = hashlib.sha256(archive.read(relative.as_posix())).hexdigest()
                check(sha256(path) == expected, f"Original differs from upload: {relative}")
        checks.append({"name": "uploaded_archive_integrity", "passed": True,
                       "files": len(before)})
    locales = sorted(path.relative_to(source)
                     for path in (source / "dsts-loader").glob("patch_text*") if path.is_dir())
    check(len(locales) == 11, "Expected exactly the 11 original locale folders")
    text_paths = {locale / "text" / table / "000_Sheet1.ap.csv"
                  for locale in locales
                  for table in ("skill_name.mbe", "skill_explanation.mbe")}
    allowed = {SKILL_TABLE, STATUS_TABLE, JAW_GEOM, *ANIMATIONS, *text_paths}
    check(not (set(before) - set(after)), "Original files were removed")
    check(set(first) == set(after), "V3 added or removed files relative to V2")
    changes = []
    preserved = 0
    for relative in sorted(set(before) | set(after)):
        old_hash = sha256(before[relative]) if relative in before else None
        new_hash = sha256(after[relative]) if relative in after else None
        if old_hash != new_hash:
            check(relative in allowed, f"Unexpected modification: {relative}")
            changes.append({"path": relative.as_posix(),
                            "status": "added" if old_hash is None else "modified",
                            "original_sha256": old_hash, "modified_sha256": new_hash})
        else:
            preserved += 1
        # This is a motion revision, not an unrelated data/balance revision.
        if relative not in ANIMATIONS and relative != JAW_GEOM:
            check(sha256(first[relative]) == new_hash,
                  f"Non-animation asset differs from reviewed V2: {relative}")
    report["file_changes"] = changes
    report["preserved_original_files"] = preserved
    report["modified_file_count"] = len(after)
    checks.append({"name": "only_allowed_assets_changed_and_v2_data_retained",
                   "passed": True, "changed": len(changes), "preserved": preserved})
    protected = [path for path in before
                 if (path.suffix in (".geom", ".nlst", ".img") or "images" in path.parts) and path != JAW_GEOM]
    for relative in protected:
        check(sha256(before[relative]) == sha256(after[relative]),
              f"Model, skeleton list, or texture changed: {relative}")
    checks.append({"name": "unrelated_geometry_skeleton_lists_textures_preserved", "passed": True,
                   "files": len(protected)})

    tables = {path.relative_to(modified): parse_typed_csv(path)
              for path in sorted(modified.rglob("*.ap.csv"))}
    checks.append({"name": "all_append_csv_types_widths_and_keys", "passed": True,
                   "tables": len(tables), "rows": sum(len(rows) for _, rows in tables.values())})
    skills = {row[0]: row for row in tables[SKILL_TABLE][1]}
    check(set(skills) == {GROUND_FANG_ID, HIGHLAND_FANG_ID},
          "Expected exactly two independent custom skills")
    original_rows = parse_typed_csv(source / SKILL_TABLE)[1]
    template = next(row for row in original_rows if row[0] == HIGHLAND_FANG_ID)
    for skill_id, animation, target in ((GROUND_FANG_ID, "3", "1"),
                                         (HIGHLAND_FANG_ID, "4", "5")):
        row = skills[skill_id]
        check(all(row[index] == skill_id for index in (0, 4, 5, 6)),
              f"Skill ID/name/description/internal key mismatch: {skill_id}")
        check(row[10] == animation and row[33] == target,
              f"Wrong animation or target for skill {skill_id}")
        check(row[29] == "-1" and row[54] == "0",
              f"Unrelated inherited trait bonus or buff remains: {skill_id}")
        check(all(row[index] == template[index] for index in (11, 22, 23, 34, 35, 36)),
              f"Inherited damage/hit timing/hit count/SP baseline changed: {skill_id}")
        check(row[12] == "0", f"An old main particle effect remains: {skill_id}")
    status_header, status_rows = tables[STATUS_TABLE]
    original_header, original_status_rows = parse_typed_csv(source / STATUS_TABLE)
    status = next(row for row in status_rows if row[0] == "55057")
    original_status = next(row for row in original_status_rows if row[0] == "55057")
    check(status_header == original_header, "Digimon status header changed")
    check(status[72] == status[126] == GROUND_FANG_ID and status[75] == HIGHLAND_FANG_ID,
          "Dinotigermon skill slots/default skill disagree")
    check(all(left == right for index, (left, right) in enumerate(zip(original_status, status))
              if index not in (72, 75, 126)), "Unrelated Digimon status values changed")
    checks.append({"name": "custom_skill_assignments_and_inherited_balance", "passed": True})
    for locale in locales:
        for table, value_index in (("skill_name.mbe", 1), ("skill_explanation.mbe", 2)):
            rows = tables[locale / "text" / table / "000_Sheet1.ap.csv"][1]
            check(len(rows) == 2 and dict(rows) == {entry[0]: entry[value_index] for entry in TEXT},
                  f"Skill name/description mismatch: {locale}/{table}")
    checks.append({"name": "exact_skill_names_and_descriptions", "passed": True,
                   "locales": len(locales), "language": "English fallback"})


def validate_animations(source, v2, modified, report):
    animations = {}
    results = []
    for relative, expected_bones in ANIMATIONS.items():
        original = anim_codec.read(source / relative, expected_bones=expected_bones)
        previous = anim_codec.read(v2 / relative, expected_bones=expected_bones)
        edited = anim_codec.read(modified / relative, expected_bones=expected_bones)
        stem = "bs01" if "_bs01" in relative.name else "bs02"
        frames = FRAMES[stem]
        check(edited.bone_count == original.bone_count,
              f"Animation bone count changed: {relative}")
        check(edited._source_frame_count == previous._source_frame_count == frames, f"Wrong V3 frame count: {relative}")
        check(edited.playback_rate == original.playback_rate,
              f"Playback rate changed: {relative}")
        expected_duration = (frames - 1) / original.playback_rate
        check(math.isclose(edited._source_duration, expected_duration, rel_tol=0, abs_tol=1e-5),
              f"Header duration disagrees with deliberate V3 frame count/rate: {relative}")
        for field in ("float_channel_count", "bone_blend_factors",
                      "float_channel_blend_factors", "unknown_section"):
            check(np.array_equal(getattr(original, field), getattr(edited, field)),
                  f"Nonanimated metadata changed ({field}): {relative}")
        anim_codec.validate(edited, expected_bones=original.bone_count, expected_frames=frames)
        if expected_bones == 52:
            for bone in range(edited.bone_count):
                check(equal_tracks(original.scales[bone], edited.scales[bone]),
                      f"Actor scale track changed despite unit-scale FK assumptions: {relative}, bone {bone}")
            # Compare poses at equal normalized phases as well as byte hashes;
            # a mere duration/header rewrite is not a choreography revision.
            greatest_position_change = greatest_rotation_change = 0.
            for phase in np.linspace(0, 1, 21):
                old_p, old_q, _ = pose_arrays(previous, phase * (previous._source_frame_count - 1))
                new_p, new_q, _ = pose_arrays(edited, phase * (frames - 1))
                greatest_position_change = max(greatest_position_change,
                                               float(np.max(np.linalg.norm(old_p - new_p, axis=1))))
                dots = np.clip(np.abs(np.sum(old_q * new_q, axis=1)), 0, 1)
                greatest_rotation_change = max(greatest_rotation_change,
                                               float(np.max(2 * np.arccos(dots))))
            # Limb changes are assessed separately from root/body changes;
            # V3 deliberately retains the reviewed approach and torso timing.
            animations[stem] = edited
        else:
            # Only the documented camera root position/rotation/FOV channels
            # may change. Retain other camera bones and scale channels exactly.
            for bone in range(original.bone_count):
                check(equal_tracks(original.scales[bone], edited.scales[bone]),
                      f"Camera scale track changed: {relative}, bone {bone}")
                if bone != 0:
                    for kind in ("positions", "rotations"):
                        check(equal_tracks(getattr(original, kind)[bone], getattr(edited, kind)[bone]),
                              f"Unexpected secondary camera track changed: {relative}")
            check(set(original.float_channels) == set(edited.float_channels),
                  f"Camera float-channel identity changed: {relative}")
            for index in original.float_channels:
                if index != 0:
                    check(equal_tracks(original.float_channels[index], edited.float_channels[index]),
                          f"Unexpected camera float channel changed: {relative}, {index}")
        results.append({"path": relative.as_posix(), "bones": edited.bone_count,
                        "frames": frames, "playback_rate": edited.playback_rate,
                        "header_span_seconds": float(edited._source_duration),
                        "frame_sequence_seconds": frames / edited.playback_rate,
                        "original_frames": original._source_frame_count,
                        "v2_frames": previous._source_frame_count,
                        "metadata_preserved": True})
    check(set(animations) == set(FRAMES), "Missing V3 actor clip")
    report["checks"].append({"name": "v3_animation_transforms_metadata_and_deliberate_timing",
                             "passed": True, "animations": results,
                             "note": "V3 retains the reviewed V2 clip durations and original playback rates."})
    return animations


def validate_neutral_and_plants(source, animations, diagnostics_path, report):
    skeleton = anim_codec.read_embedded_skeleton(source / "dsts-loader/patch/chr424857.geom")
    neutral = anim_codec.read(source / "dsts-loader/patch/chr424857_bn01.anim", expected_bones=52)
    neutral_p, neutral_q, neutral_s = pose_arrays(neutral, 0)
    _, neutral_world_q = fk(skeleton, neutral_p, neutral_q)
    approach_direction = qrotate(neutral_world_q[6], [0, 0, 1])
    approach_direction[1] = 0
    approach_direction = normalize(approach_direction)
    endpoints = []
    world = {}
    for stem, edited in animations.items():
        for frame in (0, FRAMES[stem] - 1):
            p, q, s = pose_arrays(edited, frame)
            expected_p = neutral_p.copy()
            if frame == FRAMES[stem] - 1:
                expected_p[2] += approach_direction * FINAL_APPROACH
            position_error = float(np.max(np.abs(p - expected_p)))
            rotation_error = float(np.max(np.minimum(np.linalg.norm(q - neutral_q, axis=1),
                                                     np.linalg.norm(q + neutral_q, axis=1))))
            scale_error = float(np.max(np.abs(s - neutral_s)))
            check(max(position_error, rotation_error, scale_error) <= NEUTRAL_TOLERANCE,
                  f"V3 endpoint does not match neutral articulation/approach position: {stem}, frame {frame}")
            endpoints.append({"stem": stem, "frame": frame, "position_error": position_error,
                              "quaternion_error": rotation_error, "scale_error": scale_error})
        world[stem] = []
        for frame in range(FRAMES[stem]):
            p, q, _ = pose_arrays(edited, frame)
            wp, _ = fk(skeleton, p, q)
            check(np.isfinite(wp).all(), f"Nonfinite forward kinematics: {stem}, {frame}")
            world[stem].append(wp)
    report["checks"].append({"name": "neutral_articulation_with_original_style_close_range_endpoint", "passed": True,
                             "tolerance": NEUTRAL_TOLERANCE,
                             "final_approach_distance": FINAL_APPROACH,
                             "approach_direction": approach_direction.tolist(), "endpoints": endpoints})
    diagnostics = json.loads(diagnostics_path.read_text())
    check(diagnostics.get("revision") == 3, "IK diagnostics do not describe V3")
    clips = diagnostics.get("clips", [])
    check({clip["stem"] for clip in clips} == set(FRAMES) and len(clips) == 2,
          "IK diagnostics do not contain both V3 clips exactly once")
    ground_diagnostics = next(clip for clip in clips if clip["stem"] == "bs01")
    ground_rows = {row["frame"]: row for row in ground_diagnostics["frames_diagnostics"]}
    plants = []
    for leg, bone in ((0, FOOT_BONES[0]), (1, FOOT_BONES[1])):
        points = np.asarray([world["bs01"][frame][bone] for frame in range(33, 71)])
        targets = np.asarray([next(foot["target"] for foot in ground_rows[frame]["feet"]
                                   if foot["leg"] == leg) for frame in range(33, 71)])
        check(np.isfinite(targets).all(), f"Nonfinite pin target: leg {leg}")
        raw_target_drift = float(np.max(np.linalg.norm(targets - targets[0], axis=1)))
        check(raw_target_drift <= 1e-12, f"Authored pin target actually moves: leg {leg}")
        displacement = np.linalg.norm(points - points[0], axis=1)
        maximum = float(np.max(displacement))
        maximum_pairwise = float(np.max(np.linalg.norm(points[:, None] - points[None, :], axis=2)))
        target_error = float(np.max(np.linalg.norm(points - targets, axis=1)))
        check(maximum_pairwise <= COMPRESSION_TOLERANCE and target_error <= COMPRESSION_TOLERANCE,
              f"Compressed planted foot exceeds bounded quaternion jitter: leg {leg}")
        check(maximum <= COMPRESSION_TOLERANCE,
              f"Ground Fang front ankle slides during the pin: leg {leg}, {maximum}")
        plants.append({"leg": leg, "bone": bone, "frames_inclusive": [33, 70],
                       "anchor": targets[0].tolist(), "raw_authored_target_drift": raw_target_drift,
                       "max_world_displacement_from_first_frame": maximum,
                       "max_pairwise_world_displacement": maximum_pairwise,
                       "max_compressed_error_from_exact_target": target_error})
    report["checks"].append({"name": "ground_front_ankles_stationary_during_pin", "passed": True,
                             "compression_tolerance": COMPRESSION_TOLERANCE, "plants": plants})

    results = []
    for clip in clips:
        stem = clip["stem"]
        check(clip["frames"] == FRAMES[stem], f"IK diagnostic frame count differs: {stem}")
        rows = clip["frames_diagnostics"]
        check([row["frame"] for row in rows] == list(range(FRAMES[stem])),
              f"Missing, duplicate, or unordered IK diagnostics: {stem}")
        max_authored = max_roundtrip = max_link_error = 0.
        max_all_authored = max_all_roundtrip = max_all_link_error = 0.
        all_targets = 0
        targets = 0
        for row in rows:
            frame = row["frame"]
            seen = set()
            for foot in row["feet"]:
                leg = foot["leg"]
                check(leg in FOOT_BONES and leg not in seen,
                      f"Duplicate/invalid leg diagnostic: {stem}, {frame}")
                seen.add(leg)
                target = np.asarray(foot["target"], dtype=float)
                achieved = np.asarray(foot["achieved"], dtype=float)
                error = float(foot["error"])
                check(target.shape == achieved.shape == (3,) and
                      np.isfinite(target).all() and np.isfinite(achieved).all() and
                      math.isfinite(error) and error >= 0,
                      f"Invalid IK diagnostic values: {stem}, {frame}, {leg}")
                check(math.isclose(float(np.linalg.norm(achieved - target)), error,
                                   rel_tol=0, abs_tol=1e-8),
                      f"Authored IK target error disagrees with coordinates: {stem}, {frame}, {leg}")
                rebuilt = world[stem][frame][FOOT_BONES[leg]]
                max_authored = max(max_authored, error)
                max_roundtrip = max(max_roundtrip, float(np.linalg.norm(rebuilt - target)))
                max_link_error = max(max_link_error, float(np.linalg.norm(rebuilt - achieved)))
                targets += 1
            # Per-frame sets are recorded by the author. Enforce exhaustive,
            # disjoint stance/flight coverage, with mandatory forepaw support
            # during the pin, without freezing old takeoff/landing hardcodes.
            stance = row.get("stance_legs")
            flight = row.get("flight_legs")
            check(isinstance(stance, list) and isinstance(flight, list),
                  f"Missing active-leg classification: {stem}, {frame}")
            check(len(set(stance)) == len(stance) and len(set(flight)) == len(flight),
                  f"Duplicate leg classification: {stem}, {frame}")
            check(set(stance).isdisjoint(flight) and set(stance) | set(flight) == set(FOOT_BONES),
                  f"Incomplete or overlapping leg classification: {stem}, {frame}")
            check(seen == set(stance), f"Reported stance targets disagree with active legs: {stem}, {frame}")
            if stem == "bs01" and 33 <= frame <= 70:
                check({0, 1} <= seen, f"Forepaws are not planted during pin: frame {frame}")
            solutions = row.get("all_leg_solutions", [])
            check(len(solutions) == 4 and {item["leg"] for item in solutions} == set(FOOT_BONES),
                  f"IK report does not cover all four stance/flight limbs: {stem}, {frame}")
            for item in solutions:
                leg = item["leg"]
                target = np.asarray(item["target"], dtype=float)
                achieved = np.asarray(item["achieved"], dtype=float)
                error = float(item["error"])
                weight = float(item["flight_weight"])
                check(target.shape == achieved.shape == (3,) and np.isfinite(target).all() and
                      np.isfinite(achieved).all() and math.isfinite(error) and error >= 0 and
                      math.isfinite(weight) and 0 <= weight <= 1,
                      f"Invalid full-limb IK result: {stem}, {frame}, {leg}")
                check(item["mode"] in ("stance", "flight", "release", "landing_reach") and
                      ((item["mode"] == "stance") == (leg in seen)),
                      f"IK mode disagrees with planted/flight classification: {stem}, {frame}, {leg}")
                check(math.isclose(float(np.linalg.norm(achieved - target)), error, rel_tol=0, abs_tol=1e-8),
                      f"Full-limb IK error disagrees with reported coordinates: {stem}, {frame}, {leg}")
                actual = world[stem][frame][FOOT_BONES[leg]]
                max_all_authored = max(max_all_authored, error)
                max_all_roundtrip = max(max_all_roundtrip, float(np.linalg.norm(actual - target)))
                max_all_link_error = max(max_all_link_error, float(np.linalg.norm(actual - achieved)))
                all_targets += 1
        check(targets > 0, f"No actual IK targets checked: {stem}")
        declared = float(clip["max_ik_target_error"])
        check(math.isfinite(declared) and math.isclose(declared, max_authored, rel_tol=0, abs_tol=1e-8),
              f"IK maximum is nonfinite or stale: {stem}")
        check(max_authored <= 1e-6, f"Authored leg target is unreachable: {stem}, {max_authored}")
        check(all_targets == FRAMES[stem] * 4 and max_all_authored <= 1e-6 and
              max_all_roundtrip <= COMPRESSION_TOLERANCE and max_all_link_error <= COMPRESSION_TOLERANCE,
              f"Full stance/flight IK targets exceed reach/compression limits: {stem}")
        check(max_roundtrip <= COMPRESSION_TOLERANCE and max_link_error <= COMPRESSION_TOLERANCE,
              f"Compressed clip no longer reaches its diagnostic targets: {stem}")
        results.append({"stem": stem, "targets_checked": targets,
                        "max_authored_target_error": max_authored,
                        "max_roundtrip_target_error": max_roundtrip,
                        "max_report_to_clip_error": max_link_error,
                        "all_stance_flight_targets_checked": all_targets,
                        "max_all_authored_target_error": max_all_authored,
                        "max_all_roundtrip_target_error": max_all_roundtrip,
                        "max_all_report_to_clip_error": max_all_link_error})
    report["checks"].append({"name": "all_authored_leg_targets_finite_reachable_and_linked_to_clip",
                             "passed": True, "diagnostics": str(diagnostics_path),
                             "compression_tolerance": COMPRESSION_TOLERANCE, "clips": results})



def validate_limb_and_jaw_curves(source, v2, animations, report, max_adjacent_degrees=None):
    """Check that V3 changes articulation, not only names/root motion."""
    from motion_math import quat_rotate
    skeleton = anim_codec.read_embedded_skeleton(source / JAW_GEOM)
    limb_bones = (24, 25, 26, 27, 29, 30, 31, 32, 40, 41, 42, 43, 45, 46, 47, 48)
    results = []
    for stem, edited in animations.items():
        old = anim_codec.read(v2 / f"dsts-loader/patch/chr424857_{stem}.anim")
        differences = np.zeros(52)
        paw_changes = np.zeros(4)
        jaw_angles = []
        previous_exported_q = None
        adjacent_steps = []
        for frame in range(FRAMES[stem]):
            old_p, old_q, _ = pose_arrays(old, frame)
            new_p, new_q, _ = pose_arrays(edited, frame)
            dots = np.clip(np.abs(np.sum(old_q * new_q, axis=1)), 0, 1)
            differences = np.maximum(differences, 2 * np.arccos(dots))
            if previous_exported_q is not None:
                frame_dots = np.clip(np.abs(np.sum(previous_exported_q * new_q, axis=1)), 0, 1)
                frame_angles = np.degrees(2 * np.arccos(frame_dots))
                adjacent_steps.extend((float(frame_angles[bone]), frame, bone) for bone in limb_bones)
            previous_exported_q = new_q
            old_world, _ = fk(skeleton, old_p, old_q)
            new_world, _ = fk(skeleton, new_p, new_q)
            for leg, bone in FOOT_BONES.items():
                paw_changes[leg] = max(paw_changes[leg], float(np.linalg.norm(new_world[bone] - old_world[bone])))
            # Game jaw hinge is localX; the projection records the actual
            # exported quaternion's opening, not the authoring control curve.
            forward = quat_rotate(new_q[7], [0, 0, 1])
            jaw_angles.append(math.atan2(-forward[1], forward[2]))
        changed = [bone for bone in limb_bones if differences[bone] >= math.radians(5)]
        check(len(changed) >= 4,
              f"V3 has insufficient independent limb articulation changes: {stem}")
        check(float(np.max(paw_changes)) >= 0.05,
              f"V3 paw paths remain effectively identical to V2: {stem}")
        jaw_angles = np.unwrap(jaw_angles)
        jaw_range = float(np.ptp(jaw_angles))
        check(jaw_range >= math.radians(20), f"Jaw opening/closing range is too small: {stem}")
        maximum = int(np.argmax(jaw_angles))
        check(0 < maximum < FRAMES[stem] - 1,
              f"Jaw never opens and returns during the attack: {stem}")
        check(jaw_angles[maximum] - jaw_angles[-1] >= math.radians(15),
              f"Jaw fails to close after opening: {stem}")
        results.append({"stem": stem, "changed_limb_bones_over_five_degrees": changed,
                        "max_limb_rotation_change_degrees": float(np.degrees(max(differences[list(limb_bones)]))),
                        "max_paw_path_change_from_v2": paw_changes.tolist(),
                        "jaw_min_degrees": float(np.degrees(np.min(jaw_angles))),
                        "jaw_max_degrees": float(np.degrees(np.max(jaw_angles))),
                        "jaw_range_degrees": float(np.degrees(jaw_range)),
                        "jaw_maximum_frame": maximum,
                        "largest_adjacent_limb_joint_steps": [
                            {"degrees": angle, "frame": frame, "bone": bone}
                            for angle, frame, bone in sorted(adjacent_steps, reverse=True)[:5]]})
        report["limb_transition_diagnostics"] = results.copy()
        if max_adjacent_degrees is not None:
            check(math.isfinite(max_adjacent_degrees) and max_adjacent_degrees > 0,
                  "Adjacent limb-angle limit must be finite and positive")
            check(max(angle for angle, _, _ in adjacent_steps) <= max_adjacent_degrees,
                  f"One-frame limb rotation exceeds agreed {max_adjacent_degrees}-degree limit: {stem}")
    report["checks"].append({"name": "revised_limb_articulation_and_exported_jaw_open_close_curves",
                             "passed": True, "clips": results,
                             "max_adjacent_limb_angle_limit_degrees": max_adjacent_degrees,
                             "note": "Jaw quaternion motion alone does not prove weighted mouth movement; mesh/skin tests follow. Adjacent limb steps are recorded for visual review, not accepted as automatically natural motion."})



def mesh_skin_data(geom, mesh_index):
    mesh = geom.meshes[mesh_index]
    vertices = mesh.unpack_vertices()
    points = np.asarray([vertex.position[:3] for vertex in vertices], dtype=float)
    local_indices = np.asarray([vertex.indices for vertex in vertices], dtype=int)
    weights = np.asarray([vertex.weights for vertex in vertices], dtype=float)
    palette = np.asarray(mesh.matrix_palette, dtype=int)
    check(local_indices.shape == weights.shape and np.all((local_indices >= 0) & (local_indices < len(palette))),
          f"Invalid vertex palette indices: mesh {mesh_index}")
    check(np.isfinite(points).all() and np.isfinite(weights).all() and
          np.all((weights >= 0) & (weights <= 1)), f"Invalid mesh weights: mesh {mesh_index}")
    check(float(np.max(np.abs(weights.sum(axis=1) - 1))) <= 0.001,
          f"Weights are not normalized within source half-float precision: mesh {mesh_index}")
    return points, palette[local_indices], weights


def skin_subset(geom, skeleton, positions, rotations, mesh_data, indices):
    from motion_math import quat_to_matrix
    points, bones, weights = mesh_data
    indices = np.asarray(indices, dtype=int)
    wp, wq = fk(skeleton, positions, rotations)
    matrices = []
    for bone in range(skeleton.bone_count):
        pose = np.eye(4);pose[:3, :3] = quat_to_matrix(wq[bone]);pose[:3, 3] = wp[bone]
        inverse_bind = np.eye(4);inverse_bind[:3] = np.asarray(geom.ibpms[bone]).reshape(3, 4)
        matrices.append(pose @ inverse_bind)
    matrices = np.asarray(matrices)
    sampled = matrices[bones[indices]]
    homogeneous = np.c_[points[indices], np.ones(len(indices))]
    transformed = np.einsum("nskj,nj->nsk", sampled, homogeneous)[..., :3]
    normalized = weights[indices] / weights[indices].sum(axis=1)[:, None]
    return np.sum(transformed * normalized[..., None], axis=1)


def validate_jaw_geometry(source, previous, modified, animations, report, patch_report_path, probe_path, demo_path):
    """Validate only index/weight-byte edits, and actual jaw-only skin motion."""
    from geom_preview import read_geom
    from inspect_jaw_v3 import components
    before_path, after_path = previous / JAW_GEOM, modified / JAW_GEOM
    before_bytes, after_bytes = before_path.read_bytes(), after_path.read_bytes()
    check(before_bytes != after_bytes and len(before_bytes) == len(after_bytes),
          "Jaw repair is absent or changed GEOM size/layout")
    check(patch_report_path.is_file(), "Missing jaw-patch byte/selection report")
    patch_report = json.loads(patch_report_path.read_text())
    original = read_geom(before_path); edited = read_geom(after_path)
    check(len(original.meshes) == len(edited.meshes) == 3, "Jaw patch changed mesh layout")
    allowed = np.zeros(len(before_bytes), dtype=bool)
    independent_ranges = []
    jaw_selections = {};fang_selections = {};mesh_arrays = {};weight_checks = []
    decoded_before = [mesh.unpack_vertices() for mesh in original.meshes]
    decoded_after = [mesh.unpack_vertices() for mesh in edited.meshes]
    import struct
    for mesh_index, (old_mesh, new_mesh) in enumerate(zip(original.meshes, edited.meshes)):
        old_data = mesh_skin_data(original, mesh_index)
        new_data = mesh_skin_data(edited, mesh_index)
        mesh_arrays[mesh_index] = new_data
        points, bones, weights = new_data
        old_points, old_bones, old_weights = old_data
        check(np.array_equal(points, old_points) and np.array_equal(old_mesh.matrix_palette, new_mesh.matrix_palette),
              f"Jaw patch altered vertex positions or palette: mesh {mesh_index}")
        jaw_weight = np.sum(weights * (bones == 7), axis=1)
        old_jaw_weight = np.sum(old_weights * (old_bones == 7), axis=1)
        check(not np.any(old_jaw_weight > 0), f"Baseline unexpectedly already weights the jaw: mesh {mesh_index}")
        selected = np.flatnonzero(jaw_weight > old_jaw_weight + 0.001)
        jaw_selections[mesh_index] = selected
        check(len(selected) > 0, f"No meaningful new jaw influences: mesh {mesh_index}")
        check(np.count_nonzero(jaw_weight >= 0.6) >= 24,
              f"Jaw influences remain too weak to articulate mesh {mesh_index}")
        changed_rows = np.flatnonzero(np.any(bones != old_bones, axis=1) |
                                      np.any(weights != old_weights, axis=1))
        check(set(changed_rows) <= set(selected),
              f"Skin changes outside new jaw-influenced vertices: mesh {mesh_index}")
        for vertex in selected:
            old_map = {int(bone): float(weight) for bone, weight in zip(old_bones[vertex], old_weights[vertex]) if weight > 0}
            new_map = {int(bone): float(weight) for bone, weight in zip(bones[vertex], weights[vertex]) if weight > 0}
            check(old_map.get(6, 0) > 0, f"New jaw vertex was not previously head-bound: mesh {mesh_index}, vertex {vertex}")
            for bone in set(old_map) | set(new_map):
                if bone not in (6, 7):
                    check(abs(old_map.get(bone, 0) - new_map.get(bone, 0)) <= 0.001,
                          f"Unrelated bone influence changed: mesh {mesh_index}, vertex {vertex}, bone {bone}")
            check(abs(old_map.get(6, 0) - new_map.get(6, 0) - new_map.get(7, 0)) <= 0.001,
                  f"Head influence was not transferred solely to jaw: mesh {mesh_index}, vertex {vertex}")
        region = points[selected]
        check(np.all(np.abs(region[:, 0]) <= 0.36) and
              np.all((region[:, 1] >= 0.74) & (region[:, 1] <= 1.22)) and
              np.all((region[:, 2] >= 0.70) & (region[:, 2] <= 1.42)),
              f"Jaw selection escapes the inspected mouth region: mesh {mesh_index}")
        # Permit only the exact skin-index and skin-weight attribute spans for
        # the selected vertices. Positions, UVs, normals, triangle data, shader
        # materials, strings, headers, skeleton and every other byte stay fixed.
        for attribute in old_mesh.attributes:
            if attribute.atype not in (10, 11):
                continue
            width = struct.calcsize('<' + old_mesh.DATA_TYPES[attribute.dtype] * attribute.count)
            for vertex in selected:
                start = old_mesh.vertices_offset + int(vertex) * old_mesh.bytes_per_vertex + attribute.offset
                allowed[start:start + width] = True
                independent_ranges.append([start, start + width])
        _, _, groups = components(old_mesh)
        upper_fangs = sorted({vertex for group in groups
                              if min(group) in (2264, 5560, 2308, 5605) for vertex in group})
        # Visible and outline meshes contain the two long upper fang surfaces;
        # the translucent/material-detail mesh has a different topology subset.
        if mesh_index in (0, 2):
            check(len(upper_fangs) >= 80, f"Missing protected upper-fang components: mesh {mesh_index}")
        if upper_fangs:
            check(not set(upper_fangs) & set(selected), f"Upper fangs were assigned to the lower jaw: mesh {mesh_index}")
            check(np.array_equal(jaw_weight[upper_fangs], old_jaw_weight[upper_fangs]),
                  f"Upper-fang jaw influence changed: mesh {mesh_index}")
        fang_selections[mesh_index] = upper_fangs
        weight_checks.append({"mesh": mesh_index, "new_jaw_vertices": len(selected),
                              "strong_jaw_vertices": int(np.count_nonzero(jaw_weight >= 0.6)),
                              "max_weight_sum_error": float(np.max(np.abs(weights.sum(axis=1) - 1))),
                              "protected_upper_fang_vertices": len(upper_fangs)})
    check(patch_report.get("source_sha256") == sha256(before_path) and
          patch_report.get("patched_sha256") == sha256(after_path),
          "Jaw patch report does not describe the current source/patched geometry")
    check(patch_report.get("file_size") == len(after_bytes), "Jaw report file size is stale")
    check(sorted(patch_report.get("allowed_ranges", [])) == sorted(independent_ranges),
          "Reported allowed byte ranges differ from independently decoded skin fields")
    records = patch_report.get("patches", [])
    record_keys = [(entry["mesh"], entry["vertex"]) for entry in records]
    expected_keys = [(mesh, int(vertex)) for mesh, vertices in jaw_selections.items() for vertex in vertices]
    check(len(set(record_keys)) == len(record_keys) and set(record_keys) == set(expected_keys),
          "Jaw report vertex selection does not match actual new jaw influences")
    for entry in records:
        mesh_index, vertex = entry["mesh"], entry["vertex"]
        old_vertex = decoded_before[mesh_index][vertex]
        new_vertex = decoded_after[mesh_index][vertex]
        check(np.array_equal(entry["position"], old_vertex.position[:3]) and
              np.array_equal(entry["old_indices"], old_vertex.indices) and
              np.array_equal(entry["old_weights"], old_vertex.weights) and
              np.array_equal(entry["new_indices"], new_vertex.indices) and
              np.array_equal(entry["new_weights"], new_vertex.weights),
              f"Jaw patch report old/new payload differs: mesh {mesh_index}, vertex {vertex}")
    material_start = original.materials_offset
    check(material_start == patch_report.get("protected_material_start") and
          before_bytes[material_start:] == after_bytes[material_start:],
          "Material/IBPM/skeleton tail changed")
    differences = np.flatnonzero(np.frombuffer(before_bytes, dtype=np.uint8) !=
                                 np.frombuffer(after_bytes, dtype=np.uint8))
    check(np.all(allowed[differences]), "GEOM changed outside exact permitted vertex skin bytes")
    check(len(differences) == patch_report.get("changed_byte_count"), "Reported changed-byte count is stale")
    unchanged_before = np.frombuffer(before_bytes, dtype=np.uint8)[~allowed]
    unchanged_after = np.frombuffer(after_bytes, dtype=np.uint8)[~allowed]
    check(np.array_equal(unchanged_before, unchanged_after), "Unrelated GEOM data changed")
    ranges = []
    for offset in differences:
        offset = int(offset)
        if not ranges or ranges[-1][1] != offset:
            ranges.append([offset, offset + 1])
        else:
            ranges[-1][1] = offset + 1
    report["checks"].append({"name": "jaw_weights_normalized_and_only_exact_skin_bytes_changed",
                             "passed": True, "geom_before_sha256": sha256(before_path),
                             "geom_after_sha256": sha256(after_path), "changed_bytes": len(differences),
                             "changed_byte_ranges_half_open": ranges,
                             "untouched_bytes": len(before_bytes) - len(differences),
                             "meshes": weight_checks, "patch_report": str(patch_report_path)})
    # The old supplied mesh had no positive jaw influences. Hold the head/body
    # and all other joints still and feed only the EXPORTED jaw quaternion to
    # the repaired skin. This distinguishes mouth articulation from head nods.
    skeleton = anim_codec.read_embedded_skeleton(after_path)
    neutral = anim_codec.read(source / "dsts-loader/patch/chr424857_bn01.anim")
    p, q, _ = pose_arrays(neutral, 0)
    motion = []
    for stem, anim in animations.items():
        jaw_quats = np.asarray([pose_arrays(anim, f)[1][7] for f in range(FRAMES[stem])])
        dots = np.clip(np.abs(jaw_quats @ jaw_quats[0]), 0, 1)
        opened_frame = int(np.argmax(2 * np.arccos(dots)))
        closed = q.copy();opened = q.copy()
        closed[7] = jaw_quats[-1];opened[7] = jaw_quats[opened_frame]
        per_mesh = []
        for mesh_index, selected in jaw_selections.items():
            old_pose = skin_subset(edited, skeleton, p, closed, mesh_arrays[mesh_index], selected)
            new_pose = skin_subset(edited, skeleton, p, opened, mesh_arrays[mesh_index], selected)
            delta = np.linalg.norm(new_pose - old_pose, axis=1)
            check(float(np.max(delta)) >= 0.05 and float(np.mean(delta)) >= 0.02,
                  f"Jaw quaternion fails to move actual mouth geometry with head held fixed: {stem}, mesh {mesh_index}")
            protected = fang_selections[mesh_index]
            fang_delta = 0.
            if protected:
                old_fangs = skin_subset(edited, skeleton, p, closed, mesh_arrays[mesh_index], protected)
                new_fangs = skin_subset(edited, skeleton, p, opened, mesh_arrays[mesh_index], protected)
                fang_delta = float(np.max(np.linalg.norm(new_fangs - old_fangs, axis=1)))
                check(fang_delta <= 1e-7, f"Lower-jaw motion drags an upper fang: {stem}, mesh {mesh_index}")
            per_mesh.append({"mesh": mesh_index, "vertices": len(selected),
                             "max_jaw_only_vertex_travel": float(np.max(delta)),
                             "mean_jaw_only_vertex_travel": float(np.mean(delta)),
                             "max_upper_fang_travel": fang_delta})
        motion.append({"stem": stem, "opened_frame": opened_frame,
                       "closed_frame": FRAMES[stem] - 1, "head_and_body_held_fixed": True,
                       "meshes": per_mesh})
    check(probe_path.is_file(), "Missing independent Blender fixed-head mouth probe")
    probe = json.loads(probe_path.read_text())
    check(probe.get("fixed_head") is True and probe.get("neutral_other_bones") is True,
          "Blender mouth probe did not hold the head/other joints still")
    check(probe.get("geometry_sha256") == sha256(after_path) and probe.get("patched_geometry_sha256") == sha256(after_path),
          "Blender mouth probe is missing geometry identity or describes a stale jaw patch")
    angles = probe.get("angles", [])
    check(len(angles) >= 4 and any(item["degrees"] < 0 for item in angles) and
          any(item["degrees"] >= 25 for item in angles),
          "Blender probe does not cover closed/open jaw extremes")
    for measurement in angles:
        for field in ("degrees", "lowerjaw_max_displacement", "lowerjaw_mean_displacement", "upperfang_max_displacement"):
            check(math.isfinite(float(measurement[field])), f"Nonfinite Blender jaw probe: {field}")
        check(measurement["moving_lowerjaw_vertices"] >= 24 and measurement["upperfang_vertices"] >= 80,
              "Blender probe checked too few mouth/upper-fang vertices")
        check(measurement["upperfang_max_displacement"] <= 1e-7,
              "Blender jaw-only motion drags protected upper fangs")
        if measurement["degrees"] >= 25:
            check(measurement["lowerjaw_max_displacement"] >= 0.10 and
                  measurement["lowerjaw_mean_displacement"] >= 0.04,
                  "Blender fixed-head mouth opening lacks meaningful actual geometry movement")
    check(demo_path.is_file(), "Missing final Blender closed-open-closed mouth cycle proof")
    demo = json.loads(demo_path.read_text())
    check(demo.get("geometry_sha256") == sha256(after_path) and
          demo.get("patched_geometry_sha256") == sha256(after_path) and
          demo.get("fixed_head") is True and demo.get("neutral_other_bones") is True,
          "Mouth-cycle proof is stale or moves the head/other joints")
    frames = demo.get("frames", [])
    check(len(frames) >= 12 and [item["frame"] for item in frames] == list(range(len(frames))),
          "Mouth-cycle proof has missing or unordered frames")
    openings = np.asarray([item["projected_front_opening"] for item in frames], dtype=float)
    upper = np.asarray([item["upper_incisor_position"] for item in frames], dtype=float)
    lower = np.asarray([item["lower_lip_position"] for item in frames], dtype=float)
    check(np.isfinite(openings).all() and np.isfinite(upper).all() and np.isfinite(lower).all() and
          np.all(openings >= 0), "Invalid mouth-cycle landmark measurements")
    check(float(np.max(np.linalg.norm(upper - upper[0], axis=1))) <= 1e-7,
          "Head-fixed mouth proof moves the upper incisor")
    check(all(item["upperfang_max_displacement"] <= 1e-7 for item in frames),
          "Mouth-cycle proof moves upper fangs")
    check(frames[0]["degrees"] <= 0 and frames[-1]["degrees"] <= 0 and
          max(item["degrees"] for item in frames) >= 25,
          "Mouth-cycle proof does not show closed-open-closed jaw articulation")
    check(openings[0] <= 1e-6 and openings[-1] <= 1e-6 and float(np.max(openings)) >= 0.05,
          "Actual projected mouth gap fails to open and close")
    check(float(np.linalg.norm(lower[-1] - lower[0])) <= 1e-6 and
          math.isclose(demo["mouth_opening_change"], float(np.ptp(openings)), rel_tol=0, abs_tol=1e-7),
          "Mouth-cycle landmark closure or declared opening change disagrees")
    report["checks"].append({"name": "actual_jaw_only_skin_motion_with_upper_fangs_fixed",
                             "passed": True, "clips": motion, "blender_probe": str(probe_path),
                             "closed_open_closed_demo": str(demo_path),
                             "demo_projected_mouth_gap_change": float(np.ptp(openings)),
                             "demo_upper_incisor_max_travel": float(np.max(np.linalg.norm(upper - upper[0], axis=1)))})


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=root / "original")
    parser.add_argument("--v2", type=Path, default=root / "modified_v2")
    parser.add_argument("--modified", type=Path, default=root / "modified_v3")
    parser.add_argument("--diagnostics", type=Path, default=root / "work/v3/choreography.json")
    parser.add_argument("--report", type=Path, default=root / "outputs_v3/validation.json")
    parser.add_argument("--original-zip", type=Path)
    parser.add_argument("--max-adjacent-limb-degrees", type=float,
                        help="Optional agreed quality gate; fail a larger one-frame local limb rotation")
    parser.add_argument("--jaw-report", type=Path, default=root / "work/v3/jaw_patch_report.json")
    parser.add_argument("--jaw-probe", type=Path, default=root / "work/v3/jaw_deformation_probe.json")
    parser.add_argument("--jaw-demo", type=Path, default=root / "work/v3/jaw_demo_report.json")
    args = parser.parse_args()
    report = {"passed": False, "revision": 3, "validation_scope": "offline binary/data and planted-foot consistency",
              "source": str(args.source.resolve()), "v2": str(args.v2.resolve()),
              "modified": str(args.modified.resolve()), "checks": []}
    try:
        validate_static_assets(args.source, args.v2, args.modified, report, args.original_zip)
        animations = validate_animations(args.source, args.v2, args.modified, report)
        validate_neutral_and_plants(args.source, animations, args.diagnostics, report)
        validate_limb_and_jaw_curves(args.source, args.v2, animations, report, args.max_adjacent_limb_degrees)
        validate_jaw_geometry(args.source, args.v2, args.modified, animations, report, args.jaw_report, args.jaw_probe, args.jaw_demo)
        # The packager must compare this complete inventory, not just a PASS
        # flag, to reject files changed by a later bake after validation.
        report["asset_sha256"] = {relative.as_posix(): sha256(path)
                                   for relative, path in sorted(inventory(args.modified).items())}
        report["passed"] = True
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
        traceback.print_exc()
    report["limitations"] = [
        "V3 keeps the reviewed120/96-frame timing at the original FPS; initial vanilla durations were deliberately extended in V2.",
        "Offline FK and ankle plants validate Dinotigermon's motion only, not an enemy constraint or synchronized victim reaction.",
        "A Windows game runtime is unavailable; actual battle spacing, engine hit timing, loader behavior, camera framing, and collisions remain untested in game.",
        "This script does not verify rendered head/fang clearance; that is checked separately in Blender.",
        "All existing locales use the requested English text as fallback.",
    ]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report.resolve()}")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
