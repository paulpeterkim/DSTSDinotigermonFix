"""Package validated V3 assets, motion previews and a reproducible script bundle."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs_v3'
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)

def phase(stem,f):
 if stem=='bs01':
  for stop,label in [(17,'LOAD'),(32,'APPROACH / PIN'),(45,'HOLD / DRAW FANGS'),(54,'STAB'),(76,'TEAR'),(120,'RELEASE')]:
   if f<stop:return label
 else:
  for stop,label in [(19,'LOAD'),(36,'RISE / COIL'),(43,'FANG DOWNSWING'),(52,'FOLLOW-THROUGH / LAND'),(96,'RECOVER')]:
   if f<stop:return label

report=json.loads((OUT/'validation.json').read_text())
if not report['passed']:raise ValueError('V3 validation did not pass')
current_assets={p.relative_to(ROOT/'modified_v3').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
 for p in sorted((ROOT/'modified_v3').rglob('*')) if p.is_file()}
if current_assets!=report.get('asset_sha256'):raise ValueError('Game assets differ from the validated inventory')
clearance=json.loads((OUT/'clearance.json').read_text())
scene=OUT/'Dinotigermon_Fang_Attacks_V3.blend'
if clearance['scene_identity']['sha256']!=hashlib.sha256(scene.read_bytes()).hexdigest():
 raise ValueError('Clearance report is for a different Blender scene')
geom_hash=hashlib.sha256((ROOT/'modified_v3/dsts-loader/patch/chr424857.geom').read_bytes()).hexdigest()
for name,key in [('jaw_patch_report.json','patched_sha256'),('jaw_deformation_probe.json','geometry_sha256'),('jaw_demo_report.json','geometry_sha256')]:
 if json.loads((OUT/name).read_text())[key]!=geom_hash:raise ValueError(f'Stale jaw report: {name}')
for stem,title,n in [('bs01','Ground Fang V3',120),('bs02','Highland Fang V3',96)]:
 folder=ROOT/'work/v3/sequence'/stem
 data=json.loads((folder/'frames.json').read_text())
 indices=data['frames'];paths=sorted(folder.glob('*.png'))
 if len(paths)!=len(indices) or indices[-1]!=n-1:raise ValueError(f'Incomplete sequence: {stem}')
 frames=[]
 for path,f in zip(paths,indices):
  im=Image.open(path).convert('RGB');draw=ImageDraw.Draw(im)
  draw.rectangle((0,0,640,65),fill='#202733')
  draw.text((16,6),title,font=font,fill='#f2f3f7')
  draw.text((17,40),phase(stem,f),font=small,fill='#e5be82')
  draw.text((16,455),'Blender attacker-motion preview',font=small,fill='#c1c8d5')
  frames.append(im)
 palette_image=Image.new('RGB',(640,480*5))
 for i,index in enumerate([0,len(frames)//4,len(frames)//2,3*len(frames)//4,len(frames)-1]):palette_image.paste(frames[index],(0,480*i))
 palette=palette_image.quantize(colors=256)
 frames=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in frames]
 # GIF stores centiseconds. Quantize cumulative timestamps so 30-fps motion
 # alternates 60/70 ms instead of truncating every 67-ms interval to 60 ms.
 stamps=[round((f-indices[0])/data['fps']*100)*10 for f in indices]
 duration=[b-a for a,b in zip(stamps,stamps[1:])]+[500]
 frames[0].save(OUT/(title.replace(' ','_')+'.gif'),save_all=True,append_images=frames[1:],duration=duration,loop=0,disposal=2,optimize=False)

jaw_demo=json.loads((OUT/'jaw_demo_report.json').read_text())
jaw_frames=[Image.open(ROOT/f'work/v3/jaw_demo_{entry["frame"]:02d}.png').convert('RGB') for entry in jaw_demo['frames']]
jaw_palette=jaw_frames[len(jaw_frames)//2].quantize(colors=256)
jaw_frames=[im.quantize(palette=jaw_palette,dither=Image.Dither.NONE) for im in jaw_frames]
jaw_stamps=[round(i/jaw_demo['fps']*100)*10 for i in range(len(jaw_frames)+1)]
jaw_frames[0].save(OUT/'Jaw_Motion_V3.gif',save_all=True,append_images=jaw_frames[1:],duration=[b-a for a,b in zip(jaw_stamps,jaw_stamps[1:])],loop=0,disposal=2,optimize=False)

zip_path=OUT/'Dinotigermon_Fang_Skills_V3_TEST.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((ROOT/'modified_v3').rglob('*')):
  if p.is_file():z.write(p,p.relative_to(ROOT/'modified_v3'))
 z.write(OUT/'README_V3.md','README_Fang_Skills_V3.md')
with zipfile.ZipFile(zip_path) as z:
 if z.testzip() is not None:raise ValueError('Mod ZIP CRC failure')
 for p in (ROOT/'modified_v3').rglob('*'):
  if p.is_file() and z.read(p.relative_to(ROOT/'modified_v3').as_posix())!=p.read_bytes():raise ValueError('Packed asset mismatch')
source=OUT/'Dinotigermon_Fang_Skills_V3_Source.zip'
with zipfile.ZipFile(source,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((ROOT/'scripts').glob('*.py')):z.write(p,Path('scripts')/p.name)
 for name in ['README_V3.md','validation.json','clearance.json','jaw_patch_report.json','jaw_deformation_probe.json','jaw_demo_report.json']:z.write(OUT/name,name)
 z.write(ROOT/'work/v3/choreography.json','choreography.json')
with zipfile.ZipFile(source) as z:
 if z.testzip() is not None:raise ValueError('Source ZIP CRC failure')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 for p in sorted(OUT.iterdir()) if p.is_file() and p.suffix!='.blend1' and p.name!='SHA256.json'}
(OUT/'SHA256.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({n:v['bytes'] for n,v in manifest.items()},indent=2))
print('Both archives passed CRC; every packed game asset matches the validated directory.')
