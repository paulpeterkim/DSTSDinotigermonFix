"""Retarget selected lower mandible influences in place; never serialize GEOM.

Only fixed-size vertex palette indices/half-float weights are patched. Source
positions, normals, UVs, topology, materials, skeleton, palettes, and offsets are
preserved byte-for-byte. Anatomical selection is based on inspected connected
components and a mask confined to the independent lower-muzzle skin component.
"""
from pathlib import Path
from hashlib import sha256
import json
import math
import struct
import numpy as np

from geom_preview import read_geom
from inspect_jaw_v3 import components

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'modified_v2/dsts-loader/patch/chr424857.geom'
DEST = ROOT/'modified_v3/dsts-loader/patch/chr424857.geom'
REPORT = ROOT/'work/v3/jaw_patch_report.json'


def smooth(value):
    value = min(1., max(0., value)); return value*value*(3-2*value)


def selection(geom):
    vertices, points, groups = components(geom.meshes[0])
    by_id = {min(group): group for group in groups}
    skin = by_id[20732]
    ids = {i for i in skin if points[i,1] < 1.055 and points[i,2] > .96
           and abs(points[i,0]) < .19}
    # Keep the lateral cheek plates on the upper head. They cover the saber
    # fang roots; moving them would visually uncover otherwise fixed fangs.
    _, _, secondary = components(geom.meshes[1])
    chin = next(group for group in secondary if min(group) == 22291)
    ids.update(chin)
    # The long saber fangs and shorter side fangs are upper-head structures.
    upper_fangs = set().union(*(by_id[i] for i in (2264,5560,2308,5605)))
    upper_teeth = set()
    for group in groups:
        p=points[list(group)];lo=p.min(0);hi=p.max(0)
        if len(group) in (6,8) and lo[1]>.9 and hi[1]<1.02 and lo[2]>1.18:
            upper_teeth.update(group)
    protected = upper_fangs | upper_teeth | by_id[2682] | by_id[2193] | by_id[5488]
    protected_keys = {tuple(np.round(points[i],5)) for i in protected}
    targets = {tuple(np.round(points[i],5)):smooth((points[i,2]-.95)/.16)
               for i in ids if tuple(np.round(points[i],5)) not in protected_keys}
    return targets, protected_keys, sorted(upper_fangs), sorted(upper_teeth)


def main():
    if not DEST.is_file():raise SystemExit('Parent must prepare modified_v3 before jaw patch')
    geom=read_geom(SOURCE); original=SOURCE.read_bytes(); raw=bytearray(original)
    targets, protected, fangs, teeth=selection(geom)
    patches=[]; allowed=[]; counts=[]
    for mi,mesh in enumerate(geom.meshes):
        verts=mesh.unpack_vertices(); attributes={a.atype:a for a in mesh.attributes}
        ia,wa=attributes[10],attributes[11]
        if ia.dtype!=0 or wa.dtype!=8 or ia.count!=wa.count:
            raise ValueError('Unexpected fixed-size influence layout')
        capacity=ia.count; palette=list(mesh.matrix_palette)
        if 6 not in palette or 7 not in palette:raise ValueError('Missing head/jaw palette entries')
        count=0
        for vi,vertex in enumerate(verts):
            key=tuple(np.round(vertex.position[:3],5))
            if key not in targets:continue
            alpha=targets[key]
            influences={int(palette[int(b)]):float(w) for b,w in zip(vertex.indices,vertex.weights) if w>0}
            head=influences.get(6,0.)
            if head<=0:raise ValueError('Selected mandible vertex lacks a head influence')
            influences[7]=head*alpha; influences[6]=head*(1-alpha)
            influences={b:w for b,w in influences.items() if w>1e-6}
            if len(influences)>capacity:raise ValueError('Insufficient existing influence slots')
            # Preserve original neck influence while transferring only head weight.
            entries=sorted(influences.items(),key=lambda item:(-item[1],item[0]))
            total=sum(w for _,w in entries)
            new_indices=[palette.index(b) for b,_ in entries]+[0]*(capacity-len(entries))
            new_weights=[w/total for _,w in entries]+[0.]*(capacity-len(entries))
            base=mesh.vertices_offset+vi*mesh.bytes_per_vertex
            index_start=base+ia.offset; weight_start=base+wa.offset
            index_bytes=struct.pack('<'+'B'*capacity,*new_indices)
            weight_bytes=struct.pack('<'+'e'*capacity,*new_weights)
            raw[index_start:index_start+capacity]=index_bytes
            raw[weight_start:weight_start+capacity*2]=weight_bytes
            allowed.extend([(index_start,index_start+capacity),(weight_start,weight_start+capacity*2)])
            decoded=struct.unpack('<'+'e'*capacity,weight_bytes)
            patches.append({'mesh':mi,'vertex':vi,'position':list(vertex.position[:3]),
                            'head_to_jaw_fraction':alpha,'index_range':[index_start,index_start+capacity],
                            'weight_range':[weight_start,weight_start+capacity*2],
                            'old_indices':list(vertex.indices),'old_weights':list(vertex.weights),
                            'new_indices':new_indices,'new_weights':list(decoded)})
            count+=1
        counts.append(count)
    permitted=np.zeros(len(original),dtype=bool)
    for start,end in allowed:permitted[start:end]=True
    before=np.frombuffer(original,dtype=np.uint8);after=np.frombuffer(raw,dtype=np.uint8)
    changed=np.flatnonzero(before!=after)
    if len(raw)!=len(original) or not permitted[changed].all():
        raise ValueError('Patch touched bytes outside permitted influence fields')
    # All data at/after the material boundary, including IBPMs and skeleton, stays exact.
    if bytes(raw[geom.materials_offset:])!=original[geom.materials_offset:]:
        raise ValueError('Patch changed protected material/skeleton tail')
    DEST.write_bytes(raw)
    rebuilt=read_geom(DEST)
    max_error=0.
    for mi,mesh in enumerate(rebuilt.meshes):
        verts=mesh.unpack_vertices()
        source_vertices=geom.meshes[mi].unpack_vertices()
        for entry in (p for p in patches if p['mesh']==mi):
            vertex=verts[entry['vertex']]
            max_error=max(max_error,abs(sum(vertex.weights)-1))
            if not all(math.isfinite(float(w)) and 0<=w<=1 for w in vertex.weights):
                raise ValueError('Invalid patched weights')
            if not any(mesh.matrix_palette[int(b)]==7 and w>0 for b,w in zip(vertex.indices,vertex.weights)):
                raise ValueError('Patched vertex does not actually influence the jaw')
        for vi,vertex in enumerate(verts):
            if tuple(np.round(vertex.position[:3],5)) in protected:
                old=source_vertices[vi]
                if list(vertex.indices)!=list(old.indices) or list(vertex.weights)!=list(old.weights):
                    raise ValueError('Upper head/teeth/fang influence changed')
    if max_error>5e-4:raise ValueError('Half-float weights failed normalization tolerance')
    report={'source':str(SOURCE),'destination':str(DEST),'source_sha256':sha256(original).hexdigest(),
            'patched_sha256':sha256(raw).hexdigest(),'file_size':len(raw),'changed_byte_count':len(changed),
            'allowed_ranges':allowed,'mesh_patch_counts':counts,'max_weight_sum_error':max_error,
            'protected_material_start':geom.materials_offset,'material_tail_unchanged':True,
            'protected_upper_fang_vertices':fangs,'protected_upper_teeth_vertices':teeth,
            'selection_rule':'Component22291 chin and forward lowerjaw skin in20732; explicit upperface/teeth/fang/cheekplate exclusion.',
            'patches':patches}
    REPORT.parent.mkdir(parents=True,exist_ok=True);REPORT.write_text(json.dumps(report,indent=2))
    print('JAW_PATCHED',counts,'changedbytes',len(changed),'normerror',max_error)


if __name__=='__main__':main()
