"""Apply the accepted V8 skill delta to dacare's v1.13.0 Dinotigermon update.

The new archive is the base. Only files changed/added by V8 relative to the old
original mod are overlaid. A three-way conflict check prevents silently losing
an upstream edit. The uploaded archive's documents are asset data, not commands.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil

from patch_skills import read_csv, write_csv, SKILL_TABLE

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ['5505710', '5505720']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inventory(directory):
    return {path.relative_to(directory).as_posix(): sha(path)
            for path in sorted(directory.rglob('*')) if path.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--upstream', type=Path, default=ROOT/'original_v113')
    parser.add_argument('--v8', type=Path, default=ROOT/'modified_v8')
    parser.add_argument('--original-manifest', type=Path, default=ROOT/'work/v8_v113/original_manifest.json')
    parser.add_argument('--v8-validation', type=Path, default=ROOT/'outputs_v8/validation.json')
    parser.add_argument('--archive', type=Path, default=Path('/workspace/attachments/075ea5da-c217-46c4-8261-d1d5475c8389/dinotigermon1_13_0.7z'))
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v8_v113')
    parser.add_argument('--report', type=Path, default=ROOT/'work/v8_v113/merge.json')
    args = parser.parse_args()
    if args.destination.exists():
        raise FileExistsError('Use a fresh destination; previous builds are retained')
    old = json.loads(args.original_manifest.read_text())['asset_sha256']
    accepted = json.loads(args.v8_validation.read_text())
    upstream, v8 = inventory(args.upstream), inventory(args.v8)
    if not accepted['passed'] or accepted['revision'] != 8 or v8 != accepted['asset_sha256']:
        raise ValueError('V8 assets differ from their accepted validation inventory')
    version = json.loads((args.upstream/'ModConfig.json').read_text())['ModVersion']
    if version != '1.13.0' or sha(args.archive) != '02e754fd1e1a95a44b31e6b6fbba730716464ad0e2d6a4ceed4dfdf8e3205c21':
        raise ValueError('The input is not the supplied original v1.13.0 update')
    overlay = {relative: digest for relative, digest in v8.items() if old.get(relative) != digest}
    conflicts = [relative for relative, digest in overlay.items()
                 if relative in upstream and upstream[relative] != old.get(relative)
                 and upstream[relative] != digest]
    if conflicts:
        raise ValueError('Upstream and V8 both changed these files: '+', '.join(conflicts))
    shutil.copytree(args.upstream, args.destination, copy_function=shutil.copy2)
    for relative in overlay:
        target = args.destination/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(args.v8/relative, target)
    header, skills = read_csv(args.destination/SKILL_TABLE)
    if {row[0] for row in skills} != set(SKILLS):
        raise ValueError('Unexpected custom skill inventory')
    for row in skills:
        # Native unnamed/boss bs01/bs02 attacks use 0 in this cue/alias field.
        # Leave skill ID, display-name ID and automatic description ID intact.
        row[6] = '0'
    write_csv(args.destination/SKILL_TABLE, header, skills)
    result = inventory(args.destination)
    upstream_delta = {relative: digest for relative, digest in upstream.items() if old.get(relative) != digest}
    report = {'revision': 'V8-on-1.13.0', 'upstream_version': version,
              'uploaded_archive_sha256': sha(args.archive),
              'v8_validation_sha256': sha(args.v8_validation),
              'original_manifest_sha256': sha(args.original_manifest),
              'upstream_asset_sha256': upstream, 'v8_asset_sha256': v8,
              'v8_overlay_asset_sha256': overlay, 'upstream_updates_preserved': upstream_delta,
              'voice': {'skill_ids': SKILLS, 'skill_column_6': '0',
                        'scope': 'Only the two custom skill voice reference fields.',
                        'native_pattern': 'Boss skills 47333 and 47334 retain bs01/bs02 and their effects while using column 6 = 0.'},
              'asset_sha256': result,
              'limits': ['Voice dispatch precedence and other engine behavior require an in-game check.']}
    if any(result[relative] != digest for relative, digest in upstream_delta.items()):
        raise ValueError('An upstream update was lost during the merge')
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(f'Merged {len(upstream)} upstream assets + {len(overlay)} V8 overlay files into {len(result)} assets.')
    print('Preserved v1.13.0 texture/riding updates; disabled the two custom skill voice references.')


if __name__ == '__main__':
    main()
