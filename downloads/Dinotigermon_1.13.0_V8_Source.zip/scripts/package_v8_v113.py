"""Package the validated v1.13.0 merge without replacing earlier V8 downloads."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs_v8_v113'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_zip(path, files):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source, name in files:
            archive.write(source, name)
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(files):
            raise ValueError('ZIP inventory/CRC failure')
        for source, name in files:
            if hashlib.sha256(archive.read(name)).hexdigest() != sha(source):
                raise ValueError('ZIP member hash mismatch: '+name)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    report = json.loads((OUT/'validation.json').read_text())
    assets = {p.relative_to(ROOT/'modified_v8_v113').as_posix(): sha(p)
              for p in sorted((ROOT/'modified_v8_v113').rglob('*')) if p.is_file()}
    if not report['passed'] or report['asset_sha256'] != assets:
        raise ValueError('Assets differ from the validated merge')
    merge_path = ROOT/'work/v8_v113/merge.json'
    if json.loads(merge_path.read_text())['asset_sha256'] != assets:
        raise ValueError('Merge report does not describe the packed assets')
    rebuild = ROOT/'work/v8_v113/rebuild.json'
    if rebuild.exists():
        proof = json.loads(rebuild.read_text())
        if not proof['passed'] or proof['asset_sha256'] != assets:
            raise ValueError('Stale/incomplete rebuild proof')
    shutil.copyfile(ROOT/'README_V8_1.13.0.md', OUT/'README_V8_1.13.0.md')
    checked_zip(OUT/'Dinotigermon_1.13.0_V8_Skills_TEST.zip',
                [(ROOT/'modified_v8_v113'/name, name) for name in assets]+
                [(OUT/'README_V8_1.13.0.md', 'README_V8_1.13.0.md')])
    relative = ['scripts/merge_v8_v113.py', 'scripts/validate_v8_v113.py',
                'scripts/package_v8_v113.py', 'scripts/patch_skills.py',
                'README_V8_1.13.0.md', 'outputs_v8_v113/validation.json',
                'outputs_v8/validation.json', 'work/v8_v113/original_manifest.json',
                'work/v8_v113/merge.json', 'work/v113_voice_research.json',
                'work/voice_native_evidence_alt.json']
    if rebuild.exists():
        relative.append('work/v8_v113/rebuild.json')
    checked_zip(OUT/'Dinotigermon_1.13.0_V8_Source.zip', [(ROOT/name, name) for name in relative])
    manifest = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256.json'}
    (OUT/'SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('All mod/source ZIP members and CRCs verified.')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
