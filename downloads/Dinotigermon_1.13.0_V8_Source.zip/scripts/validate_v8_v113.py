"""Independently check the v1.13.0/V8 merge and its two voice-reference edits.

Only Python's standard library and py7zr (to verify the supplied archive) are
required. Accepted V8 animation, rig, camera and effect bytes are checked against
the published ZIP; no new Blender/codec export is involved in this merge.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile
import traceback
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_SHA256 = '02e754fd1e1a95a44b31e6b6fbba730716464ad0e2d6a4ceed4dfdf8e3205c21'
V8_ZIP_SHA256 = '96ed8d3dad7c139df1912429f2c9e25b2893d3e978f0ef269bef8f6aa5ab7e25'
SKILL_TABLE = 'dsts-loader/patch/data/battle_skill.mbe/000_battle_skill_list.ap.csv'
STATUS_TABLE = 'dsts-loader/patch/data/digimon_status.mbe/000_digimon_status_data.ap.csv'
SKILLS = {'5505710', '5505720'}
UPSTREAM_CHANGED = {'ModConfig.json', 'Sewer56.Update.Metadata.json',
                    'dsts-loader/patch/images/dino057_base.img'}
UPSTREAM_ADDED = {'dsts-loader/patch/chr424857_r424_fn01.anim',
                  'dsts-loader/patch/chr424857_r424_fw01.anim',
                  'dsts-loader/patch/data/field_anime.mbe/001_field_digi_ride_animation.ap.csv'}


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def inventory(directory):
    check(directory.is_dir(), 'Missing mod directory: '+str(directory))
    result = {}
    for path in sorted(directory.rglob('*')):
        check(not path.is_symlink(), 'Unexpected symlink: '+str(path))
        if path.is_file():
            result[path.relative_to(directory).as_posix()] = sha(path)
    check(result, 'Empty mod directory: '+str(directory))
    return result


def typed_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        data = list(csv.reader(stream, strict=True))
    check(data, 'Empty CSV: '+str(path))
    header, rows = data[0], [row for row in data[1:] if row]
    kinds = []
    for index, field in enumerate(header):
        match = re.fullmatch(r'(empty|bool|float|double|string[23]?|u?int(?:8|16|32|64)) (\d+)', field)
        check(match is not None and int(match[2]) == index, 'Invalid typed CSV header: '+str(path))
        kinds.append(match[1])
    for line, row in enumerate(rows, 2):
        check(len(row) == len(header), f'CSV row width mismatch: {path}:{line}')
        for column, (kind, value) in enumerate(zip(kinds, row)):
            if kind == 'empty':
                check(value == '', f'Nonempty CSV padding: {path}:{line}:{column}')
            elif kind == 'bool':
                check(value in ('true', 'false'), f'Invalid bool: {path}:{line}:{column}')
            elif kind in ('float', 'double'):
                check(math.isfinite(float(value)), f'Invalid float: {path}:{line}:{column}')
            elif 'int' in kind:
                check(re.fullmatch(r'[+-]?\d+', value) is not None, f'Invalid integer: {path}:{line}:{column}')
                bits = int(re.search(r'\d+', kind)[0])
                minimum, maximum = ((0, 2**bits-1) if kind.startswith('u') else (-2**(bits-1), 2**(bits-1)-1))
                check(minimum <= int(value) <= maximum, f'Integer overflow: {path}:{line}:{column}')
    check(len({row[0] for row in rows}) == len(rows), 'Duplicate CSV primary key: '+str(path))
    return header, rows


def verify_uploaded_archive(archive_path, extracted, report):
    check(sha(archive_path) == ARCHIVE_SHA256, 'The input is not the supplied v1.13.0 archive')
    try:
        import py7zr
    except ImportError:
        # The cloud environment installs this optional reader in an isolated
        # task directory. A normal pip-installed py7zr works without this path.
        isolated = Path('/tmp/dinotigermon_archive_deps')
        if isolated.is_dir():
            sys.path.insert(0, str(isolated))
        import py7zr
    with py7zr.SevenZipFile(archive_path, 'r') as archive:
        for name in archive.getnames():
            value = PurePosixPath(name.replace('\\', '/'))
            check(not value.is_absolute() and '..' not in value.parts,
                  'Unsafe archive member path: '+name)
        check(archive.testzip() is None, 'Uploaded archive CRC failure')
    with tempfile.TemporaryDirectory(prefix='dinotigermon-v113-independent-extract-') as temp:
        with py7zr.SevenZipFile(archive_path, 'r') as archive:
            archive.extractall(path=temp)
        source = inventory(Path(temp))
    check(len(source) == 117, 'The original update has an unexpected file count')
    check(inventory(extracted) == source, 'The extracted update differs from the uploaded archive')
    check(json.loads((extracted/'ModConfig.json').read_text())['ModVersion'] == '1.13.0',
          'The source ModConfig version is not 1.13.0')
    report['uploaded_archive_sha256'] = ARCHIVE_SHA256
    report['upstream_asset_sha256'] = source
    report['checks'].append({'name': 'uploaded_v113_archive_crc_and_independent_extraction',
                             'passed': True, 'files': len(source)})
    return source


def verify_v8(zip_path, directory, accepted_path, report):
    check(sha(zip_path) == V8_ZIP_SHA256, 'V8 ZIP differs from the published accepted download')
    accepted = json.loads(accepted_path.read_text())
    check(accepted.get('passed') is True and accepted.get('revision') == 8,
          'A successful V8 baseline report is required')
    hashes = accepted['asset_sha256']
    check(len(hashes) == 141 and inventory(directory) == hashes, 'Extracted V8 inventory is stale')
    with zipfile.ZipFile(zip_path) as archive:
        check(archive.testzip() is None, 'Published V8 ZIP CRC failure')
        members = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
        check(len(members) == len(set(members)), 'Duplicate member in V8 ZIP')
        check(set(members) == set(hashes)|{'README_Fang_Skills_V8.md'}, 'V8 ZIP has an unexpected inventory')
        for relative, digest in hashes.items():
            check(hashlib.sha256(archive.read(relative)).hexdigest() == digest,
                  'V8 ZIP member differs from its accepted hash: '+relative)
    report['v8_zip_sha256'] = V8_ZIP_SHA256
    report['v8_validation_sha256'] = sha(accepted_path)
    report['checks'].append({'name': 'published_v8_zip_and_accepted_asset_inventory',
                             'passed': True, 'files': len(hashes),
                             'framing_audit_sha256': accepted['framing_audit_sha256']})
    return hashes


def overlay_paths():
    prefix = 'dsts-loader/patch/'
    paths = {prefix+'chr424857.geom', SKILL_TABLE, STATUS_TABLE,
             prefix+'data/battle_effect.mbe/000_battle_effect_list.ap.csv'}
    for stem in ('bs01', 'bs02'):
        paths.add(prefix+f'chr424857_{stem}.anim')
        for side in ('pc', 'em'):
            paths.add(prefix+f'cam_chr424857_{stem}_{side}.anim')
    for stem in ('ground', 'highland'):
        paths.update(prefix+f'ef_b_dt5057_{stem}_v8.{ext}' for ext in ('bson', 'geom', 'anim', 'nlst'))
    paths.update(prefix+f'images/ki481000000{i}.img' for i in range(6))
    paths.update(prefix+f'images/ki482000000{i}.img' for i in range(2))
    for locale in ('00', '01', '02', '03', '04', '05', '07', '09', '10', '11', '30'):
        paths.add(f'dsts-loader/patch_text{locale}/text/skill_name.mbe/000_Sheet1.ap.csv')
    return paths


def verify_merge_scope(upstream, v8, original_manifest, modified, report):
    manifest = json.loads(original_manifest.read_text())
    original = manifest['asset_sha256']
    check(manifest.get('base_version') == '1.11.0' and len(original) == 114,
          'The three-way original baseline is invalid')
    check(all(re.fullmatch(r'[0-9a-f]{64}', value) for value in original.values()),
          'The original manifest contains an invalid SHA256')
    check(set(original) <= set(upstream) and set(original) <= set(v8), 'An original mod asset was removed')
    added = set(upstream)-set(original)
    changed = {relative for relative in original if upstream[relative] != original[relative]}
    check(added == UPSTREAM_ADDED and changed == UPSTREAM_CHANGED,
          'The upstream update differs from the expected texture/riding/version changes')
    overlay = {relative for relative, digest in v8.items() if original.get(relative) != digest}
    check(overlay == overlay_paths() and len(overlay) == 37, 'The V8 delta is outside the accepted skill scope')
    conflicts = [relative for relative in overlay if relative in upstream
                 and upstream[relative] != original.get(relative) and upstream[relative] != v8[relative]]
    check(not conflicts, 'An upstream update conflicts with V8: '+str(conflicts))
    expected = dict(upstream)
    expected.update({relative: v8[relative] for relative in overlay})
    actual = inventory(modified)
    check(set(actual) == set(expected) and len(actual) == 144, 'Unexpected files were added or removed in the merged mod')
    for relative in expected:
        if relative != SKILL_TABLE:
            check(actual[relative] == expected[relative], 'A protected merged asset changed: '+relative)
    for relative in UPSTREAM_ADDED|UPSTREAM_CHANGED:
        check(actual[relative] == upstream[relative], 'An original-modder update was lost: '+relative)
    check(json.loads((modified/'ModConfig.json').read_text())['ModVersion'] == '1.13.0',
          'The upstream mod version was replaced')
    report['original_manifest_sha256'] = sha(original_manifest)
    report['v8_overlay_asset_sha256'] = {relative: v8[relative] for relative in sorted(overlay)}
    report['preserved_upstream_updates'] = {relative: actual[relative] for relative in sorted(UPSTREAM_ADDED|UPSTREAM_CHANGED)}
    report['scope'] = {'files': len(actual), 'upstream_files': len(upstream),
                       'v8_overlay_files': len(overlay), 'added_to_upstream': len(set(actual)-set(upstream)),
                       'changed_upstream_files': sum(actual[relative] != digest for relative, digest in upstream.items()),
                       'unchanged_upstream_files': sum(actual[relative] == digest for relative, digest in upstream.items())}
    report['checks'].append({'name': 'three_way_merge_scope_and_all_upstream_improvements_preserved',
                             'passed': True, **report['scope'],
                             'preserved_updates': sorted(UPSTREAM_ADDED|UPSTREAM_CHANGED)})
    return actual, expected, overlay


def verify_voice_and_gameplay(v8_directory, modified, actual, expected, report):
    old_header, old_rows = typed_csv(v8_directory/SKILL_TABLE)
    header, rows = typed_csv(modified/SKILL_TABLE)
    check(old_header == header and len(rows) == len(old_rows) == 2, 'The skill table schema/row inventory changed')
    old = {row[0]: row for row in old_rows}
    current = {row[0]: row for row in rows}
    check(set(old) == set(current) == SKILLS, 'Unexpected skill IDs')
    details = []
    independent_rows = []
    for original in old_rows:
        skill_id = original[0]
        row = current[skill_id]
        delta = [column for column, (before, after) in enumerate(zip(original, row)) if before != after]
        check(delta == [6] and row[6] == '0', 'Changes exceed the custom skill voice reference: '+skill_id)
        check(row[4] == skill_id and row[5] == '0', 'Skill names or automatic descriptions changed')
        check(row[12] in ('5505781', '5505782') and row[14] == row[16] == '0',
              'V8 main effect bindings changed')
        rewritten = original.copy(); rewritten[6] = '0'; independent_rows.append(rewritten)
        details.append({'skill_id': skill_id, 'changed_columns': delta, 'previous_voice_reference': original[6],
                        'voice_reference': row[6], 'description_id': row[5], 'animation_id': row[10],
                        'main_effect_id': row[12]})
    buffer = io.StringIO(newline='')
    writer = csv.writer(buffer, lineterminator='\r\n')
    writer.writerow(old_header); writer.writerows(independent_rows)
    check((modified/SKILL_TABLE).read_bytes() == buffer.getvalue().encode('utf-8'),
          'The skill CSV differs from an independent two-cell rewrite')
    expected[SKILL_TABLE] = hashlib.sha256(buffer.getvalue().encode('utf-8')).hexdigest()
    check(actual == expected, 'Final merged inventory differs from the independent reconstruction')
    check(not list((modified/'dsts-loader').glob('patch_text*/text/skill_explanation.mbe/*.csv')),
          'Removed custom description files were restored')
    report['skill_voice_changes'] = details
    report['checks'].append({'name': 'only_two_custom_skill_voice_cells_changed_from_v8',
                             'passed': True, 'skills': details,
                             'note': 'All other skill fields, gameplay values, names, targeting and effect references match V8.'})


def verify_native_pattern(evidence_path, report):
    evidence = json.loads(evidence_path.read_text())['preferred_direct_skill_sentinel']
    check(evidence['column'] == 6 and evidence['silent_value'] == '0', 'Native voice-reference evidence uses a different field')
    examples = evidence['paired_player_boss_skill_rows']
    check(len(examples) == 2, 'Missing native paired special-skill evidence')
    summary = []
    native_file = Path(evidence['path'])
    native_rows = None
    if native_file.exists():
        check(sha(native_file) == evidence['sha256'], 'The native evidence source changed')
        _, rows = typed_csv(native_file)
        native_rows = {row[0]: row for row in rows}
    for index, (player, boss, animation) in enumerate((('27331', '47333', '3'), ('27332', '47334', '4'))):
        pair = examples[index]
        check(set(pair) == {player, boss}, 'Unexpected native skill evidence pair')
        a, b = pair[player], pair[boss]
        check(a[6] == player and b[6] == '0' and a[10] == b[10] == animation
              and a[12] == b[12] == player, 'Native examples do not retain special animation/effect when voice reference is zero')
        if native_rows is not None:
            check(native_rows[player] == a and native_rows[boss] == b, 'Recorded evidence differs from native rows')
        summary.append({'player_skill': player, 'boss_skill': boss, 'animation_id': animation,
                        'shared_main_effect_id': player, 'boss_voice_reference': '0'})
    report['voice_evidence_sha256'] = sha(evidence_path)
    report['checks'].append({'name': 'native_zero_voice_reference_pattern_for_both_special_animation_slots',
                             'passed': True, 'native_source_sha256': evidence['sha256'],
                             'native_source_available_and_checked': native_rows is not None,
                             'examples': summary,
                             'limit': 'Native data establishes the field pattern; actual engine voice dispatch still needs an in-game check.'})


def verify_accepted_combat_bytes(v8, actual, overlay, report):
    protected = sorted(overlay-{SKILL_TABLE})
    check(all(actual[relative] == v8[relative] for relative in protected), 'An accepted V8 combat asset changed')
    report['checks'].append({'name': 'exact_v8_attack_camera_rig_effect_and_localized_name_bytes',
                             'passed': True, 'unchanged_v8_overlay_files': len(protected),
                             'actor_frame_counts_from_accepted_v8': {'bs01': 68, 'bs02': 48},
                             'note': 'Exact accepted V8 bytes preserve both active endings, jaw binding, four cameras, effect timings and mute settings.'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, default=Path('/workspace/attachments/075ea5da-c217-46c4-8261-d1d5475c8389/dinotigermon1_13_0.7z'))
    parser.add_argument('--upstream', type=Path, default=ROOT/'original_v113')
    parser.add_argument('--v8', type=Path, default=ROOT/'modified_v8')
    parser.add_argument('--v8-zip', type=Path, default=ROOT/'downloads/Dinotigermon_Fang_Skills_V8_TEST.zip')
    parser.add_argument('--v8-validation', type=Path, default=ROOT/'outputs_v8/validation.json')
    parser.add_argument('--original-manifest', type=Path, default=ROOT/'work/v8_v113/original_manifest.json')
    parser.add_argument('--modified', type=Path, default=ROOT/'modified_v8_v113')
    parser.add_argument('--voice-evidence', type=Path, default=ROOT/'work/voice_native_evidence_alt.json')
    parser.add_argument('--report', type=Path, default=ROOT/'outputs_v8_v113/validation.json')
    args = parser.parse_args()
    report = {'revision': 'V8-on-1.13.0', 'passed': False, 'checks': []}
    try:
        upstream = verify_uploaded_archive(args.archive, args.upstream, report)
        v8 = verify_v8(args.v8_zip, args.v8, args.v8_validation, report)
        actual, expected, overlay = verify_merge_scope(upstream, v8, args.original_manifest, args.modified, report)
        verify_voice_and_gameplay(args.v8, args.modified, actual, expected, report)
        verify_native_pattern(args.voice_evidence, report)
        verify_accepted_combat_bytes(v8, actual, overlay, report)
        tables = sorted(args.modified.rglob('*.ap.csv'))
        for path in tables:
            typed_csv(path)
        report['checks'].append({'name': 'all_merged_typed_csvs_parse_and_keep_valid_field_types',
                                 'passed': True, 'tables': len(tables)})
        report['asset_sha256'] = actual
        report['passed'] = True
    except Exception as error:
        report['error'] = str(error)
        report['traceback'] = traceback.format_exc()
    report['limits'] = ['The accepted V8 combat assets are reused without animation or camera reauthoring.',
                        'Native shader output, combat behavior and actual voice dispatch need an in-game check.',
                        'Only the two custom skill voice-reference cells are zeroed; no global voice bank or shared sound cue is altered.']
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report}")
    if not report['passed']:
        print(report['error'], file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
