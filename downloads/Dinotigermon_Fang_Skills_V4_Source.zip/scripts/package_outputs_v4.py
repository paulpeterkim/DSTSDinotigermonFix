"""Package V4 only after matching every game file to its validation hash."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs_v4'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    # In the distributable source ZIP the editable README is at the root.
    if not (OUT/'README_V4.md').exists():
        shutil.copyfile(ROOT/'README_V4.md', OUT/'README_V4.md')
    report = json.loads((OUT/'validation.json').read_text())
    assets = {p.relative_to(ROOT/'modified_v4').as_posix(): sha(p)
              for p in sorted((ROOT/'modified_v4').rglob('*')) if p.is_file()}
    if not report['passed'] or report['asset_sha256'] != assets:
        raise ValueError('V4 assets differ from the validated inventory')
    mod = OUT/'Dinotigermon_Fang_Skills_V4_EFFECTS_TEST.zip'
    with zipfile.ZipFile(mod, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in assets:
            z.write(ROOT/'modified_v4'/name, name)
        z.write(OUT/'README_V4.md', 'README_Fang_Skills_V4.md')
    with zipfile.ZipFile(mod) as z:
        if z.testzip() is not None:
            raise ValueError('Mod ZIP CRC failure')
        for name in assets:
            if hashlib.sha256(z.read(name)).hexdigest() != assets[name]:
                raise ValueError(f'Mod ZIP asset mismatch: {name}')
    source = OUT/'Dinotigermon_Fang_Skills_V4_Source.zip'
    scripts = ['add_effects_v4.py', 'validate_mod_v4.py', 'render_camera_v4.py',
               'package_outputs_v4.py', 'anim_codec.py', 'motion_math.py',
               'patch_skills.py', 'validate_mod.py']
    baseline = ROOT/'outputs_v3/validation.json'
    if not baseline.exists():
        baseline = ROOT/'baseline_v3_validation.json'
    with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in scripts:
            z.write(ROOT/'scripts'/name, 'scripts/'+name)
        z.write(OUT/'README_V4.md', 'README_V4.md')
        z.write(OUT/'validation.json', 'outputs_v4/validation.json')
        z.write(baseline, 'baseline_v3_validation.json')
        for name in ['native_effect_references.json', 'effects.json']:
            z.write(ROOT/'work/v4'/name, 'work/v4/'+name)
    with zipfile.ZipFile(source) as z:
        if z.testzip() is not None:
            raise ValueError('Source ZIP CRC failure')
    folder = ROOT/'work/v4/camera_preview'
    if (folder/'frames.json').exists():
        from PIL import Image, ImageDraw, ImageFont
        data = json.loads((folder/'frames.json').read_text())
        camera = ROOT/'modified_v4/dsts-loader/patch/cam_chr424857_bs02_pc.anim'
        if data['camera_sha256'] != sha(camera):
            raise ValueError('Camera preview is stale')
        paths = sorted(folder.glob('*.png'))
        if len(paths) != len(data['frames']):
            raise ValueError('Camera preview is incomplete')
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 19)
        small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 12)
        images = []
        for path in paths:
            im = Image.open(path).convert('RGB')
            draw = ImageDraw.Draw(im)
            draw.rectangle((0, 0, 640, 42), fill='#202733')
            draw.text((12, 10), 'Highland Fang V4 — camera preview', font=font, fill='white')
            draw.rectangle((0, 452, 640, 480), fill='#202733')
            draw.text((12, 460), 'Exported camera; native particles require the game.', font=small, fill='#e5be82')
            images.append(im)
        palette = images[len(images)//2].quantize(colors=256)
        images = [im.quantize(palette=palette, dither=Image.Dither.NONE) for im in images]
        stamps = [round((f-data['frames'][0])/data['fps']*100)*10 for f in data['frames']]
        durations = [b-a for a, b in zip(stamps, stamps[1:])]+[500]
        images[0].save(OUT/'Highland_Camera_V4.gif', save_all=True, append_images=images[1:],
                       duration=durations, loop=0, disposal=2, optimize=False)
    manifest = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256.json'}
    (OUT/'SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('V4 mod/source ZIP CRC and every packed game-asset hash verified.')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
