"""Add native wind/quake bindings and a bounded landing camera shake to V3.

Native particle playback follows the game's hit/effect sequence. This script
does not invent an undocumented per-frame particle scheduler or change damage.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil

import numpy as np

from anim_codec import read, write, sample
from motion_math import qrotate
from patch_skills import read_csv, write_csv, SKILL_TABLE

ROOT = Path(__file__).resolve().parents[1]
COMMIT = 'f633513a7d86bd70d82f2766ce01157ec91285af'
REPOSITORY = 'https://github.com/zeak6464/DigimonTimeStrangerToolKit'
CHANGES = {'5505710': {16: '30191'}, '5505720': {14: '30182', 16: '12010'}}
START, PEAK, END = 43, 46, 62


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(folder):
    return {p.relative_to(folder).as_posix(): digest(p)
            for p in sorted(folder.rglob('*')) if p.is_file()}


def collect_references(base):
    paths = {'skills': base/'data/battle_skill.mbe/000_battle_skill_list.csv',
             'effects': base/'data/battle_effect.mbe/000_battle_effect_list.csv'}
    parsed = {key: read_csv(path) for key, path in paths.items()}
    wanted = {'skills': {'30191', '30181', '48821', '28062'},
              'effects': {'30191', '30182', '12010', '30291', '30031'}}
    result = {'source': {'repository': REPOSITORY, 'commit': COMMIT,
                        'files': {key: {'path': str(path.relative_to(base.parent)),
                                        'sha256': digest(path)} for key, path in paths.items()}},
              'workshop': 'https://hyotan-dev.github.io/dstsworkshop/documentation/mbe/battle_skill/',
              'headers': {key: data[0] for key, data in parsed.items()},
              'native_skills': {r[0]: r for r in parsed['skills'][1] if r[0] in wanted['skills']},
              'native_effects': {r[0]: r for r in parsed['effects'][1] if r[0] in wanted['effects']},
              'notes': ['Native Wind Claw uses effect30191 in skill field16.',
                        'Native Awesome Quake uses effect30182 in field14 and rock12010 in field16.',
                        'Native skills48821 and28062 provide timing1 precedents for these effect slot types.',
                        'Their particle spawn frame, scale and duration are not established by these tables.']}
    validate_references(result)
    return result


def validate_references(refs):
    effects, skills = refs['native_effects'], refs['native_skills']
    for effect, asset in [('30191', 'ef_b_gwi_s02'), ('30182', 'ef_b_gro_a01'),
                          ('12010', 'ef_b_hit_170_rock')]:
        if effects[effect][0] != effect or effects[effect][4] != asset:
            raise ValueError(f'Native effect reference mismatch: {effect}')
    if skills['30191'][16] != '30191' or skills['30181'][14:17:2] != ['30182', '12010']:
        raise ValueError('Native effect slot reference mismatch')
    if skills['48821'][11] != '1' or skills['28062'][11] != '1':
        raise ValueError('Native timing1 precedent mismatch')
    for skill, field in [('48821', 16), ('28062', 14)]:
        effect = skills[skill][field]
        if effects[effect][5] != '4' or effects[effect][7] != '4':
            raise ValueError('Native timing1 effect type precedent mismatch')


def shake(frame, fps):
    """Camera-local translation only: smooth onset, peak on landing, then decay."""
    if frame <= START or frame >= END:
        return 0., np.zeros(3)
    if frame <= PEAK:
        envelope = math.sin(math.pi*.5*(frame-START)/(PEAK-START))**2
    else:
        envelope = math.cos(math.pi*.5*(frame-PEAK)/(END-PEAK))**2
    time = (frame-START)/fps
    offset = envelope*np.array([.045*math.sin(2*math.pi*7*time+.4),
                                .022*math.cos(2*math.pi*9.5*time+.3), 0.])
    return envelope, offset


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT/'modified_v3')
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v4')
    parser.add_argument('--baseline-validation', type=Path, default=ROOT/'outputs_v3/validation.json')
    parser.add_argument('--references', type=Path, default=ROOT/'work/v4/native_effect_references.json')
    parser.add_argument('--native-base', type=Path,
                        default=Path('/workspace/research_formats/DigimonTimeStrangerToolKit/Base'))
    args = parser.parse_args()
    baseline = json.loads(args.baseline_validation.read_text())
    if not baseline['passed'] or inventory(args.source) != baseline['asset_sha256']:
        raise ValueError('Source is not the validated V3 asset inventory')
    if args.destination.exists():
        raise FileExistsError('Destination exists; use a new folder to preserve previous builds')
    refs = json.loads(args.references.read_text()) if args.references.is_file() else collect_references(args.native_base)
    validate_references(refs)
    args.references.parent.mkdir(parents=True, exist_ok=True)
    args.references.write_text(json.dumps(refs, indent=2)+'\n')
    header, rows = read_csv(args.source/SKILL_TABLE)
    if {row[0] for row in rows} != set(CHANGES):
        raise ValueError('Expected exactly the two custom skills')
    for row in rows:
        for column, effect in CHANGES[row[0]].items():
            row[column] = effect
    shutil.copytree(args.source, args.destination, copy_function=shutil.copy2)
    write_csv(args.destination/SKILL_TABLE, header, rows)
    cameras = []
    for side in ('pc', 'em'):
        relative = Path(f'dsts-loader/patch/cam_chr424857_bs02_{side}.anim')
        old = read(args.source/relative, expected_bones=2)
        new = deepcopy(old)
        diagnostics = []
        for frame in range(old._source_frame_count):
            position, rotation, _ = sample(old, 0, frame)
            envelope, local = shake(frame, old.playback_rate)
            world = qrotate(rotation, local)
            if np.linalg.norm(world) > .06:
                raise ValueError('Camera shake exceeds the authored bound')
            if np.any(world):
                new.positions[0][frame] = (position+world).tolist()
            diagnostics.append({'frame': frame, 'envelope': envelope,
                                'local_offset': local.tolist(), 'world_offset': world.tolist()})
        rebuilt = write(new, args.destination/relative, preserve_duration=True, expected_bones=2)
        cameras.append({'path': relative.as_posix(), 'frames': rebuilt._source_frame_count,
                        'fps': rebuilt.playback_rate, 'samples': diagnostics,
                        'max_intended_offset': max(float(np.linalg.norm(s['world_offset'])) for s in diagnostics)})
    report = {'revision': 4, 'source_asset_sha256': inventory(args.source),
              'skill_changes': CHANGES, 'reference_sha256': digest(args.references),
              'shake': {'start_frame': START, 'peak_frame': PEAK, 'end_frame': END,
                        'max_offset_limit': .06, 'frequencies_hz': [7, 9.5], 'cameras': cameras},
              'limits': ['Native particles are rendered by the game, not staged in Blender.',
                         'Hit timing stays1 (after the actor clip); exact native VFX synchronization is untested.',
                         'Only the camera shake is authored on the landing frames.']}
    report_path = ROOT/'work/v4/effects.json'
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2)+'\n')
    print('V4 effects added; V3 actor animations, jaw binding and gameplay balance preserved.')
    print('Ground: Wind Claw hit; Highland: Awesome Quake sequence, rock hit and landing camera shake.')
    print('Native particle appearance and timing require an in-game test.')


if __name__ == '__main__':
    main()
