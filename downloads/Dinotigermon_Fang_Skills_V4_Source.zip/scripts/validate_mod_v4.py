#!/usr/bin/env python3
"""Validate V4 native visual references and bounded impact-camera motion.

The accepted V3 actor, jaw, textures and gameplay remain byte-identical. Native
effect bindings and camera offsets are checked offline; this does not establish
particle appearance, playback timing or combat behavior in the game engine.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import traceback

import numpy as np

import anim_codec
from patch_skills import GROUND_FANG_ID, HIGHLAND_FANG_ID, SKILL_TABLE
from validate_mod import check, inventory, parse_typed_csv, sha256

ROOT = Path(__file__).resolve().parents[1]
CAMERAS = [Path(f"dsts-loader/patch/cam_chr424857_bs02_{side}.anim")
           for side in ("pc", "em")]
ALLOWED = {SKILL_TABLE, *CAMERAS}
EXPECTED_SKILL_EDITS = {GROUND_FANG_ID: {16: "30191"},
                        HIGHLAND_FANG_ID: {14: "30182", 16: "12010"}}
EXPECTED_NATIVE = {
    "30191": ["30191", "", "", "", "ef_b_gwi_s02", "4", "", "4", "0", "1", "0", "-1", "-1", "false", ""],
    "30182": ["30182", "", "", "", "ef_b_gro_a01", "4", "", "4", "0", "1", "0", "-1", "-1", "false", ""],
    "12010": ["12010", "", "", "", "ef_b_hit_170_rock", "2", "CP01", "5", "0.8", "2", "6", "-1", "-1", "false", ""],
    "30031": ["30031", "", "", "", "ef_b_gfi_a02", "4", "", "4", "0", "1", "0", "-1", "-1", "false", ""],
    "30291": ["30291", "", "", "", "ef_b_gda_s01", "4", "", "4", "0", "1", "0", "-1", "-1", "false", ""],
}
SOURCE_COMMIT = "f633513a7d86bd70d82f2766ce01157ec91285af"
START, END = 43, 62
# Quaternion/translation packing can perturb unchanged samples by a few 1e-5.
CODEC_TOLERANCE = 0.0001


def close_tracks(left, right, *, atol=CODEC_TOLERANCE, quaternion=False):
    check(set(left) == set(right), "Animation track keyframes changed")
    largest = 0.
    for frame in left:
        a, b = np.asarray(left[frame]), np.asarray(right[frame])
        if quaternion and np.dot(a, b) < 0:
            b = -b
        error = float(np.max(np.abs(a - b)))
        check(error <= atol, f"Protected animation channel changed at frame {frame}: {error}")
        largest = max(largest, error)
    return largest


def validate_baseline(baseline, baseline_report, modified, report):
    accepted = json.loads(baseline_report.read_text())
    check(accepted.get("passed") is True and accepted.get("revision") == 3,
          "Baseline does not have a passing V3 validation report")
    before, after = inventory(baseline), inventory(modified)
    before_hashes = {p.as_posix(): sha256(file) for p, file in sorted(before.items())}
    check(before_hashes == accepted.get("asset_sha256"),
          "V3 baseline differs from its accepted complete hash inventory")
    check(set(before) == set(after), "V4 added or removed game files")
    changed = []
    for relative in sorted(before):
        old, new = before_hashes[relative.as_posix()], sha256(after[relative])
        if old != new:
            check(relative in ALLOWED, f"Unexpected change outside V4 scope: {relative}")
            changed.append({"path": relative.as_posix(), "v3_sha256": old, "v4_sha256": new})
    check({entry["path"] for entry in changed} == {p.as_posix() for p in ALLOWED},
          "Expected exactly the skill table and both Highland camera clips to change")
    report["baseline_validation_sha256"] = sha256(baseline_report)
    report["file_changes"] = changed
    report["checks"].append({"name": "accepted_v3_inventory_and_exact_v4_change_scope", "passed": True,
                              "files": len(before), "changed": len(changed),
                              "unchanged": len(before) - len(changed)})
    report["checks"].append({"name": "v3_body_jaw_textures_text_and_ground_cameras_preserved", "passed": True,
                              "note": "Byte identity inherits the accepted V3 actor, pin, jaw and limb checks; no new runtime claim."})
    return after


def validate_skills(baseline, modified, report):
    old_header, old_rows = parse_typed_csv(baseline / SKILL_TABLE)
    header, rows = parse_typed_csv(modified / SKILL_TABLE)
    check(header == old_header and len(header) == 73, "Skill schema changed")
    before, after = {r[0]: r for r in old_rows}, {r[0]: r for r in rows}
    check(set(before) == set(after) == set(EXPECTED_SKILL_EDITS), "Custom skill keys changed")
    details = []
    for skill_id, edits in EXPECTED_SKILL_EDITS.items():
        expected = before[skill_id].copy()
        for column, effect_id in edits.items():
            expected[column] = effect_id
        check(after[skill_id] == expected, f"Skill changed beyond the intended visual fields: {skill_id}")
        check(after[skill_id][11] == "1" and after[skill_id][12] == "0" and after[skill_id][28] == "0",
              f"Hit timing/main effect/damage element changed: {skill_id}")
        details.append({"skill": skill_id, "changed_columns": {str(k): v for k, v in edits.items()},
                        "hit_timing": after[skill_id][11], "damage_element": after[skill_id][28],
                        "target": after[skill_id][33], "power": after[skill_id][23],
                        "sp": after[skill_id][36]})
    all_tables = [parse_typed_csv(p) for p in sorted(modified.rglob("*.ap.csv"))]
    report["checks"].append({"name": "typed_append_csv_fields_widths_unique_keys", "passed": True,
                              "tables": len(all_tables), "rows": sum(len(rows) for _, rows in all_tables)})
    report["checks"].append({"name": "only_native_visual_skill_fields_changed", "passed": True, "skills": details,
                              "note": "Wind/rock presentation does not alter physical Null damage, balance, targeting or hit scheduling."})


def csv_rows_in_json(value):
    """Collect complete typed-table row snapshots from the provenance document."""
    if isinstance(value, list):
        if len(value) == 15 and all(isinstance(x, str) for x in value) and value[0].isdigit():
            yield value
        else:
            for child in value:
                yield from csv_rows_in_json(child)
    elif isinstance(value, dict):
        for child in value.values():
            yield from csv_rows_in_json(child)


def validate_native(references_path, native_source, report):
    references = json.loads(references_path.read_text())
    serialized = json.dumps(references)
    check(SOURCE_COMMIT in serialized, "Native reference document lacks the inspected toolkit commit")
    check("DigimonTimeStrangerToolKit" in serialized, "Missing native reference repository provenance")
    snapshots = {r[0]: r for r in csv_rows_in_json(references)}
    for effect_id, row in EXPECTED_NATIVE.items():
        check(snapshots.get(effect_id) == row, f"Native effect snapshot differs from verified source: {effect_id}")
    source_details = {"source_commit": SOURCE_COMMIT, "references_sha256": sha256(references_path)}
    skills = references["native_skills"]
    check(set(skills) == {"30191", "30181", "48821", "28062"}, "Native skill examples changed")
    check(all(len(row) == 73 and row[0] == key for key, row in skills.items()),
          "Native skill snapshots have invalid width/key")
    check(skills["30191"][16] == "30191", "Wind Claw native hit slot does not match")
    check(skills["30181"][14] == "30182" and skills["30181"][16] == "12010",
          "Awesome Quake native supplemental/hit slots do not match")
    check(skills["48821"][11] == "1" and skills["48821"][16] == "30291" and
          skills["28062"][11] == "1" and skills["28062"][14] == "30031",
          "Native timing1 slot-family examples do not match")
    if native_source is not None:
        _, source_rows = parse_typed_csv(native_source)
        native = {r[0]: r for r in source_rows}
        for effect_id, expected in EXPECTED_NATIVE.items():
            check(native.get(effect_id) == expected, f"Native table changed: {effect_id}")
        source_hash = sha256(native_source)
        check(source_hash == references["source"]["files"]["effects"]["sha256"],
              "Provenance snapshot does not bind the current native source table hash")
        native_skills_path = native_source.parent.parent / "battle_skill.mbe/000_battle_skill_list.csv"
        _, source_skills = parse_typed_csv(native_skills_path)
        skill_lookup = {r[0]: r for r in source_skills}
        check(sha256(native_skills_path) == references["source"]["files"]["skills"]["sha256"],
              "Native skill source table does not match the bound provenance hash")
        for skill_id, row in skills.items():
            check(skill_lookup.get(skill_id) == row, f"Native skill snapshot differs from source: {skill_id}")
        source_details.update({"source_table_sha256": source_hash, "source_table": str(native_source.resolve())})
    report["native_effect_references_sha256"] = sha256(references_path)
    report["checks"].append({"name": "verified_native_effect_ids_and_resource_names", "passed": True,
                              "effects": [{"id": k, "resource": v[4]} for k, v in EXPECTED_NATIVE.items()],
                              **source_details,
                              "note": "References establish native data identity; particle appearance and engine timing need in-game testing."})
    report["checks"].append({"name": "native_effect_slot_and_after_animation_timing_family_examples", "passed": True,
                              "wind_native_skill": "30191", "quake_native_skill": "30181",
                              "timing1_hit_example": "48821", "timing1_supplemental_example": "28062",
                              "note": "Matching native slot families supports the test configuration; exact spawn synchronization still needs runtime testing."})


def validate_cameras(baseline, modified, report):
    metrics = []
    offsets_by_side = {}
    for relative in CAMERAS:
        old = anim_codec.read(baseline / relative, expected_bones=2)
        new = anim_codec.read(modified / relative, expected_bones=2)
        check(old._source_frame_count == new._source_frame_count == 96, "Highland camera frame count changed")
        check(old.playback_rate == new.playback_rate, "Highland camera playback rate changed")
        check(math.isclose(old._source_duration, new._source_duration, rel_tol=0, abs_tol=2e-6),
              "Highland camera duration changed")
        for field in ("bone_count", "float_channel_count"):
            check(getattr(old, field) == getattr(new, field), f"Camera {field} changed")
        for field in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
            check(np.array_equal(getattr(old, field), getattr(new, field)), f"Camera metadata changed: {field}")
        for field in ("positions", "rotations", "scales", "float_channels"):
            check(set(getattr(old, field)) == set(getattr(new, field)), f"Camera channel set changed: {field}")
        maximum_protected_error = 0.
        for bone in range(2):
            for field in ("rotations", "scales"):
                maximum_protected_error = max(maximum_protected_error,
                    close_tracks(getattr(old, field)[bone], getattr(new, field)[bone], quaternion=field == "rotations"))
            if bone != 0:
                maximum_protected_error = max(maximum_protected_error,
                    close_tracks(old.positions[bone], new.positions[bone]))
        for channel in old.float_channels:
            maximum_protected_error = max(maximum_protected_error,
                close_tracks(old.float_channels[channel], new.float_channels[channel], atol=1e-5))
        check(set(old.positions[0]) == set(new.positions[0]) == set(range(96)),
              "Camera root position keys were added, dropped or made sparse")
        offsets = np.asarray([np.asarray(new.positions[0][f]) - np.asarray(old.positions[0][f]) for f in range(96)])
        check(np.isfinite(offsets).all(), "Nonfinite camera displacement")
        lengths = np.linalg.norm(offsets, axis=1)
        check(float(np.max(lengths)) <= .06 + CODEC_TOLERANCE, "Camera shake exceeds .06-unit displacement bound")
        check(float(np.max(lengths)) >= .02, "Camera shake is absent or too small to establish actual displacement")
        outside = list(range(START + 1)) + list(range(END, 96))
        check(float(np.max(lengths[outside])) <= CODEC_TOLERANCE,
              "Camera changed outside the impact window or fails zero boundary closure")
        peak = int(np.argmax(lengths))
        check(44 <= peak <= 52, f"Camera peak is displaced from Highland impact/landing: frame {peak}")
        check(float(np.max(lengths[58:END])) < float(np.max(lengths[44:53])) * .6,
              "Camera tremor does not decay toward the recovery boundary")
        # Count real direction reversals in the camera's own image plane. This
        # rejects a single displaced camera pose mislabeled as a tremor.
        from motion_math import qrotate, qinv
        local = np.asarray([qrotate(qinv(anim_codec.sample(old, 0, f)[1]), offsets[f]) for f in range(96)])
        reversals = []
        for axis in (0, 1):
            values = local[44:END, axis]
            signs = np.sign(values[np.abs(values) > .0005])
            reversals.append(int(np.count_nonzero(signs[1:] != signs[:-1])))
        check(max(reversals) >= 2, "Camera offset does not oscillate in its image plane")
        check(float(np.max(np.abs(local[:, 2]))) <= CODEC_TOLERANCE * 2,
              "Camera shake moves along the lens axis instead of lateral/up only")
        offsets_by_side[relative.as_posix()] = offsets
        metrics.append({"path": relative.as_posix(), "frames": 96, "playback_rate": new.playback_rate,
                        "duration": new._source_duration, "max_offset": float(np.max(lengths)),
                        "peak_frame": peak, "last_four_frames_max_offset": float(np.max(lengths[58:END])),
                        "max_protected_channel_error": maximum_protected_error,
                        "local_axis_sign_reversals": reversals,
                        "max_adjacent_offset_step": float(np.max(np.linalg.norm(np.diff(offsets, axis=0), axis=1))),
                        "decoded_world_offsets": offsets.tolist()})
    report["checks"].append({"name": "highland_camera_metadata_rotation_scale_fov_and_secondary_tracks_preserved",
                              "passed": True, "cameras": [{k: v for k, v in m.items() if k != "decoded_world_offsets"} for m in metrics]})
    report["checks"].append({"name": "bounded_local_plane_tremor_with_zero_boundaries_and_recovery_decay", "passed": True,
                              "window_frames": [START, END], "max_allowed_offset": .06, "cameras": metrics,
                              "note": "Decoded camera displacement is measured in the root coordinate space; game-side framing remains untested."})
    return offsets_by_side


def validate_diagnostics(path, baseline, baseline_report, references_path, decoded_offsets, report):
    diagnostics = json.loads(path.read_text())
    accepted = json.loads(baseline_report.read_text())
    check(diagnostics.get("revision") == 4, "Wrong authoring diagnostic revision")
    check(diagnostics.get("source_asset_sha256") == accepted["asset_sha256"],
          "Authoring diagnostics refer to a different V3 baseline")
    check(diagnostics.get("reference_sha256") == sha256(references_path),
          "Authoring diagnostics use stale native effect references")
    expected_changes = {skill: {str(column): value for column, value in edits.items()}
                        for skill, edits in EXPECTED_SKILL_EDITS.items()}
    check(diagnostics.get("skill_changes") == expected_changes, "Authoring diagnostic skill edits disagree")
    shake = diagnostics["shake"]
    check((shake["start_frame"], shake["peak_frame"], shake["end_frame"]) == (START, 46, END),
          "Authoring diagnostic camera phase bounds changed")
    check(shake["max_offset_limit"] == .06, "Authoring diagnostic camera bound changed")
    cameras = {camera["path"]: camera for camera in shake["cameras"]}
    check(set(cameras) == set(decoded_offsets), "Missing/extra diagnostic camera")
    results = []
    local_by_camera = []
    from motion_math import qrotate
    for relative, decoded in decoded_offsets.items():
        camera = cameras[relative]
        old = anim_codec.read(baseline / relative)
        check(camera["frames"] == 96 and camera["fps"] == old.playback_rate,
              f"Diagnostic timing mismatch: {relative}")
        samples = camera["samples"]
        check(len(samples) == 96 and [s["frame"] for s in samples] == list(range(96)),
              f"Diagnostic camera frames are missing or unordered: {relative}")
        envelope = np.asarray([s["envelope"] for s in samples], dtype=float)
        local = np.asarray([s["local_offset"] for s in samples], dtype=float)
        world = np.asarray([s["world_offset"] for s in samples], dtype=float)
        check(envelope.shape == (96,) and local.shape == world.shape == (96, 3) and
              np.isfinite(envelope).all() and np.isfinite(local).all() and np.isfinite(world).all(),
              f"Invalid camera diagnostic samples: {relative}")
        check(np.all((envelope >= 0) & (envelope <= 1)) and envelope[46] == 1,
              "Shake envelope is not normalized with the intended landing peak")
        check(np.all(envelope[:START + 1] == 0) and np.all(envelope[END:] == 0) and
              np.all(np.diff(envelope[START:47]) >= 0) and np.all(np.diff(envelope[46:END + 1]) <= 0),
              "Shake envelope does not rise from zero, decay and return to zero")
        check(float(np.max(np.abs(local[:, 2]))) <= 1e-12,
              "Authored camera shake changes the lens axis")
        predicted_world = np.asarray([qrotate(anim_codec.sample(old, 0, f)[1], local[f]) for f in range(96)])
        transform_error = float(np.max(np.linalg.norm(predicted_world - world, axis=1)))
        check(transform_error <= 1e-10, "Recorded camera-local offsets do not transform to recorded world offsets")
        max_intended = float(np.max(np.linalg.norm(world, axis=1)))
        check(max_intended <= .06 and math.isclose(camera["max_intended_offset"], max_intended, rel_tol=0, abs_tol=1e-12),
              "Recorded peak camera displacement disagrees")
        error = float(np.max(np.linalg.norm(decoded - world, axis=1)))
        check(error <= CODEC_TOLERANCE, f"Decoded camera displacement differs from recorded intended motion: {relative}, {error}")
        local_by_camera.append(local)
        results.append({"path": relative, "max_intended_offset": max_intended,
                        "max_decoded_vs_intended_error": error, "max_coordinate_transform_error": transform_error})
    check(np.array_equal(local_by_camera[0], local_by_camera[1]),
          "PC and enemy camera tremor use different local displacement patterns")
    report["effects_diagnostics_sha256"] = sha256(path)
    report["checks"].append({"name": "authoring_provenance_and_decoded_camera_motion_agree", "passed": True,
                              "envelope_peak_frame": 46, "both_sides_share_local_pattern": True,
                              "cameras": results})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=ROOT / "modified_v3")
    parser.add_argument("--modified", type=Path, default=ROOT / "modified_v4")
    parser.add_argument("--baseline-report", type=Path, default=ROOT / "outputs_v3/validation.json")
    parser.add_argument("--native-references", type=Path, default=ROOT / "work/v4/native_effect_references.json")
    parser.add_argument("--native-source", type=Path)
    parser.add_argument("--diagnostics", type=Path, default=ROOT / "work/v4/effects.json")
    parser.add_argument("--report", type=Path, default=ROOT / "outputs_v4/validation.json")
    args = parser.parse_args()
    report = {"revision": 4, "passed": False, "validation_scope": "offline visual bindings, preserved V3 assets and exported camera displacement",
              "baseline": str(args.baseline.resolve()), "modified": str(args.modified.resolve()), "checks": []}
    try:
        files = validate_baseline(args.baseline, args.baseline_report, args.modified, report)
        validate_skills(args.baseline, args.modified, report)
        validate_native(args.native_references, args.native_source, report)
        decoded_offsets = validate_cameras(args.baseline, args.modified, report)
        validate_diagnostics(args.diagnostics, args.baseline, args.baseline_report,
                             args.native_references, decoded_offsets, report)
        report["asset_sha256"] = {relative.as_posix(): sha256(path) for relative, path in sorted(files.items())}
        report["passed"] = True
    except Exception as error:
        report["error"] = str(error)
        report["traceback"] = traceback.format_exc()
    report["limits"] = ["Native particle assets are resolved by the installed game; this is not an engine particle render.",
                        "V3 hit timing remains after-animation (column11=1); exact VFX/combat synchronization is untested.",
                        "Camera tremor is authored near the landing; it does not deform the battle terrain."]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report}")
    if not report["passed"]:
        print(report["error"], file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
