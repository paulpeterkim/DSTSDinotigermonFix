"""Render the exported Highland PC camera on the unchanged V3 actor scene.

This shows actual camera translation/rotation/FOV. Native game particles are
not available to Blender and are deliberately not simulated in this preview.
"""
from pathlib import Path
import hashlib
import json
import math
import sys

import bpy
from mathutils import Quaternion, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from anim_codec import read, sample, sample_track

source = ROOT/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend'
bpy.ops.wm.open_mainfile(filepath=str(source))
scene = bpy.context.scene
arm = bpy.data.objects['chr424857']
arm.animation_data.action = bpy.data.actions['chr424857_bs02']
for track in arm.animation_data.nla_tracks:
    track.mute = True
camera_path = ROOT/'modified_v4/dsts-loader/patch/cam_chr424857_bs02_pc.anim'
clip = read(camera_path, expected_bones=2)
cam = scene.camera
cam.data.type = 'PERSP'
cam.rotation_mode = 'QUATERNION'
conversion = Quaternion((1., 0., 0.), math.pi/2)
scene.render.resolution_x = 640
scene.render.resolution_y = 480
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
out = ROOT/'work/v4/camera_preview'
out.mkdir(parents=True, exist_ok=True)
frames = list(range(28, 74))
for index, frame in enumerate(frames):
    scene.frame_set(frame+1)
    position, rotation, _ = sample(clip, 0, frame)
    cam.location = Vector((position[0], -position[2], position[1]))
    cam.rotation_quaternion = conversion @ Quaternion((rotation[3], *rotation[:3]))
    cam.data.angle = math.radians(float(sample_track(clip.float_channels[0], frame)))
    scene.render.filepath = str(out/f'{index:03d}.png')
    bpy.ops.render.render(write_still=True)
(out/'frames.json').write_text(json.dumps({
    'frames': frames, 'fps': clip.playback_rate,
    'source_scene_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'camera_sha256': hashlib.sha256(camera_path.read_bytes()).hexdigest(),
    'note': 'Exported PC camera with unchanged V3 actor; native particles are not rendered.'
}, indent=2)+'\n')
print('V4 actual-camera preview rendered:', len(frames), 'frames')
