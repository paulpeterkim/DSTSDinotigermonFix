# Dinotigermon: Ground Fang / Highland Fang — test build

This is an edited copy of the uploaded Dinotigermon_55057 v1.11.0 mod by dacare.
Original model, textures, skeleton, field animations, evolution data, and icons
are preserved. No GitHub changes were pushed.

## What changed

- **Ground Fang** (skill 5505710, bs01): low pounce, foreleg pinning pose,
  downward fang thrust, left/right tearing motion, then recovery.
- **Highland Fang** (skill 5505720, bs02): crouch, high leap, downward fang/head
  sweep, landing, then recovery.
- Both use the exact requested English names and descriptions in all 11 locale
  folders. These are English fallbacks, not new translations.
- Independent custom skill IDs keep vanilla SaberLeomon skills unchanged.
- Four player/enemy camera animations are reframed around the new movements.
- The old mane-projectile effect and unrelated Bird bonus/buff are removed.
  Original effect assets remain present but are no longer assigned.

## Install

1. Back up or move your existing Dinotigermon mod folder.
2. Extract Dinotigermon_Fang_Skills_TEST.zip into that mod folder. ModConfig.json
   and dsts-loader should sit at the same level, just as in the original ZIP.
3. Enable this replacement in Reloaded-II with the existing DSTS.ModLoader
   dependencies. Do not enable the original and edited copies together; they
   share a ModId and Digimon ID.
4. Check both skills in battle, including use by player/enemy Digimon and against
   differently sized enemies. Check names, damage, camera framing, and return to
   idle. Keep a backup: a future update of the original mod can replace edits.

## Scope and remaining game-side work

This build changes Dinotigermon's attacker animations, cameras, and skill data.
It does **not** animate or constrain a victim, add a gameplay immobilization
status, dismember enemy meshes, or add an instant-kill rule. Pinning is represented
by Dinotigermon's foreleg/body pose. Enemy reactions still use the game's existing
logic; actual contact depends on enemy size and battle positioning.

No game executable or base game battle/event assets were provided. This build
has not been loaded in the game. Damage/contact timing retains the original
engine setting (column 11 = 1, hit after the animation), so visual impact and
reaction synchronization need an in-game check. The supplied tool branch has
no enabled Blender animation export operator; the animations were encoded using
its Time Stranger/Hundred Line binary animation writer.

Ground Fang targets one enemy; Highland Fang retains the original second skill's
all-enemy scope. Both use the only complete skill row supplied in the archive as
the balance baseline: physical Null, power 55, SP 300, accuracy 100, one hit.
The original first skill (24241) was only a reference to missing vanilla data;
its original balance could not be reconstructed from this upload.

## Files for editing and review

- Dinotigermon_Fang_Attacks.blend: packed base texture, original rig, both authored
  actions, and a simple preview scene. Select armature chr424857 and action
  chr424857_bs01 or chr424857_bs02. Frame numbers in Blender start at 1.
- Ground_Fang.gif / Highland_Fang.gif: rendered attacker-motion previews.
  Materials approximate the base texture; game shaders/effects are not simulated.
- Dinotigermon_Fang_Skills_Source.zip: authoring scripts and validation reports.
- validation.json: typed CSV, reference, integrity, animation, and SHA-256 checks.
- clearance.json: every-frame head/fang-proxy floor-clearance diagnostics.

## Rebuild

Use Python 3 with numpy and Blender 4.3.2. Extract the untouched uploaded mod into
an `original` directory beside the `scripts` directory. Begin with no `modified`
directory; the patcher refuses to overwrite an existing output.

Use Romsstar/Blender-Tools-for-DSCS, feature/refactor, inspected commit
`dfcef08a33f67abd5b96f0f121902c27060b7c57`:
https://github.com/Romsstar/Blender-Tools-for-DSCS/tree/feature/refactor

Set DSCS_TOOLS_ROOT to that checkout's absolute path, then run from this folder:

```
python3 scripts/patch_skills.py --disable-highland-effect
python3 scripts/author_animations.py
python3 scripts/validate_mod.py
blender --background --python-exit-code 1 --python scripts/inspect_blender.py
blender --background --python-exit-code 1 --python scripts/render_preview.py
blender --background --python-exit-code 1 --python scripts/check_clearance.py
```

The optional Blender preview compatibility layer reads known mesh/skeleton
regions and leaves unsupported shader material bytes opaque. It never rewrites
GEOM files. Changing the Blender scene alone does not rebuild game animations;
edit author_animations.py and regenerate them with the binary writer.

## Validation completed

- Original uploaded ZIP CRC and extracted-file integrity verified.
- All 82 AP CSV tables (115 rows) parse with declared types and ranges.
- Both skills and all 11 locale name/description pairs resolve consistently.
- Both character clips retain 52 bones, original 56/57-frame durations and FPS;
  all four camera clips also retain their original timing and bone counts.
- All six animation files parse after writing, with finite transforms and unit
  quaternions; masks and retained channel metadata are checked on serialization.
- Source model, skeleton, textures, and unrelated assets remain byte-identical.
- Blender import/render succeeded; corrected head/fang poses clear the preview
  floor throughout both clips. No in-game compatibility claim is made.

Format reference: https://hyotan-dev.github.io/dstsworkshop/
