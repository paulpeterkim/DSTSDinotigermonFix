"""Change known effect color uniforms while preserving every other GEOM byte.

The upstream Time Stranger reader is used to locate shader uniforms, not to
rewrite the model. This works for the reference wind and quake GEOMs whose
complete parser roundtrips have been verified byte for byte.
"""
from __future__ import annotations

import importlib
import math
from pathlib import Path
import struct

from anim_codec import _load_tools, _PACKAGE


COLOR_UNIFORMS = {0x19: "diffuse_rgba", 0x12D: "secondary_rgb"}


def tint_effect_geom(source_path, destination_path, rgb):
    """Replace nonblack RGB uniform tints, preserving strength and alpha.

    ``rgb`` is the desired color with components in [0, 1]. The brightest
    component of each source uniform supplies its original intensity, including
    values above 1 used by the game's bright additive effect shaders. Black
    uniforms, textures, mesh data, skeletons, offsets, and all other fields stay
    byte-identical. Return a compact audit list of the changed uniform fields.
    """
    source = Path(source_path)
    destination = Path(destination_path)
    rgb = tuple(float(v) for v in rgb)
    if len(rgb) != 3 or not all(math.isfinite(v) and 0 <= v <= 1 for v in rgb):
        raise ValueError("Expected three finite color components in [0, 1]")
    if not any(rgb):
        raise ValueError("A nonblack tint is required")
    _load_tools()
    module = importlib.import_module(f"{_PACKAGE}.src.filetypes.Geom.Binary.TimeStranger")
    original_uniform = module.ShaderUniformHundredLine

    class LocatedUniform(original_uniform):
        def exbip_rw(self, rw):
            self.source_payload_offset = rw.tell()
            super().exbip_rw(rw)

    # The parser resolves its uniform class at read time. Restore it immediately
    # so this isolated locator does not change subsequent imports or exports.
    module.ShaderUniformHundredLine = LocatedUniform
    try:
        geom = module.GeomFileBinaryTimeStranger()
        geom.read(str(source))
    finally:
        module.ShaderUniformHundredLine = original_uniform

    original = source.read_bytes()
    output = bytearray(original)
    allowed_offsets = set()
    changes = []
    for material_index, material in enumerate(geom.materials):
        material_name = geom.get_string(
            geom.name_offsets.material_name_offsets[material_index]
        ).decode("utf8", errors="replace")
        for uniform in material.uniforms:
            if uniform.index not in COLOR_UNIFORMS:
                continue
            expected_count = 4 if uniform.index == 0x19 else 3
            if uniform.float_count != expected_count:
                raise ValueError(f"Unexpected color format on {material_name}")
            values = tuple(float(v) for v in uniform.unpack())
            if not all(math.isfinite(v) for v in values):
                raise ValueError(f"Nonfinite material color on {material_name}")
            strength = max(values[:3])
            if strength <= 0:
                continue
            after = tuple(strength * component for component in rgb)
            offset = uniform.source_payload_offset
            if original[offset:offset + 16] != uniform.payload:
                raise ValueError("Uniform payload does not match its source offset")
            replacement = struct.pack("<3f", *after)
            output[offset:offset + 12] = replacement
            allowed_offsets.update(range(offset, offset + 12))
            changes.append({
                "material": material_name,
                "material_index": material_index,
                "uniform": COLOR_UNIFORMS[uniform.index],
                "offset": offset,
                "before": list(values[:3]),
                "after": list(after),
            })
    changed_offsets = {i for i, (before, after) in enumerate(zip(original, output))
                       if before != after}
    if len(output) != len(original) or not changed_offsets <= allowed_offsets:
        raise AssertionError("Protected GEOM bytes changed")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(output)
    return changes
