"""Package the validated V8 game assets, provenance and exported-camera GIFs."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs_v8'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_zip(path, entries):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source, relative in entries:
            archive.write(source, relative)
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(entries):
            raise ValueError('ZIP integrity/inventory failure: '+str(path))
        for source, relative in entries:
            if hashlib.sha256(archive.read(relative)).hexdigest() != sha(source):
                raise ValueError('ZIP member changed: '+relative)


def camera_gif(stem, title, assets, audit):
    folder = ROOT/f'work/v8/camera_frames/{stem}_pc'
    if not (folder/'frames.json').exists():
        return
    from PIL import Image, ImageDraw, ImageFont
    data = json.loads((folder/'frames.json').read_text())
    for kind in ('camera', 'actor'):
        relative = ('dsts-loader/patch/'+(f'cam_chr424857_{stem}_pc.anim' if kind=='camera' else f'chr424857_{stem}.anim'))
        if data[kind+'_sha256'] != assets[relative]:
            raise ValueError('Stale camera preview '+kind)
    if data['source_scene_sha256'] != audit['source_scene_sha256']:
        raise ValueError('Preview/audit scene mismatch')
    if data['camera_diagnostics_sha256'] != sha(ROOT/'work/v8/cameras.json'):
        raise ValueError('Stale preview diagnostics')
    if data['frames'][-1] != (67 if stem=='bs01' else 47):
        raise ValueError('Preview misses active ending')
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 23)
    small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 12)
    frames = []
    for row in data['rendered_files']:
        path = folder/row['path']
        if sha(path) != row['sha256']:
            raise ValueError('Rendered frame changed')
        im = Image.open(path).convert('RGB')
        draw = ImageDraw.Draw(im)
        draw.rectangle((0, 0, 768, 44), fill='#202733')
        draw.text((14, 9), title+' V8 — earlier close-up', font=font, fill='#f2f3f7')
        draw.rectangle((0, 409, 768, 432), fill='#202733')
        draw.text((14, 414), 'Actual exported camera; native particles are not rendered.', font=small, fill='#e5be82')
        frames.append(im)
    palette_image = Image.new('RGB', (768, 432*5))
    for i, index in enumerate([0, len(frames)//4, len(frames)//2, 3*len(frames)//4, len(frames)-1]):
        palette_image.paste(frames[index], (0, 432*i))
    palette = palette_image.quantize(colors=256)
    frames = [im.quantize(palette=palette, dither=Image.Dither.NONE) for im in frames]
    stamps = [round((frame-data['frames'][0])/data['fps']*100)*10 for frame in data['frames']]
    ending = round((data['frames'][-1]+1)/data['fps']*100)*10
    durations = [b-a for a, b in zip(stamps, stamps[1:])]+[ending-stamps[-1]]
    frames[0].save(OUT/(title.replace(' ', '_')+'_Camera_V8.gif'), save_all=True,
                   append_images=frames[1:], duration=durations, loop=0, disposal=2, optimize=False)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    report = json.loads((OUT/'validation.json').read_text())
    assets = {path.relative_to(ROOT/'modified_v8').as_posix(): sha(path)
              for path in sorted((ROOT/'modified_v8').rglob('*')) if path.is_file()}
    if not report['passed'] or report['asset_sha256'] != assets:
        raise ValueError('Game asset inventory differs from successful validation')
    audit_path = ROOT/'work/v8/camera_framing_audit.json'
    audit = json.loads(audit_path.read_text())
    if not audit['passed'] or report['framing_audit_sha256'] != sha(audit_path):
        raise ValueError('Stale framing audit')
    if report['effect_authoring_report_sha256'] != sha(ROOT/'work/v8/effects.json'):
        raise ValueError('Stale effects diagnostics')
    for relative, expected in {**audit['actor_sha256'], **audit['camera_sha256']}.items():
        if assets[relative] != expected:
            raise ValueError('Audit asset mismatch: '+relative)
    shutil.copyfile(ROOT/'README_V8.md', OUT/'README_V8.md')
    for stem, title in [('bs01', 'Ground Fang'), ('bs02', 'Highland Fang')]:
        camera_gif(stem, title, assets, audit)
    checked_zip(OUT/'Dinotigermon_Fang_Skills_V8_TEST.zip',
                [(ROOT/'modified_v8'/relative, relative) for relative in assets]+
                [(OUT/'README_V8.md', 'README_Fang_Skills_V8.md')])
    scripts = ['author_cameras_v8.py', 'author_effects_v8.py', 'effect_bson.py', 'effect_materials.py',
               'audit_camera_v8.py', 'render_camera_v8.py', 'render_effect_check_v8.py',
               'validate_mod_v8.py', 'package_outputs_v8.py', 'author_cameras_v5.py',
               'revise_mod_v6.py', 'anim_codec.py', 'motion_math.py', 'geom_preview.py',
               'inspect_jaw_v3.py', 'patch_skills.py', 'validate_mod.py']
    relative_files = ['README_V8.md', 'outputs_v8/validation.json', 'outputs_v7/validation.json',
                      'outputs_v4/validation.json', 'work/v4/effects.json', 'work/v7/camera_framing_audit.json']
    relative_files += ['scripts/'+name for name in scripts]
    relative_files += ['work/v8/'+name for name in ['cameras.json', 'effects.json', 'face_selection.json',
                        'muzzle_selection.json', 'jaw_selection.json', 'camera_framing_audit.json']]
    relative_files += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'work/v8/effect_checks').glob('*.json'))]
    rebuild = ROOT/'work/v8/rebuild_check.json'
    if rebuild.exists():
        proof = json.loads(rebuild.read_text())
        if proof.get('passed') is not True or proof.get('rebuilt_asset_sha256') != assets:
            raise ValueError('Isolated rebuild proof is incomplete or stale')
        relative_files.append('work/v8/rebuild_check.json')
    checked_zip(OUT/'Dinotigermon_Fang_Skills_V8_Source.zip', [(ROOT/name, name) for name in relative_files])
    manifest = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
                for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256.json'}
    (OUT/'SHA256.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('V8 ZIP CRC and every packed game/source member hash verified.')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
