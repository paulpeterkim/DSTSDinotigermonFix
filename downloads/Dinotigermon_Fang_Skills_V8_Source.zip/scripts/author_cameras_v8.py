"""Push into Dinotigermon's muzzle earlier while retaining readable fang strikes.

Only the four camera animations are written. Actor clips and camera metadata
remain the accepted V7 data; PC and EM receive identical spatial camera tracks.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import numpy as np

from anim_codec import read, write, sample, sample_track, read_embedded_skeleton, slerp
from author_cameras_v5 import face_points, skinned_face, projected_bounds
from revise_mod_v6 import jaw_points, framed_view
from geom_preview import read_geom
from motion_math import fk, qrotate, normalize

ROOT = Path(__file__).resolve().parents[1]
ASPECT = 16/9
CLOSE_FOV = 36.
COUNTS = {'bs01': 68, 'bs02': 48}
PHASE_WINDOWS = {
    'bs01': {'opening': [0, 6], 'muzzle': [16, 31],
             'full_fang': [39, 52], 'final_jaw': [65, 67]},
    'bs02': {'opening': [0, 6], 'muzzle': [18, 34],
             'full_fang': [40, 47], 'final_jaw': []},
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(folder):
    return {p.relative_to(folder).as_posix(): sha(p)
            for p in sorted(folder.rglob('*')) if p.is_file()}


def eased(frame, start, end):
    t = min(1., max(0., (frame-start)/(end-start)))
    return t*t*t*(10+t*(-15+6*t))


def muzzle_subset(selection):
    """Retain eyes, muzzle and jaws; long fang tips may leave the early shot."""
    result = deepcopy(selection)
    for mesh in result['meshes']:
        keep = np.asarray(mesh['positions_game'])[:, 1] > .84
        mesh['vertex_indices'] = np.asarray(mesh['vertex_indices'])[keep].tolist()
        mesh['positions_game'] = np.asarray(mesh['positions_game'])[keep].tolist()
    result['selection_rule'] = 'V5 face vertices with neutral game-space Y > 0.84'
    return result


def phase(stem, frame):
    windows = PHASE_WINDOWS[stem]
    for name, limits in windows.items():
        if limits and limits[0] <= frame <= limits[1]:
            return name
    if frame < windows['muzzle'][0]:
        return 'push_to_muzzle'
    if frame < windows['full_fang'][0]:
        return 'reveal_full_fangs'
    return 'push_to_jaw'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT/'modified_v7')
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v8')
    parser.add_argument('--baseline-report', type=Path, default=ROOT/'outputs_v7/validation.json')
    parser.add_argument('--v4-effects', type=Path, default=ROOT/'work/v4/effects.json')
    parser.add_argument('--v4-report', type=Path, default=ROOT/'outputs_v4/validation.json')
    parser.add_argument('--output', type=Path, default=ROOT/'work/v8')
    args = parser.parse_args()
    baseline = json.loads(args.baseline_report.read_text())
    if not baseline['passed'] or inventory(args.source) != baseline['asset_sha256']:
        raise ValueError('Camera source differs from accepted V7')
    if not args.destination.is_dir():
        raise FileNotFoundError('Create the V8 working copy before authoring cameras')
    v4 = json.loads(args.v4_report.read_text())
    if sha(args.v4_effects) != v4['effects_diagnostics_sha256']:
        raise ValueError('Landing shake diagnostics differ from accepted V4')
    source_patch = args.source/'dsts-loader/patch'
    destination_patch = args.destination/'dsts-loader/patch'
    protected = ['chr424857.geom', 'chr424857_bs01.anim', 'chr424857_bs02.anim']
    for name in protected:
        if sha(source_patch/name) != sha(destination_patch/name):
            raise ValueError('V8 actor or geometry differs from V7: '+name)
    skeleton = read_embedded_skeleton(source_patch/'chr424857.geom')
    geom = read_geom(source_patch/'chr424857.geom')
    face_bindings, face_count, face_selection = face_points(geom, skeleton)
    jaw_bindings, jaw_count, jaw_selection = jaw_points(geom, skeleton)
    bind_points = np.concatenate([np.asarray(m['positions_game']) for m in face_selection['meshes']])
    muzzle_mask = bind_points[:, 1] > .84
    muzzle_selection = muzzle_subset(face_selection)
    args.output.mkdir(parents=True, exist_ok=True)
    selections = {'face': face_selection, 'muzzle': muzzle_selection, 'jaw': jaw_selection}
    for name, selection in selections.items():
        selection['geometry_sha256'] = sha(source_patch/'chr424857.geom')
        (args.output/f'{name}_selection.json').write_text(json.dumps(selection, indent=2)+'\n')
    shake = {Path(c['path']).name: {s['frame']: np.array(s['local_offset']) for s in c['samples']}
             for c in json.loads(args.v4_effects.read_text())['shake']['cameras']}
    cameras, actors = [], []
    for stem, count in COUNTS.items():
        actor_path = source_patch/f'chr424857_{stem}.anim'
        actor = read(actor_path, expected_bones=52)
        if actor._source_frame_count != count:
            raise ValueError('Source actor has an unexpected duration')
        poses = []
        for frame in range(count):
            transforms = [sample(actor, bone, frame) for bone in range(52)]
            poses.append(fk(skeleton, np.array([t[0] for t in transforms]),
                            np.array([t[1] for t in transforms])))
        forward = poses[-1][0][2]-poses[0][0][2]
        forward[1] = 0.
        forward = normalize(forward)
        actors.append({'path': 'dsts-loader/patch/'+actor_path.name,
                       'frames': count, 'fps': actor.playback_rate,
                       'source_sha256': sha(actor_path),
                       'modified_sha256': sha(destination_patch/actor_path.name)})
        # Derive one canonical spatial path. Each side retains its own metadata.
        canonical_path = source_patch/f'cam_chr424857_{stem}_pc.anim'
        canonical = read(canonical_path, expected_bones=2)
        rows, authored = [], []
        previous = None
        for frame, (wp, wq) in enumerate(poses):
            face = skinned_face(face_bindings, face_count, wp, wq)
            muzzle = face[muzzle_mask]
            jaw = skinned_face(jaw_bindings, jaw_count, wp, wq)
            bp, bq, _ = sample(canonical, 0, frame)
            bfov = float(sample_track(canonical.float_channels[0], frame))
            opening_zoom = eased(frame, 6, PHASE_WINDOWS[stem]['muzzle'][0])
            full_fang = eased(frame, PHASE_WINDOWS[stem]['muzzle'][1],
                              PHASE_WINDOWS[stem]['full_fang'][0])
            jaw_zoom = eased(frame, 52, 67) if stem == 'bs01' else 0.
            elevation = max(-.32, .20+.75*min(0., float(qrotate(wq[6], [0., 0., 1.])[1])))
            mp, mq, mt, md = framed_view(muzzle, -9., elevation, CLOSE_FOV,
                                         width=.86, height=.84, minimum=1.3)
            fp, fq, ft, fd = framed_view(face, -9., elevation, CLOSE_FOV,
                                         width=.86, height=.84, minimum=1.3)
            closep = mp*(1-full_fang)+fp*full_fang
            closeq = slerp(mq, fq, full_fang)
            fov = CLOSE_FOV
            if jaw_zoom:
                jp, jq, _, _ = framed_view(jaw, -7.5, .08, 38.,
                                           width=.82, height=.68, minimum=1.)
                closep = closep*(1-jaw_zoom)+jp*jaw_zoom
                closeq = slerp(closeq, jq, jaw_zoom)
                fov = fov*(1-jaw_zoom)+38.*jaw_zoom
            local_shake = (shake[canonical_path.name][frame] if stem == 'bs02' else np.zeros(3))
            rotation = slerp(bq, closeq, opening_zoom)
            position = ((bp-qrotate(bq, local_shake))*(1-opening_zoom)
                        +closep*opening_zoom+qrotate(rotation, local_shake))
            fov = bfov*(1-opening_zoom)+fov*opening_zoom
            if frame <= 6:
                # Preserve opening keys verbatim, including quaternion signs.
                position, rotation, fov = bp, bq, bfov
            elif previous is not None and np.dot(previous, rotation) < 0:
                rotation = -rotation
            previous = rotation
            authored.append((position, rotation, fov))
            rows.append({'frame': frame, 'focus_region': phase(stem, frame),
                         'opening_zoom': opening_zoom, 'full_fang_blend': full_fang,
                         'jaw_zoom': jaw_zoom, 'fov': fov,
                         'muzzle_target': mt.tolist(), 'muzzle_distance': md,
                         'face_target': ft.tolist(), 'face_distance': fd,
                         'local_shake': local_shake.tolist(),
                         'baseline_face_bounds': projected_bounds(face, bp, bq, bfov)})
        for side in ('pc', 'em'):
            name = f'cam_chr424857_{stem}_{side}.anim'
            original = read(source_patch/name, expected_bones=2)
            camera = deepcopy(original)
            if original._source_frame_count != count:
                raise ValueError('Camera length does not match the active actor')
            for frame, (position, rotation, fov) in enumerate(authored):
                if frame > 6:
                    camera.positions[0][frame] = position.tolist()
                    camera.rotations[0][frame] = rotation.tolist()
                    camera.float_channels[0][frame] = fov
            rebuilt = write(camera, destination_patch/name,
                            preserve_duration=True, expected_bones=2)
            samples = deepcopy(rows)
            for frame, (wp, wq) in enumerate(poses):
                p, q, _ = sample(rebuilt, 0, frame)
                fov = float(sample_track(rebuilt.float_channels[0], frame))
                face = skinned_face(face_bindings, face_count, wp, wq)
                jaw = skinned_face(jaw_bindings, jaw_count, wp, wq)
                samples[frame].update({
                    'fov': fov,
                    'screen_forward_dot': float(np.dot(forward, qrotate(q, [1., 0., 0.]))),
                    'face_bounds': projected_bounds(face, p, q, fov),
                    'muzzle_bounds': projected_bounds(face[muzzle_mask], p, q, fov),
                    'jaw_bounds': projected_bounds(jaw, p, q, fov)})
            cameras.append({'path': 'dsts-loader/patch/'+name, 'stem': stem, 'side': side,
                            'frames': count, 'fps': rebuilt.playback_rate,
                            'duration': rebuilt._source_duration,
                            'source_sha256': sha(source_patch/name),
                            'modified_sha256': sha(destination_patch/name),
                            'phase_windows': PHASE_WINDOWS[stem], 'samples': samples})
            print(name, 'earlier muzzle close-up authored;', count, 'active frames', flush=True)
    report = {'revision': 8, 'source_asset_sha256': baseline['asset_sha256'],
              'baseline_report_sha256': sha(args.baseline_report),
              'geometry_sha256': sha(source_patch/'chr424857.geom'),
              **{name+'_selection_sha256': sha(args.output/f'{name}_selection.json') for name in selections},
              'v4_shake_sha256': sha(args.v4_effects), 'v4_validation_sha256': sha(args.v4_report),
              'aspect_ratio': ASPECT, 'close_fov_degrees': CLOSE_FOV,
              'close_yaw_degrees': -9., 'phase_windows': PHASE_WINDOWS,
              'actors': actors, 'cameras': cameras,
              'notes': ['Opening frames 0 through 6 and all actor motion retain V7 data.',
                        'Early muzzle shots intentionally crop the long fang tips to reduce visible legs.',
                        'The full fang silhouette is restored for the strike; Ground ends on its jaw.',
                        'PC and EM spatial paths match while each retains its own original metadata.',
                        'Highland retains the accepted camera-local landing shake.']}
    (args.output/'cameras.json').write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
