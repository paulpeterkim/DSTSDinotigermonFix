"""Bind complete, silent local main effects and synchronize their real tracks.

Reference assets are read as data. No reference gameplay/model configuration is
imported. The source effect's 512 Hz transforms and material float channels are
retimed together; BSON's undocumented delay fields are deliberately preserved.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np

from anim_codec import read, write, sample, read_embedded_skeleton
from effect_bson import patch, remove_objects, Document
from effect_materials import tint_effect_geom
from motion_math import fk
from patch_skills import read_csv, write_csv, SKILL_TABLE

ROOT = Path(__file__).resolve().parents[1]
EFFECT_TABLE = Path('dsts-loader/patch/data/battle_effect.mbe/000_battle_effect_list.ap.csv')
GHOST_CLAWS = [2, 5, 7, 9, 11, 13, 15, 16, 17, 18]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def smooth(value):
    t = np.clip(value, 0., 1.)
    return t*t*(3.-2.*t)


def sampled(track, frames, quaternion=False):
    """Vectorized linear/shortest-path SLERP sampling; empty tracks stay empty."""
    keys = np.array(sorted(track), dtype=float)
    values = np.array([track[int(k)] for k in keys], dtype=float)
    if len(keys) == 1:
        return np.repeat(values, len(frames), axis=0)
    if not quaternion:
        if values.ndim == 1:
            return np.interp(frames, keys, values)
        return np.column_stack([np.interp(frames, keys, values[:, c]) for c in range(values.shape[1])])
    right = np.clip(np.searchsorted(keys, frames, side='right'), 1, len(keys)-1)
    left = right-1
    weight = np.clip((frames-keys[left])/(keys[right]-keys[left]), 0., 1.)
    a, b = values[left].copy(), values[right].copy()
    a /= np.linalg.norm(a, axis=1)[:, None]
    b /= np.linalg.norm(b, axis=1)[:, None]
    dot = np.sum(a*b, axis=1)
    b[dot < 0] *= -1
    dot = np.clip(np.abs(dot), 0., 1.)
    angle = np.arccos(dot)
    result = a*(1.-weight[:, None])+b*weight[:, None]
    curved = dot < .9995
    t, theta = weight[curved], angle[curved]
    result[curved] = (a[curved]*np.sin((1.-t)*theta)[:, None]+
                      b[curved]*np.sin(t*theta)[:, None])/np.sin(theta)[:, None]
    return result/np.linalg.norm(result, axis=1)[:, None]


def retime(source, times, knots):
    anim = deepcopy(source)
    source_frames = np.interp(times, np.array(knots)[:, 0], np.array(knots)[:, 1])*source.playback_rate
    for kind in ('positions', 'rotations', 'scales', 'float_channels'):
        channels = {}
        for bone, track in getattr(source, kind).items():
            if not track:
                channels[bone] = {}
                continue
            values = sampled(track, source_frames, quaternion=kind == 'rotations')
            # Retain constants without inflating every source rest channel.
            indices = [0] if np.max(np.abs(values-values[0])) < 1e-12 else range(len(times))
            channels[bone] = {f: values[f].tolist() for f in indices}
        setattr(anim, kind, channels)
    return anim


def actor_head_positions(destination, stem):
    directory = destination/'dsts-loader/patch'
    actor = read(directory/f'chr424857_{stem}.anim')
    skeleton = read_embedded_skeleton(directory/'chr424857.geom')
    heads = []
    for frame in range(actor._source_frame_count):
        transforms = [sample(actor, bone, frame) for bone in range(actor.bone_count)]
        p, _ = fk(skeleton, np.array([t[0] for t in transforms]), np.array([t[1] for t in transforms]))
        heads.append(p[6])
    return actor, np.array(heads)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference', type=Path, default=Path('/workspace/reference_kumamon'))
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v8')
    parser.add_argument('--reference-zip', type=Path, default=Path('/workspace/attachments/95f5236a-48a8-4297-bb7b-145cb6ec34e3/KumamonKorikakumon_55047.zip'))
    args = parser.parse_args()
    reference = args.reference/'dsts-loader/patch'
    destination = args.destination/'dsts-loader/patch'
    report = {'revision': 8, 'reference_zip_sha256': sha(args.reference_zip), 'effects': [],
              'limits': ['Game runtime and native shader output require an in-game check.',
                         'Only active custom effect audio is muted; no global voice/audio table is changed.']}
    settings = [
        {'stem': 'bs01', 'skill_id': '5505710', 'effect_id': '5505781',
         'source': 'ef_b_ch5548_bs02', 'name': 'ef_b_dt5057_ground_v8',
         'rgb': [1., .96, .84], 'scale': .23, 'gate': [1.20, 1.34],
         'release_gate': [2.0, 65/30],
         'knots': [[0., 0.], [1.20, 1.], [1.35, 1.04], [1.70, 1.15]],
         'source_end': 1.30, 'images': ['ki4820000000', 'ki4820000001']},
        {'stem': 'bs02', 'skill_id': '5505720', 'effect_id': '5505782',
         'source': 'ef_b_ch5548_bs01', 'name': 'ef_b_dt5057_highland_v8',
         'rgb': [.85, .72, .50], 'scale': .25, 'gate': [1.27, 1.34],
         'knots': [[0., 0.], [1.27, 1.65], [1.30, 1.70], [1.40, 1.80], [1.47, 2.05]],
         'source_end': 2.30, 'images': [f'ki481000000{i}' for i in range(6)]},
    ]
    for config in settings:
        print('Authoring '+config['name'], flush=True)
        source_path = reference/config['source']
        output_path = destination/config['name']
        actor, heads = actor_head_positions(args.destination, config['stem'])
        source = read(source_path.with_suffix('.anim'))
        count = round(actor._source_duration*source.playback_rate)+1
        times = np.arange(count)/source.playback_rate
        knots = config['knots']+[[float(times[-1]), config['source_end']]]
        anim = retime(source, times, knots)
        gate = smooth((times-config['gate'][0])/(config['gate'][1]-config['gate'][0]))
        if 'release_gate' in config:
            release = config['release_gate']
            gate *= 1.-smooth((times-release[0])/(release[1]-release[0]))
        if config['stem'] == 'bs01':
            # The supplied claw effect contains ghost hand models; suppress only
            # their ten independent mesh bones, retaining wind ribbons/debris.
            for bone in GHOST_CLAWS:
                anim.scales[bone] = {0: [0., 0., 0.]}
            actor_frames = times*actor.playback_rate
            head_positions = np.column_stack([np.interp(actor_frames, np.arange(len(heads)), heads[:, c]) for c in range(3)])
            positions = head_positions-config['scale']*np.array([0., 2.25, .93])+np.array([.4, -.35, .10])
            placement = {'kind': 'follow_actor_head', 'actor_bone': 6,
                         'effect_center_game': [0., 2.25, .93], 'offset_game': [.4, -.35, .10],
                         'sampling': 'linear interpolation of decoded actor integer-frame world joint positions'}
        else:
            positions = np.repeat([[-.33, 0., 4.26]], count, axis=0)
            placement = {'kind': 'constant', 'position_game': [-.33, 0., 4.26],
                         'purpose': 'center the expanding ground ring under the final forepaw plant'}
        anim.positions[0] = {f: p.tolist() for f, p in enumerate(positions)}
        anim.scales[0] = {f: [float(config['scale']*g)]*3 for f, g in enumerate(gate)}
        rebuilt = write(anim, output_path.with_suffix('.anim'), preserve_duration=False)
        raw = source_path.with_suffix('.bson').read_bytes()
        removal = None
        if config['stem'] == 'bs01':
            raw, removal = remove_objects(raw, ['sg/snow_set'])
        raw, bson_report = patch(raw, model_renames={config['source']: config['name']}, mute_sound=True)
        output_path.with_suffix('.bson').write_bytes(raw)
        colors = tint_effect_geom(source_path.with_suffix('.geom'), output_path.with_suffix('.geom'), config['rgb'])
        shutil.copyfile(source_path.with_suffix('.nlst'), output_path.with_suffix('.nlst'))
        image_hashes = {}
        for image in config['images']:
            relative = Path('images')/(image+'.img')
            (destination/relative).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(reference/relative, destination/relative)
            image_hashes[str(relative)] = sha(destination/relative)
        row = dict(config)
        row.update({'time_map_target_seconds_to_source_seconds': knots,
                    'fps': rebuilt.playback_rate, 'frames': rebuilt._source_frame_count,
                    'duration_seconds': rebuilt._source_duration, 'actor_duration_seconds': actor._source_duration,
                    'root_placement': placement, 'hidden_mesh_bones': GHOST_CLAWS if config['stem']=='bs01' else [],
                    'bson_patch': bson_report, 'bson_removed_objects': removal, 'material_uniforms': colors,
                    'source_sha256': {ext: sha(source_path.with_suffix('.'+ext)) for ext in ['bson', 'geom', 'anim', 'nlst']},
                    'output_sha256': {ext: sha(output_path.with_suffix('.'+ext)) for ext in ['bson', 'geom', 'anim', 'nlst']},
                    'image_sha256': image_hashes,
                    'sound_volumes': [n.value for n in Document(raw).scalars('se_volume')]})
        report['effects'].append(row)
    header, skills = read_csv(args.destination/SKILL_TABLE)
    header_effects, effects = read_csv(args.destination/EFFECT_TABLE)
    effects = [row for row in effects if row[0] not in {c['effect_id'] for c in settings}]
    for config in settings:
        skill = next(row for row in skills if row[0] == config['skill_id'])
        skill[12], skill[14], skill[16] = config['effect_id'], '0', '0'
        effects.append([config['effect_id'], '', '', '', config['name'], '1', '', '3', '0', '1', '0', '-1', '-1', 'false', ''])
    write_csv(args.destination/SKILL_TABLE, header, skills)
    write_csv(args.destination/EFFECT_TABLE, header_effects, effects)
    out = ROOT/'work/v8/effects.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2)+'\n')
    print('Main effects bound; later full-effect slots cleared; active effect audio muted.', flush=True)


if __name__ == '__main__':
    main()
