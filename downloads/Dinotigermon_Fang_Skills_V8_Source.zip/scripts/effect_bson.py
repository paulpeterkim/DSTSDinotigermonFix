"""Strict, byte-preserving reader/patcher for DSTS effect BSON version 10.

This is the game's custom TLV format, not MongoDB BSON. Scalar patches preserve
object boundaries/order and existing strings. Explicit object removals preserve
every surviving subtree except the size/count fields of its ancestors. A longer
model name can be appended to the string table without relocating any existing
string or changing an object size.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import struct
from typing import Any


@dataclass(frozen=True)
class Node:
    kind: int
    key: str
    path: tuple[str, ...]
    offset: int
    size: int
    value: Any
    children: tuple['Node', ...] = ()

    @property
    def value_offset(self):
        if self.kind == 1:
            raise ValueError('Objects have no scalar payload')
        return self.offset+8


class Document:
    """Parse the entire known container and reject ambiguous/truncated layouts."""
    def __init__(self, raw: bytes):
        self.raw = bytes(raw)
        if len(raw) < 28 or raw[:4] != b'BSON':
            raise ValueError('Not a DSTS effect BSON')
        self.version = struct.unpack_from('<I', raw, 4)[0]
        if self.version != 10:
            raise ValueError(f'Unsupported BSON version {self.version}')
        kind, root_size = struct.unpack_from('<HH', raw, 8)
        if kind != 1 or root_size < 16:
            raise ValueError('Expected one root object at offset8')
        self.string_header_offset = 8+root_size
        if self.string_header_offset+8 > len(raw):
            raise ValueError('Root overlaps or omits the string table')
        tag, length = struct.unpack_from('<HH', raw, self.string_header_offset)
        if tag != 0x20:
            raise ValueError('Expected string-table tag0x20 immediately after root')
        self.string_offset = self.string_header_offset+4
        self.string_data = raw[self.string_offset:self.string_offset+length]
        if self.string_offset+length+4 != len(raw) or raw[-4:] != b'\x03\0\x04\0':
            raise ValueError('String-table length or final terminator is invalid')
        self.nodes: list[Node] = []
        self.root = self._parse(8, ())
        if self.root.offset+self.root.size != self.string_header_offset:
            raise ValueError('Root end does not match the declared string table')
        self.by_path = {}
        for node in self.nodes:
            if node.path in self.by_path:
                raise ValueError('Duplicate node path is not supported for patching')
            self.by_path[node.path] = node

    @classmethod
    def read(cls, path):
        return cls(Path(path).read_bytes())

    def string(self, offset):
        if not 0 <= offset < len(self.string_data):
            raise ValueError(f'String reference outside table: {offset}')
        end = self.string_data.find(b'\0', offset)
        if end < 0:
            raise ValueError('String reference has no terminator')
        return self.string_data[offset:end].decode('utf-8')

    def _parse(self, offset, parent):
        if offset+8 > self.string_header_offset:
            raise ValueError('Node header extends beyond root')
        kind, size, key_offset = struct.unpack_from('<HHI', self.raw, offset)
        if size < 12 or offset+size > self.string_header_offset:
            raise ValueError('Invalid BSON node bounds')
        key = self.string(key_offset); path = parent+(key,)
        if kind == 1:
            count = struct.unpack_from('<I', self.raw, offset+8)[0]
            children = []; cursor = offset+12
            while cursor < offset+size-4:
                child = self._parse(cursor, path)
                children.append(child); cursor += child.size
            if len(children) != count or cursor != offset+size-4 or self.raw[cursor:cursor+4] != b'\x03\0\x04\0':
                raise ValueError(f'Object count/end mismatch at {path}')
            node = Node(kind, key, path, offset, size, count, tuple(children))
        elif kind in (0x10, 0x11, 0x14):
            if size != 12:
                raise ValueError('Known scalar has an unexpected width')
            if kind == 0x10:
                value = struct.unpack_from('<i', self.raw, offset+8)[0]
            elif kind == 0x11:
                value = struct.unpack_from('<f', self.raw, offset+8)[0]
                if not math.isfinite(value):
                    raise ValueError('Non-finite BSON float')
            else:
                value = self.string(struct.unpack_from('<I', self.raw, offset+8)[0])
            node = Node(kind, key, path, offset, size, value)
        else:
            raise ValueError(f'Unknown BSON node kind {kind:#x} at {offset:#x}')
        self.nodes.append(node)
        return node

    def scalars(self, key=None):
        return [n for n in self.nodes if n.kind != 1 and (key is None or n.key == key)]

    def summary(self):
        return {'version': self.version, 'bytes': len(self.raw),
                'sha256': hashlib.sha256(self.raw).hexdigest(),
                'root_bytes': self.root.size, 'strings_bytes': len(self.string_data),
                'nodes': [{'path': '/'.join(n.path), 'kind': n.kind,
                           'offset': n.offset, 'value': n.value}
                          for n in self.scalars()]}


def remove_objects(raw: bytes, paths):
    """Remove explicitly selected complete subtrees, preserving all other data.

    The format stores no object byte offsets: all references point into the
    trailing string table. A removed object therefore needs only its ancestors'
    uint16 sizes and direct parents' uint32 child counts updated. String-table
    bytes and offsets remain unchanged, including now-unused strings. Callers
    must establish that the selected object is semantically independent; this
    function verifies the container structure and byte preservation only.
    """
    document = Document(raw)
    selected = set()
    for path in paths:
        key = tuple(path.strip('/').split('/')) if isinstance(path, str) else tuple(path)
        node = document.by_path.get(key)
        if node is None or node.kind != 1:
            raise ValueError(f'No existing object at path {key}')
        if node is document.root:
            raise ValueError('The root object cannot be removed')
        selected.add(key)
    for path in selected:
        if any(path[:len(other)] == other for other in selected if other != path):
            raise ValueError('Nested object removals are ambiguous; select the ancestor only')

    removed_paths = {n.path for n in document.nodes
                     if any(n.path[:len(path)] == path for path in selected)}
    ancestors = {n.path for n in document.nodes
                 if n.kind == 1 and n.path not in removed_paths
                 and any(path[:len(n.path)] == n.path for path in selected)}
    ancestor_updates = []

    def rebuild(node):
        if node.path in selected:
            return b''
        if node.path not in ancestors:
            return raw[node.offset:node.offset+node.size]
        children = [child for child in node.children if child.path not in selected]
        body = b''.join(rebuild(child) for child in children)
        size = 12+len(body)+4
        header = bytearray(raw[node.offset:node.offset+12])
        struct.pack_into('<H', header, 2, size)
        struct.pack_into('<I', header, 8, len(children))
        ancestor_updates.append({'path': '/'.join(node.path), 'old_size': node.size,
                                 'new_size': size, 'old_child_count': node.value,
                                 'new_child_count': len(children)})
        return bytes(header)+body+raw[node.offset+node.size-4:node.offset+node.size]

    result = raw[:8]+rebuild(document.root)+raw[document.string_header_offset:]
    rebuilt = Document(result)
    if set(rebuilt.by_path) != set(document.by_path)-removed_paths:
        raise ValueError('Removal changed unexpected nodes')
    if result[rebuilt.string_header_offset:] != raw[document.string_header_offset:]:
        raise ValueError('Removal changed the original string table or trailing bytes')
    for path, node in rebuilt.by_path.items():
        original = document.by_path[path]
        if node.kind != original.kind or node.key != original.key:
            raise ValueError('Removal changed a surviving node type/name')
        if path not in ancestors:
            if result[node.offset:node.offset+node.size] != raw[original.offset:original.offset+original.size]:
                raise ValueError('Removal changed a surviving subtree')
        elif [c.path for c in node.children] != [c.path for c in original.children if c.path not in selected]:
            raise ValueError('Removal changed unexpected object children')
    report = {'source_sha256': hashlib.sha256(raw).hexdigest(),
              'patched_sha256': hashlib.sha256(result).hexdigest(),
              'source_bytes': len(raw), 'patched_bytes': len(result),
              'removed_objects': [{'path': '/'.join(path),
                                   'original_range': [document.by_path[path].offset,
                                                      document.by_path[path].offset+document.by_path[path].size],
                                   'subtree_node_count': sum(n.path[:len(path)] == path for n in document.nodes)}
                                  for path in sorted(selected)],
              'ancestor_updates': ancestor_updates,
              'surviving_subtrees_byte_identical': True,
              'original_string_table_byte_identical': True}
    return result, report


def patch(raw: bytes, *, changes=None, model_renames=None, mute_sound=False):
    """Return (patched_bytes, report), changing only explicitly selected scalars.

    ``changes`` maps exact slash-separated paths or path tuples to scalar values.
    ``model_renames`` maps emitter ``dn`` model basenames to new resource names.
    ``mute_sound`` writes zero to each explicitly named ``se_volume`` field,
    preserving its original int32/float32 type. It does not alter global audio.
    """
    document = Document(raw)
    updates = {}
    for path, value in (changes or {}).items():
        key = tuple(path.strip('/').split('/')) if isinstance(path, str) else tuple(path)
        if key not in document.by_path or document.by_path[key].kind == 1:
            raise ValueError(f'No existing scalar at path {key}')
        updates[key] = value
    found_models = set()
    for node in document.scalars():
        if node.key == 'dn' and node.path[-2].startswith('emitter') and node.value in (model_renames or {}):
            updates[node.path] = model_renames[node.value]; found_models.add(node.value)
        if mute_sound and node.key == 'se_volume':
            if node.kind not in (0x10, 0x11):
                raise ValueError('Unexpected sound-volume scalar type')
            updates[node.path] = 0 if node.kind == 0x10 else 0.
    if found_models != set(model_renames or {}):
        raise ValueError('One or more requested model names were not emitter dn fields')
    prefix = bytearray(raw[:document.string_header_offset])
    strings = bytearray(document.string_data)
    offsets = {}; cursor = 0
    while cursor < len(strings):
        end = strings.find(b'\0', cursor)
        if end < 0:
            raise ValueError('Malformed original string table')
        offsets.setdefault(bytes(strings[cursor:end]).decode('utf-8'), cursor)
        cursor = end+1
    mutations = []
    allowed = set()
    for path, value in updates.items():
        node = document.by_path[path]
        if node.kind == 0x10:
            if not isinstance(value, int) or isinstance(value, bool):
                raise ValueError('int32 field requires an integer value')
            encoded = struct.pack('<i', value)
        elif node.kind == 0x11:
            if not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError('float32 field requires a finite numeric value')
            encoded = struct.pack('<f', value)
        elif node.kind == 0x14:
            if not isinstance(value, str) or '\0' in value:
                raise ValueError('String fields require a string without embedded NUL')
            if value not in offsets:
                offsets[value] = len(strings)
                strings.extend(value.encode('utf-8')+b'\0')
            encoded = struct.pack('<I', offsets[value])
        else:
            raise ValueError('Refusing to patch an unsupported scalar type')
        start = node.value_offset
        prefix[start:start+4] = encoded
        allowed.update(range(start, start+4))
        mutations.append({'path': '/'.join(path), 'kind': node.kind, 'payload_range': [start, start+4],
                          'old_value': node.value, 'requested_value': value})
    if len(strings) > 65535:
        raise ValueError('Updated string table exceeds the format uint16 capacity')
    patched = bytes(prefix)+struct.pack('<HH', 0x20, len(strings))+bytes(strings)+raw[-4:]
    rebuilt = Document(patched)
    if len(rebuilt.nodes) != len(document.nodes):
        raise ValueError('Patching changed the node inventory')
    changed_bytes = [i for i in range(len(prefix)) if raw[i] != patched[i]]
    if any(i not in allowed for i in changed_bytes):
        raise ValueError('Patching changed protected object bytes')
    if rebuilt.string_data[:len(document.string_data)] != document.string_data:
        raise ValueError('Patching changed existing string bytes')
    for node in document.nodes:
        new = rebuilt.by_path[node.path]
        if (new.kind, new.offset, new.size) != (node.kind, node.offset, node.size):
            raise ValueError('Patching changed node type/bounds')
        if node.path not in updates and new.value != node.value:
            raise ValueError('Patching changed an unselected value')
    for mutation in mutations:
        mutation['new_value'] = rebuilt.by_path[tuple(mutation['path'].split('/'))].value
    report = {'source_sha256': hashlib.sha256(raw).hexdigest(),
              'patched_sha256': hashlib.sha256(patched).hexdigest(),
              'source_bytes': len(raw), 'patched_bytes': len(patched),
              'changed_object_byte_count': len(changed_bytes),
              'existing_object_layout_unchanged': True, 'existing_strings_unchanged': True,
              'appended_string_bytes': len(strings)-len(document.string_data),
              'mutations': mutations,
              'sound_volume_fields_muted': sum(n.key == 'se_volume' for n in document.scalars()) if mute_sound else 0}
    return patched, report


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    result = Document.read(args.file).summary()
    output = json.dumps(result, indent=2)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output+'\n')
    else:
        print(output)
