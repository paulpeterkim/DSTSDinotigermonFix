"""Render the exported V8 camera on the unchanged canonical V3 actor scene."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import sys

import bpy
from mathutils import Quaternion, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from anim_codec import read, sample, sample_track


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


arguments = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('stem', choices=['bs01', 'bs02'])
parser.add_argument('--side', choices=['pc', 'em'], default='pc')
parser.add_argument('--keyposes', action='store_true')
parser.add_argument('--step', type=int, default=2)
args = parser.parse_args(arguments)
if args.step < 1:
    raise ValueError('Frame step must be positive')
source = ROOT/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend'
diagnostics_path = ROOT/'work/v8/cameras.json'
diagnostics = json.loads(diagnostics_path.read_text())
relative_camera = f'dsts-loader/patch/cam_chr424857_{args.stem}_{args.side}.anim'
camera_path = ROOT/'modified_v8'/relative_camera
actor_path = ROOT/f'modified_v8/dsts-loader/patch/chr424857_{args.stem}.anim'
camera_record = next(row for row in diagnostics['cameras'] if row['path'] == relative_camera)
actor_record = next(row for row in diagnostics['actors'] if Path(row['path']).name == actor_path.name)
if digest(camera_path) != camera_record['modified_sha256']:
    raise ValueError('Exported camera differs from V8 author diagnostics')
if digest(actor_path) != actor_record['modified_sha256'] or actor_record['source_sha256'] != actor_record['modified_sha256']:
    raise ValueError('Preview actor differs from the unchanged V7 actor')
v7_audit = json.loads((ROOT/'work/v7/camera_framing_audit.json').read_text())
if digest(source) != v7_audit['source_scene_sha256']:
    raise ValueError('Canonical actor scene differs from the accepted V7 preview source')
bpy.ops.wm.open_mainfile(filepath=str(source))
scene = bpy.context.scene
arm = bpy.data.objects['chr424857']
arm.animation_data.action = bpy.data.actions['chr424857_'+args.stem]
for track in arm.animation_data.nla_tracks:
    track.mute = True
clip = read(camera_path, expected_bones=2)
cam = scene.camera
cam.data.type = 'PERSP'
cam.data.sensor_fit = 'HORIZONTAL'
cam.data.shift_x = cam.data.shift_y = 0.
cam.rotation_mode = 'QUATERNION'
conversion = Quaternion((1., 0., 0.), math.pi/2)
scene.render.resolution_x = 768
scene.render.resolution_y = 432
scene.render.resolution_percentage = 100
scene.render.pixel_aspect_x = scene.render.pixel_aspect_y = 1.
scene.render.image_settings.file_format = 'PNG'
if args.keyposes:
    out = ROOT/'work/v8/keyposes'
    frames = ([0, 6, 10, 16, 24, 31, 39, 44, 52, 59, 65, 67]
              if args.stem == 'bs01' else [0, 6, 12, 18, 24, 34, 40, 42, 46, 47])
else:
    out = ROOT/f'work/v8/camera_frames/{args.stem}_{args.side}'
    frames = list(range(0, clip._source_frame_count, args.step))
    if frames[-1] != clip._source_frame_count-1:
        frames.append(clip._source_frame_count-1)
out.mkdir(parents=True, exist_ok=True)
rendered = []
for index, frame in enumerate(frames):
    scene.frame_set(frame+1)
    position, rotation, _ = sample(clip, 0, frame)
    cam.location = Vector((position[0], -position[2], position[1]))
    cam.rotation_quaternion = conversion @ Quaternion((rotation[3], *rotation[:3]))
    cam.data.angle = math.radians(float(sample_track(clip.float_channels[0], frame)))
    name = f'{args.stem}_{args.side}_{frame:03d}.png' if args.keyposes else f'{index:03d}.png'
    image_path = out/name
    scene.render.filepath = str(image_path)
    bpy.ops.render.render(write_still=True)
    rendered.append({'source_frame': frame, 'path': name, 'sha256': digest(image_path)})
report_name = f'{args.stem}_{args.side}_frames.json' if args.keyposes else 'frames.json'
(out/report_name).write_text(json.dumps({
    'revision': 8, 'stem': args.stem, 'side': args.side, 'frames': frames,
    'fps': clip.playback_rate, 'step': args.step, 'aspect_ratio': 16/9,
    'source_scene_sha256': digest(source), 'actor_sha256': digest(actor_path),
    'camera_sha256': digest(camera_path), 'camera_diagnostics_sha256': digest(diagnostics_path),
    'render_script_sha256': digest(Path(__file__)), 'rendered_files': rendered,
    'phase_windows': camera_record['phase_windows'],
    'note': 'Actual exported V8 camera; unchanged actor prefix uses the accepted canonical scene. Native engine particles are not rendered in Blender.'
}, indent=2)+'\n')
print('V8 exported camera rendered:', args.stem, args.side, len(frames), 'frames', flush=True)
