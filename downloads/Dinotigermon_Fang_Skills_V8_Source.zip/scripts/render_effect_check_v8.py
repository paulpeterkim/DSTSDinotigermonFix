"""Read-only geometry diagnostic for the exported V8 effects and cameras.

This preview uses actual GEOM, ANIM, and NLST files. Workbench materials cannot
reproduce native shader opacity, float-channel shader animation, or BSON engine
emitter behavior; it is an alignment check, not an in-game VFX screenshot.
"""
from pathlib import Path
import argparse
import hashlib
import importlib
import inspect
import json
import math
import sys

import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Quaternion, Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from anim_codec import _load_tools, _PACKAGE, read, sample, sample_track


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def render_one(stem, side):
    source = ROOT/'outputs_v3/Dinotigermon_Fang_Attacks_V3.blend'
    patch = ROOT/'modified_v8/dsts-loader/patch'
    diagnostics_path = ROOT/'work/v8/cameras.json'
    effect_report_path = ROOT/'work/v8/effects.json'
    diagnostics = json.loads(diagnostics_path.read_text())
    effects = json.loads(effect_report_path.read_text())
    effect_record = next(row for row in effects['effects'] if row['stem']==stem)
    effect_name = effect_record['name']
    effect_paths = {ext: patch/(effect_name+'.'+ext) for ext in ('bson','geom','anim','nlst')}
    for ext, path in effect_paths.items():
        if digest(path) != effect_record['output_sha256'][ext]:
            raise ValueError('Effect differs from author diagnostics: '+str(path))
    relative_camera = f'dsts-loader/patch/cam_chr424857_{stem}_{side}.anim'
    camera_path = ROOT/'modified_v8'/relative_camera
    actor_path = patch/f'chr424857_{stem}.anim'
    camera_record = next(row for row in diagnostics['cameras'] if row['path']==relative_camera)
    actor_record = next(row for row in diagnostics['actors'] if Path(row['path']).name==actor_path.name)
    if digest(camera_path) != camera_record['modified_sha256']:
        raise ValueError('Exported camera differs from author diagnostics')
    if digest(actor_path) != actor_record['modified_sha256'] or actor_record['source_sha256'] != actor_record['modified_sha256']:
        raise ValueError('Actor differs from the unchanged V7 actor')
    v7_audit = json.loads((ROOT/'work/v7/camera_framing_audit.json').read_text())
    if digest(source) != v7_audit['source_scene_sha256']:
        raise ValueError('Canonical actor scene differs from V7 source')
    bpy.ops.wm.open_mainfile(filepath=str(source))
    scene = bpy.context.scene
    actor = bpy.data.objects['chr424857']
    actor.animation_data.action = bpy.data.actions['chr424857_'+stem]
    for track in actor.animation_data.nla_tracks:
        track.mute = True
    camera = scene.camera
    _load_tools()
    module = importlib.import_module(f'{_PACKAGE}.src.BlenderIO.Import.ImportTimeStrangerGeom')
    errorlog = importlib.import_module(f'{_PACKAGE}.src.BlenderIO.Logging').ImportErrorLog
    before_objects = set(bpy.data.objects)
    # Two mesh labels in the supplied claw NLST do not match their GEOM hashes.
    # Keep every source asset intact and supply only Blender display-name fallbacks.
    source_code = inspect.getsource(module.import_ts_geom).replace(
        'mesh_name_lookup[mesh.name_hash]',
        'mesh_name_lookup.get(mesh.name_hash, f"EffectMesh_{i}")')
    namespace = dict(module.__dict__)
    exec(source_code, namespace)
    namespace['import_ts_geom'](str(effect_paths['geom']), errorlog())
    effect = bpy.data.objects[effect_name]
    action = bpy.data.actions[effect_name+'_base']
    clip = read(effect_paths['anim'])
    # Imported action keys use raw 512 Hz sample indices, while the actor scene
    # runs at 30 fps. Change only this in-memory Blender action's time coordinate.
    factor = 30.0/clip.playback_rate
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.co.x = 1+(key.co.x-1)*factor
            key.handle_left.x = 1+(key.handle_left.x-1)*factor
            key.handle_right.x = 1+(key.handle_right.x-1)*factor
        curve.update()
    effect.animation_data.action = action
    for track in effect.animation_data.nla_tracks:
        track.mute = True
    effect_meshes = [obj for obj in set(bpy.data.objects)-before_objects if obj.type=='MESH']
    # Display the decoded color uniforms in Workbench. Native shader texture and
    # alpha output remains an explicit limitation of this geometry diagnostic.
    geometry_module = importlib.import_module(f'{_PACKAGE}.src.filetypes.Geom.Binary.TimeStranger')
    geom = geometry_module.GeomFileBinaryTimeStranger()
    geom.read(str(effect_paths['geom']))
    material_names = [geom.get_string(o).decode() for o in geom.name_offsets.material_name_offsets]
    for index, material in enumerate(geom.materials):
        rgb = None
        for uniform in material.uniforms:
            if uniform.index==0x19 and uniform.float_count==4 and max(uniform.unpack()[:3])>0:
                rgb = uniform.unpack()[:3]
                break
        if rgb is None:
            rgb = next((u.unpack()[:3] for u in material.uniforms if u.index==0x12d and u.float_count==3),(.8,.8,.8))
        intensity = max(max(rgb),1.)
        color = tuple(v/intensity for v in rgb)+(1.,)
        for obj in effect_meshes:
            mat = obj.active_material
            if mat and mat.name.split('.')[0]==material_names[index]:
                mat.diffuse_color = color
    scene.render.engine='BLENDER_WORKBENCH'
    scene.display.shading.light='STUDIO'
    scene.display.shading.color_type='MATERIAL'
    scene.display.shading.show_shadows=False
    scene.display.shading.show_cavity=True
    scene.render.resolution_x=768
    scene.render.resolution_y=432
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    camera.data.type='PERSP'
    camera.data.sensor_fit='HORIZONTAL'
    camera.data.shift_x=camera.data.shift_y=0.
    camera.rotation_mode='QUATERNION'
    camera_clip=read(camera_path,expected_bones=2)
    conversion=Quaternion((1.,0.,0.),math.pi/2)
    frames=[40,58,67] if stem=='bs01' else [43,47]
    out=ROOT/'work/v8/effect_checks'
    out.mkdir(parents=True,exist_ok=True)
    rendered=[]
    for frame in frames:
        scene.frame_set(frame+1)
        position,rotation,_=sample(camera_clip,0,frame)
        camera.location=Vector((position[0],-position[2],position[1]))
        camera.rotation_quaternion=conversion@Quaternion((rotation[3],*rotation[:3]))
        camera.data.angle=math.radians(float(sample_track(camera_clip.float_channels[0],frame)))
        bpy.context.view_layer.update()
        deps=bpy.context.evaluated_depsgraph_get()
        points=[]
        for obj in effect_meshes:
            evaluated=obj.evaluated_get(deps)
            mesh=evaluated.to_mesh()
            points.extend([obj.matrix_world@v.co for v in mesh.vertices])
            evaluated.to_mesh_clear()
        projected=[world_to_camera_view(scene,camera,p) for p in points]
        in_frame=sum(0<=p.x<=1 and 0<=p.y<=1 and p.z>0 for p in projected)
        filename=f'{stem}_{side}_{frame:03d}.png'
        path=out/filename
        scene.render.filepath=str(path)
        bpy.ops.render.render(write_still=True)
        rendered.append({'source_frame':frame,'file':filename,'sha256':digest(path),
            'effect_world_bounds_blender':[[min(p[a] for p in points) for a in range(3)],
                                           [max(p[a] for p in points) for a in range(3)]],
            'effect_projected_bounds':[[min(p[a] for p in projected) for a in range(2)],
                                       [max(p[a] for p in projected) for a in range(2)]],
            'effect_vertices_in_camera':in_frame,'effect_vertex_count':len(points)})
    report={'revision':8,'stem':stem,'side':side,'frames':frames,
        'source_scene_sha256':digest(source),'actor_sha256':digest(actor_path),
        'camera_sha256':digest(camera_path),'effect_sha256':{ext:digest(path) for ext,path in effect_paths.items()},
        'effect_diagnostics_sha256':digest(effect_report_path),'camera_diagnostics_sha256':digest(diagnostics_path),
        'script_sha256':digest(Path(__file__)),'effect_mesh_count':len(effect_meshes),
        'source_effect_fps':clip.playback_rate,'preview_actor_fps':30,
        'note':__doc__.strip(),'rendered_files':rendered}
    (out/f'{stem}_{side}_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Actual V8 effect geometry checked:',stem,frames,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stem',choices=['bs01','bs02','both'],default='both')
    parser.add_argument('--side',choices=['pc','em'],default='pc')
    arguments=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    args=parser.parse_args(arguments)
    for stem in (['bs01','bs02'] if args.stem=='both' else [args.stem]):
        render_one(stem,args.side)
