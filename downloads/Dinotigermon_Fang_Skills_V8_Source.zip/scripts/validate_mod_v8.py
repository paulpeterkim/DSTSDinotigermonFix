#!/usr/bin/env python3
"""Independently validate the V8 main-effect bundles and tighter cameras.

This checks exported game assets and actual Blender projection reports. It does
not claim that a Windows game-engine playthrough has been performed.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import math
from pathlib import Path
import sys
import tempfile
import traceback
import zipfile

import numpy as np

import anim_codec
from effect_bson import Document
from motion_math import fk, normalize, qrotate
from patch_skills import SKILL_TABLE, GROUND_FANG_ID, HIGHLAND_FANG_ID
from validate_mod import check, inventory, parse_typed_csv, sha256

ROOT = Path(__file__).resolve().parents[1]
PATCH = Path("dsts-loader/patch")
EFFECT_TABLE = PATCH/"data/battle_effect.mbe/000_battle_effect_list.ap.csv"
COUNTS = {"bs01": 68, "bs02": 48}
ACTORS = {PATCH/f"chr424857_{stem}.anim": stem for stem in COUNTS}
CAMERAS = {PATCH/f"cam_chr424857_{stem}_{side}.anim": stem
           for stem in COUNTS for side in ("pc", "em")}
SKILLS = {GROUND_FANG_ID: "bs01", HIGHLAND_FANG_ID: "bs02"}
SOURCE_MODELS = {"bs01": "ef_b_ch5548_bs02", "bs02": "ef_b_ch5548_bs01"}
SOURCE_IMAGES = {"bs01": [f"ki482000000{i}.img" for i in range(2)],
                 "bs02": [f"ki481000000{i}.img" for i in range(6)]}
PHASES = {"bs01": {"muzzle": set(range(16, 32)), "face": set(range(39, 53)), "jaw": set(range(65, 68))},
          "bs02": {"muzzle": set(range(18, 35)), "face": set(range(40, 48)), "jaw": set()}}


def quat_angles(a, b):
    dots = np.clip(np.abs(np.sum(np.asarray(a)*np.asarray(b), axis=-1)), 0, 1)
    return np.degrees(2*np.arccos(dots))


def equal_tracks(left, right, *, quaternion=False, tolerance=1e-4):
    check(set(left) == set(right), "Protected channel key inventory changed")
    error = 0.
    for frame in left:
        a, b = np.asarray(left[frame]), np.asarray(right[frame])
        if quaternion and np.dot(a, b) < 0:
            b = -b
        difference = float(np.max(np.abs(a-b)))
        check(difference <= tolerance, f"Protected sample changed at frame{frame}: {difference}")
        error = max(error, difference)
    return error


def validate_scope(baseline, baseline_report, modified, report):
    accepted = json.loads(baseline_report.read_text())
    check(accepted.get("passed") is True and accepted.get("revision") == 7,
          "V8 requires the accepted V7 baseline")
    before, after = inventory(baseline), inventory(modified)
    expected = {p.as_posix(): sha256(f) for p, f in sorted(before.items())}
    check(expected == accepted.get("asset_sha256"), "V7 baseline no longer matches its accepted report")
    check(set(before) <= set(after), "V8 removed an existing game asset")
    allowed = {*CAMERAS, SKILL_TABLE, EFFECT_TABLE}
    changes = []
    for relative in sorted(before):
        new_hash = sha256(after[relative])
        if new_hash != expected[relative.as_posix()]:
            check(relative in allowed, f"Unexpected V7 asset mutation: {relative}")
            changes.append({"path": relative.as_posix(), "v7_sha256": expected[relative.as_posix()],
                            "v8_sha256": new_hash})
    check({r["path"] for r in changes} == {p.as_posix() for p in allowed},
          "Expected four camera changes and the two effect-reference tables")
    check(not list((modified/"dsts-loader").glob("patch_text*/text/skill_explanation.mbe/*.csv")),
          "Removed description overrides were restored")
    report["baseline_validation_sha256"] = sha256(baseline_report)
    report["file_changes"] = changes
    report["added_files"] = sorted(p.as_posix() for p in set(after)-set(before))
    report["checks"].append({"name": "accepted_v7_baseline_and_preserved_actor_assets", "passed": True,
                             "original_files": len(before), "changed_existing_files": len(changes),
                             "unchanged_existing_files": len(before)-len(changes),
                             "note": "Both actor clips, jaw binding, all character assets and unrelated data are byte-identical to V7."})
    return before, after


def validate_skill_bindings(baseline, modified, report):
    old_header, old_rows = parse_typed_csv(baseline/SKILL_TABLE)
    header, rows = parse_typed_csv(modified/SKILL_TABLE)
    check(header == old_header and len(rows) == len(old_rows) == 2, "Skill schema/row count changed")
    old = {r[0]: r for r in old_rows}; current = {r[0]: r for r in rows}
    check(set(current) == set(SKILLS), "Skill identifiers changed")
    effects_header, effects_rows = parse_typed_csv(modified/EFFECT_TABLE)
    old_effects_header, old_effects_rows = parse_typed_csv(baseline/EFFECT_TABLE)
    check(effects_header == old_effects_header, "Battle-effect table schema changed")
    effect_map = {r[0]: r for r in effects_rows}
    check(all(effect_map.get(r[0]) == r for r in old_effects_rows), "An existing effect row changed")
    bundles = {}
    references = []
    for skill_id, stem in SKILLS.items():
        row = current[skill_id]
        delta = {i for i, (a, b) in enumerate(zip(old[skill_id], row)) if a != b}
        check(delta <= {12, 14, 16}, f"Non-effect gameplay or text fields changed: {skill_id}, {delta}")
        check(row[5] == "0" and row[11] == "1", "Automatic descriptions or hit scheduling changed")
        check(row[12] != "0" and row[14] == row[16] == "0", "Main effect missing or obsolete late full effects remain")
        effect_id = row[12]
        check(effect_id in effect_map, f"Main effect has no table row: {effect_id}")
        effect = effect_map[effect_id]
        check(effect[5] == "1" and effect[7] == "3", "Main effect does not use reference mode1/type3")
        check(effect[8:] == ["0", "1", "0", "-1", "-1", "false", ""], "Unexpected custom-effect playback settings")
        model = effect[4]
        check(model and model != SOURCE_MODELS[stem] and "/" not in model and "\\" not in model,
              "Effect does not use a unique local asset basename")
        check(model not in bundles.values(), "Both skills unexpectedly share a main effect bundle")
        bundles[stem] = model
        references.append({"skill_id": skill_id, "actor": stem, "main_effect_column": 12,
                           "main_effect_id": effect_id, "model": model, "post_hit_columns": {"14": row[14], "16": row[16]},
                           "changed_skill_columns": sorted(delta)})
    check(set(effect_map)-{r[0] for r in old_effects_rows} == {r["main_effect_id"] for r in references},
          "Unexpected extra battle-effect rows")
    report["skill_effect_bindings"] = references
    report["checks"].append({"name": "during_animation_main_effect_bindings_and_gameplay_preservation", "passed": True,
                             "skills": references,
                             "note": "The old post-hit full effects are cleared; the game hit trigger itself remains after the actor clip."})
    return bundles


def full_geom(path):
    anim_codec._load_tools()
    module = importlib.import_module(f"{anim_codec._PACKAGE}.src.filetypes.Geom.Binary.TimeStranger")
    geom = module.GeomFileBinaryTimeStranger(); geom.read(str(path))
    return geom


def validate_geom_delta(source, target):
    """Reconstruct target allowing only explicit color-uniform payload changes."""
    before, after = full_geom(source), full_geom(target)
    check(len(before.materials) == len(after.materials), "Effect material inventory changed")
    changes = []
    for material_index, (left, right) in enumerate(zip(before.materials, after.materials)):
        check(len(left.uniforms) == len(right.uniforms), "Effect uniform inventory changed")
        for uniform_index, (a, b) in enumerate(zip(left.uniforms, right.uniforms)):
            if a.payload != b.payload:
                check(a.index == b.index and a.index in (0x19, 0x12d) and a.float_count == b.float_count,
                      "Effect GEOM changed a protected shader parameter")
                values = b.unpack()
                check(b.float_count in (3, 4) and np.isfinite(values).all(), "Invalid effect material color")
                changes.append({"material_index": material_index, "uniform_index": uniform_index,
                                "uniform_id": hex(a.index), "source": list(a.unpack()), "result": list(values)})
                a.payload = b.payload
    with tempfile.TemporaryDirectory(prefix="dinotigermon-v8-geom-check-") as temp:
        rebuilt = Path(temp)/"checked.geom"; before.write(str(rebuilt))
        check(rebuilt.read_bytes() == target.read_bytes(), "Effect GEOM contains changes beyond allowed color uniforms")
    return after, changes


def validate_bson_delta(source_raw, target_raw, model, *, remove_snow):
    """Compare the parsed controls independently of the author's byte patcher."""
    source, target = Document(source_raw), Document(target_raw)
    removed = ("sg", "snow_set") if remove_snow else None
    expected = {p: n for p, n in source.by_path.items()
                if removed is None or p[:len(removed)] != removed}
    check(set(target.by_path) == set(expected), "Effect BSON removed or added an unexpected control node")
    changes = []
    for path, left in expected.items():
        right = target.by_path[path]
        check(left.kind == right.kind and left.key == right.key, "Effect BSON control types changed")
        if left.kind == 1:
            expected_count = left.value-(1 if remove_snow and path == ("sg",) else 0)
            check(right.value == expected_count, "Effect BSON child count changed unexpectedly")
            continue
        wanted = model if left.key == "dn" else 0 if left.key == "se_volume" else left.value
        check(right.value == wanted, f"Protected effect BSON control changed: {'/'.join(path)}")
        if left.value != right.value:
            changes.append({"path": "/".join(path), "source": left.value, "result": right.value})
    check(target.string_data[:len(source.string_data)] == source.string_data,
          "Existing BSON string-table contents changed")
    return changes


def validate_effect_timing(config, source, actual, actor, skeleton):
    """Check exported samples against source data without the authoring sampler.

    Every linear output key is compared with independent numpy interpolation.
    Quaternion tracks are checked with the codec's scalar SLERP at evenly
    spaced samples and each retiming/gate boundary and its immediate neighbors.
    All root positions/gating samples are verified independently as well.
    """
    count = actual._source_frame_count
    check(count == round(actor._source_duration*512)+1, "Effect frame count is not the nearest512Hz actor duration")
    knots = np.asarray(config["time_map_target_seconds_to_source_seconds"], dtype=float)
    check(knots.ndim == 2 and knots.shape[1] == 2 and np.isfinite(knots).all(), "Invalid effect time map")
    check(np.all(np.diff(knots[:, 0]) > 0) and np.all(np.diff(knots[:, 1]) >= 0), "Effect time map reverses or duplicates time")
    check(np.max(np.abs(knots[0])) < 1e-8 and abs(knots[-1, 0]-actual._source_duration) < 2e-6,
          "Effect time map does not cover its exact exported duration")
    check(knots[-1, 1] <= source._source_duration+1/512., "Effect time map samples beyond its source")
    times = np.arange(count)/512.
    source_frames = np.interp(times, knots[:, 0], knots[:, 1])*512.
    probe_frames = set(np.linspace(0, count-1, 25).round().astype(int))
    for time in list(knots[:, 0])+list(config["gate"])+list(config.get("release_gate", [])):
        frame = round(time*512)
        probe_frames.update(f for f in (frame-1, frame, frame+1) if 0 <= f < count)
    probe_frames = [int(frame) for frame in sorted(probe_frames|{0, count-2, count-1})]
    hidden = set(config["hidden_mesh_bones"])
    expected_hidden = {2, 5, 7, 9, 11, 13, 15, 16, 17, 18} if config["stem"] == "bs01" else set()
    check(hidden == expected_hidden, "Unexpected source effect meshes were hidden")
    maximum = {kind: 0. for kind in ("positions", "rotations", "scales", "float_channels")}
    checked_values = {kind: 0 for kind in maximum}
    for kind in maximum:
        source_channels, target_channels = getattr(source, kind), getattr(actual, kind)
        check(set(source_channels) == set(target_channels), "Retimed effect channel set changed")
        for bone, old in source_channels.items():
            new = target_channels[bone]
            if kind == "scales" and bone in hidden:
                check(set(new) == {0} and np.array_equal(new[0], [0., 0., 0.]), "Ghost hand geometry was not fully suppressed")
                continue
            if bone == 0 and kind in ("positions", "scales"):
                continue
            if not old:
                check(not new, "An unanimated effect channel gained invented keys")
                continue
            check(new and set(new) in ({0}, set(range(count))), "Effect channel has unexpected sparse or missing output keys")
            if kind == "rotations":
                frames = probe_frames
                for frame in frames:
                    wanted = anim_codec.sample_track(old, source_frames[frame], quaternion=True)
                    got = np.asarray(new[0 if len(new) == 1 else frame], dtype=float)
                    if np.dot(wanted, got) < 0: got = -got
                    error = float(np.max(np.abs(wanted-got)))
                    check(error <= 1e-4, f"Incorrect retimed quaternion: bone{bone}, frame{frame}, error{error}")
                    maximum[kind] = max(maximum[kind], error)
                    checked_values[kind] += 1
            else:
                keys = np.array(sorted(old), dtype=float)
                values = np.asarray([old[int(k)] for k in keys], dtype=float)
                # A single stored key holds for the whole clip; check that it
                # was not incorrectly collapsed from a changing source track.
                frames = np.arange(count, dtype=int)
                at = source_frames[frames]
                if values.ndim == 1:
                    wanted = np.interp(at, keys, values)
                else:
                    wanted = np.column_stack([np.interp(at, keys, values[:, column]) for column in range(values.shape[1])])
                got = np.asarray([new[0 if len(new) == 1 else int(f)] for f in frames])
                error = float(np.max(np.abs(wanted-got)))
                check(error <= 1e-4, f"Incorrect retimed {kind}: channel{bone}, error{error}")
                maximum[kind] = max(maximum[kind], error)
                checked_values[kind] += len(frames)
    placement = config["root_placement"]
    if placement["kind"] == "follow_actor_head":
        check(placement["actor_bone"] == 6, "Wind effect follows an unexpected actor joint")
        heads = []
        for frame in range(actor._source_frame_count):
            pose = [anim_codec.sample(actor, bone, frame) for bone in range(actor.bone_count)]
            positions, _ = fk(skeleton, np.asarray([p[0] for p in pose]), np.asarray([p[1] for p in pose]))
            heads.append(positions[6])
        heads = np.asarray(heads)
        actor_frames = times*actor.playback_rate
        positions = np.column_stack([np.interp(actor_frames, np.arange(len(heads)), heads[:, c]) for c in range(3)])
        positions -= float(config["scale"])*np.asarray(placement["effect_center_game"])
        positions += np.asarray(placement["offset_game"])
    else:
        check(placement["kind"] == "constant", "Unknown effect placement rule")
        positions = np.tile(np.asarray(placement["position_game"]), (count, 1))
    check(set(actual.positions[0]) == set(actual.scales[0]) == set(range(count)), "Effect root placement/gate keys are incomplete")
    position_error = float(np.max(np.abs(positions-np.asarray([actual.positions[0][f] for f in range(count)]))))
    check(position_error <= 1e-4, "Main effect does not follow its intended head/stomp location")
    start, finish = config["gate"]
    check(0 <= start < finish < actor._source_duration and 0 < config["scale"] <= 1,
          "Effect visibility gate misses the attack or has invalid scale")
    factor = np.clip((times-start)/(finish-start), 0, 1)
    expected_gate = float(config["scale"])*(3*factor**2-2*factor**3)
    release = config.get("release_gate")
    if release is not None:
        release_start, release_end = release
        check(finish < release_start < release_end <= actor._source_duration,
              "Effect release gate is outside the attack window")
        release_factor = np.clip((times-release_start)/(release_end-release_start), 0, 1)
        expected_gate *= 1-(3*release_factor**2-2*release_factor**3)
    scales = np.asarray([actual.scales[0][f] for f in range(count)])
    gate_error = float(np.max(np.abs(scales-expected_gate[:, None])))
    check(gate_error <= 1e-4 and np.array_equal(scales[times <= start], np.zeros_like(scales[times <= start])),
          "Main-effect growth gate is incorrect or visible before the attack")
    if release is not None:
        check(np.array_equal(scales[times >= release[1]], np.zeros_like(scales[times >= release[1]])),
              "Main effect remains visible after its release window")
    return {"retimed_channel_max_component_error": maximum, "verified_output_values": checked_values,
            "quaternion_probe_frames": probe_frames, "all_root_positions_max_error": position_error,
            "all_root_scales_max_error": gate_error, "gate_seconds": config["gate"],
            "time_map_target_seconds_to_source_seconds": knots.tolist(),
            "first_visible_effect_frame": int(np.flatnonzero(scales[:, 0] > 0)[0]),
            "last_visible_effect_frame": int(np.flatnonzero(scales[:, 0] > 0)[-1]),
            "release_gate_seconds": release,
            "root_placement": placement, "hidden_mesh_bones": sorted(hidden)}


def validate_effects(modified, bundles, reference_zip, reference_dir, effect_report_path, report):
    check(reference_zip.is_file(), "Reference ZIP is required for provenance validation")
    check(effect_report_path.is_file(), "Missing main-effect authoring/timing report")
    effect_report = json.loads(effect_report_path.read_text())
    check(effect_report.get("revision") == 8 and effect_report.get("reference_zip_sha256") == sha256(reference_zip),
          "Effect report describes another reference upload")
    configs = {row["stem"]: row for row in effect_report["effects"]}
    check(set(configs) == set(COUNTS), "Effect authoring report has the wrong skill inventory")
    actor_skeleton = anim_codec.read_embedded_skeleton(modified/PATCH/"chr424857.geom")
    added_expected = set()
    records = []
    with zipfile.ZipFile(reference_zip) as archive:
        check(archive.testzip() is None, "Reference ZIP CRC failure")
        for stem, model in bundles.items():
            source_model = SOURCE_MODELS[stem]
            config = configs[stem]
            check(config["source"] == source_model and config["name"] == model, "Effect report describes a different source/main bundle")
            paths = {ext: modified/PATCH/(model+"."+ext) for ext in ("bson", "geom", "anim", "nlst")}
            check(all(p.is_file() for p in paths.values()), f"Incomplete local main-effect bundle: {model}")
            added_expected.update(p.relative_to(modified).as_posix() for p in paths.values())
            for ext in ("bson", "geom", "anim", "nlst"):
                relative = (PATCH/(source_model+"."+ext)).as_posix()
                check((reference_dir/relative).read_bytes() == archive.read(relative), "Extracted effect source differs from reference ZIP")
            source_geom = reference_dir/PATCH/(source_model+".geom")
            geom, color_changes = validate_geom_delta(source_geom, paths["geom"])
            check(paths["nlst"].read_bytes() == archive.read((PATCH/(source_model+".nlst")).as_posix()),
                  "Internal effect names/hierarchy changed")
            document = Document.read(paths["bson"])
            bson_changes = validate_bson_delta(archive.read((PATCH/(source_model+".bson")).as_posix()),
                                               paths["bson"].read_bytes(), model, remove_snow=stem == "bs01")
            dn = [n.value for n in document.scalars("dn") if n.value]
            check(dn == [model], f"Effect BSON model dependency is missing or unresolved: {dn}")
            volumes = document.scalars("se_volume")
            check(volumes and all(n.value == 0 for n in volumes), "Main effect still contains enabled attack audio")
            anim = anim_codec.read(paths["anim"])
            source_anim = anim_codec.read(reference_dir/PATCH/(source_model+".anim"))
            check(anim.bone_count == geom.skel.bone_count == source_anim.bone_count,
                  "Effect animation/skeleton bone counts disagree")
            check(anim.float_channel_count == geom.skel.float_channel_count == source_anim.float_channel_count,
                  "Effect animation/skeleton float channel counts disagree")
            check(anim.playback_rate == source_anim.playback_rate == 512., "Effect timebase was treated as character fps")
            actor = anim_codec.read(modified/PATCH/f"chr424857_{stem}.anim")
            check(abs(anim._source_duration-actor._source_duration) <= 1/512.+1e-4,
                  "Main effect duration does not align with the actor clip")
            for field in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
                check(np.array_equal(getattr(anim, field), getattr(source_anim, field)), f"Effect metadata changed: {field}")
            check(config["output_sha256"] == {ext: sha256(path) for ext, path in paths.items()}, "Effect report uses stale exported assets")
            timing = validate_effect_timing(config, source_anim, anim, actor, actor_skeleton)
            images = []
            for image in SOURCE_IMAGES[stem]:
                relative = PATCH/"images"/image
                added_expected.add(relative.as_posix())
                check((modified/relative).is_file(), f"Missing custom main-effect texture: {image}")
                check((modified/relative).read_bytes() == archive.read(relative.as_posix()), "Reference effect texture changed")
                images.append({"path": relative.as_posix(), "sha256": sha256(modified/relative)})
            records.append({"actor": stem, "model": model, "reference_model": source_model,
                            "reference_bundle_sha256": {ext: hashlib.sha256(archive.read((PATCH/(source_model+"."+ext)).as_posix())).hexdigest()
                                                         for ext in paths},
                            "bundle_sha256": {ext: sha256(p) for ext, p in paths.items()},
                            "frames": anim._source_frame_count, "duration": anim._source_duration,
                            "actor_duration": actor._source_duration, "fps": anim.playback_rate,
                            "bones": anim.bone_count, "float_channels": anim.float_channel_count,
                            "sound_volume_fields": [{"path": "/".join(n.path), "value": n.value} for n in volumes],
                            "bson_scalar_changes": bson_changes, "snow_auxiliary_removed": stem == "bs01",
                            "retiming_and_placement": timing,
                            "color_uniform_changes": color_changes, "supplied_images": images})
    check(set(report["added_files"]) == added_expected, "Added game files differ from the two complete effect bundles and their textures")
    report["reference_zip_sha256"] = sha256(reference_zip)
    report["effect_authoring_report_sha256"] = sha256(effect_report_path)
    report["effects"] = records
    report["checks"].append({"name": "complete_reference_main_effect_assets_textures_timebase_and_muted_audio", "passed": True,
                             "effects": records,
                             "note": "Generic ef_* shader textures are the same vanilla-game dependencies used by the supplied reference."})
    report["checks"].append({"name": "independent_effect_retiming_head_follow_stomp_location_and_visibility_gates", "passed": True,
                             "effects": [{"actor": row["actor"], **row["retiming_and_placement"]} for row in records],
                             "note": "All linear output keys and root transforms are checked; quaternion tracks use independent codec SLERP probes including every time-map boundary."})
    return effect_report


def validate_cameras(baseline, modified, report):
    skeleton = anim_codec.read_embedded_skeleton(modified/PATCH/"chr424857.geom")
    actors, forward = {}, {}
    for relative, stem in ACTORS.items():
        check((baseline/relative).read_bytes() == (modified/relative).read_bytes(), "Actor motion changed in the camera/effect revision")
        actor = anim_codec.read(modified/relative); actors[stem] = actor
        check(actor._source_frame_count == COUNTS[stem], "Actor attack ending changed")
        positions = []
        for frame in (0, COUNTS[stem]-1):
            poses = [anim_codec.sample(actor, bone, frame) for bone in range(52)]
            wp, _ = fk(skeleton, np.asarray([p[0] for p in poses]), np.asarray([p[1] for p in poses]))
            positions.append(wp[2])
        v = positions[1]-positions[0]; v[1] = 0; forward[stem] = normalize(v)
    decoded = {}
    records = []
    for relative, stem in CAMERAS.items():
        old, new = anim_codec.read(baseline/relative), anim_codec.read(modified/relative)
        count = COUNTS[stem]
        check(new.bone_count == old.bone_count == 2 and new._source_frame_count == old._source_frame_count == count,
              "Camera skeleton or frame count changed")
        check(new.playback_rate == old.playback_rate and abs(new._source_duration-actors[stem]._source_duration) < 2e-6,
              "Camera and actor duration/timebase differ")
        for field in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
            check(np.array_equal(getattr(old, field), getattr(new, field)), f"Camera metadata changed: {relative}:{field}")
        protected_error = 0.
        for kind in ("positions", "rotations", "scales", "float_channels"):
            a, b = getattr(old, kind), getattr(new, kind)
            check(set(a) == set(b), "Camera channel inventory changed")
            for channel in a:
                mutable = (channel == 0 and kind in ("positions", "rotations", "float_channels"))
                if not mutable:
                    protected_error = max(protected_error, equal_tracks(a[channel], b[channel], quaternion=kind == "rotations"))
                else:
                    check(set(b[channel]) == set(range(count)), "Camera root/FOV track is missing frames")
                    for frame in range(7):
                        av, bv = np.asarray(anim_codec.sample_track(a[channel], frame, quaternion=kind == "rotations")), np.asarray(b[channel][frame])
                        if kind == "rotations" and np.dot(av, bv) < 0: bv = -bv
                        check(float(np.max(np.abs(av-bv))) <= 1e-4, "Opening camera0–6 was changed")
        samples = [anim_codec.sample(new, 0, f) for f in range(count)]
        p, q = np.asarray([s[0] for s in samples]), np.asarray([s[1] for s in samples])
        fov = np.asarray([float(anim_codec.sample_track(new.float_channels[0], f)) for f in range(count)])
        check(np.isfinite(p).all() and np.isfinite(q).all() and np.isfinite(fov).all(), "Nonfinite camera channel")
        check(np.all((fov > 5) & (fov < 120)), "Invalid camera FOV")
        steps = np.linalg.norm(np.diff(p, axis=0), axis=1)
        rotation_steps = quat_angles(q[1:], q[:-1]); fov_steps = np.abs(np.diff(fov))
        check(float(max(steps)) <= 1.5 and float(max(rotation_steps)) <= 30 and float(max(fov_steps)) <= 6,
              f"Abrupt camera transition: {relative}")
        directions = [float(np.dot(qrotate(q[f], [1., 0., 0.]), forward[stem])) for f in range(9, count)]
        check(min(directions) > .025, "Camera reversed the left-to-right attack direction")
        decoded[relative] = new
        records.append({"path": relative.as_posix(), "frames": count, "duration": new._source_duration,
                        "fps": new.playback_rate, "max_protected_channel_error": protected_error,
                        "max_position_step": float(max(steps)), "max_rotation_step_degrees": float(max(rotation_steps)),
                        "max_fov_step_degrees": float(max(fov_steps)), "minimum_screen_forward_dot": min(directions),
                        "sha256": sha256(modified/relative)})
    for stem in COUNTS:
        a = decoded[PATCH/f"cam_chr424857_{stem}_pc.anim"]
        b = decoded[PATCH/f"cam_chr424857_{stem}_em.anim"]
        for kind in ("positions", "rotations", "float_channels"):
            equal_tracks(getattr(a, kind)[0], getattr(b, kind)[0], quaternion=kind == "rotations")
    report["cameras"] = records
    report["checks"].append({"name": "unchanged_openings_matching_actor_lengths_camera_metadata_and_direction", "passed": True,
                             "cameras": records})


def validate_framing(audit_path, modified, report):
    check(audit_path.is_file(), "Missing independent actual-mesh Blender framing audit")
    audit = json.loads(audit_path.read_text())
    check(audit.get("passed") is True and audit.get("revision") == 8, "V8 Blender framing audit did not pass")
    check(audit["projection"]["aspect_ratio"] == "16:9" and audit["projection"]["fov_convention"] == "horizontal",
          "Framing projection convention changed")
    expected_cameras = {r.as_posix(): sha256(modified/r) for r in CAMERAS}
    expected_actors = {r.as_posix(): sha256(modified/r) for r in ACTORS}
    check(audit["camera_sha256"] == expected_cameras and audit["actor_sha256"] == expected_actors,
          "Framing audit uses stale cameras or actor clips")
    check(audit["clip_frame_counts"] == COUNTS, "Framing audit uses different attack endings")
    check(audit["source_geometry_sha256"] == sha256(modified/PATCH/"chr424857.geom"), "Framing audit geometry changed")
    for field, filename in (("face_selection_sha256", "face_selection.json"), ("jaw_selection_sha256", "jaw_selection.json"),
                            ("muzzle_selection_sha256", "muzzle_selection.json"), ("camera_diagnostics_sha256", "cameras.json")):
        check(audit[field] == sha256(audit_path.parent/filename), f"Framing audit uses stale {filename}")
        report[field] = audit[field]
    scene = ROOT/"outputs_v3/Dinotigermon_Fang_Attacks_V3.blend"
    if scene.exists(): check(audit["source_scene_sha256"] == sha256(scene), "Framing audit scene changed")
    check(set(audit["cameras"]) == set(expected_cameras), "Framing audit camera inventory differs")
    summaries = []
    for relative, record in audit["cameras"].items():
        stem = CAMERAS[Path(relative)]; rows = record["frames"]
        check(len(rows) == COUNTS[stem] and [r["frame"] for r in rows] == list(range(COUNTS[stem])), "Missing audited camera frames")
        for region, field, minimum in (("muzzle", "tight_muzzle_frames", .65), ("face", "full_face_frames", .65),
                                       ("jaw", "jaw_end_frames", .55)):
            phase = set(record[field])
            check(phase == PHASES[stem][region], f"Incorrect {region} framing phase")
            for row in rows:
                value = row[region]
                check(math.isfinite(value["min_depth"]) and value["min_depth"] > .05, "Face geometry crosses the camera near plane")
                if row["frame"] not in phase: continue
                lo, hi = np.asarray(value["bbox_ndc"]["min"]), np.asarray(value["bbox_ndc"]["max"])
                check(lo.shape == hi.shape == (2,) and np.isfinite(lo).all() and np.isfinite(hi).all(), "Invalid projected bounds")
                check(np.all(lo >= .02) and np.all(hi <= .98) and minimum <= value["height_fraction"] <= .96,
                      f"{relative} frame{row['frame']} {region} is too small or cropped")
        check(not record.get("near_plane_failure_frames"), "Framing audit reports near-plane failures")
        check(not record.get("screen_direction_failure_frames") and record["min_active_screen_forward_dot"] > 0,
              "Actual Blender camera reverses the attack direction")
        check(not record.get("below_ground_failure_frames") and record["minimum_camera_ground_clearance"] >= .05,
              "Actual Blender camera passes below the ground")
        summaries.append({"path": relative, "muzzle_frames": sorted(PHASES[stem]["muzzle"]),
                          "face_frames": sorted(PHASES[stem]["face"]), "jaw_frames": sorted(PHASES[stem]["jaw"])})
    report["framing_audit_sha256"] = sha256(audit_path)
    report["checks"].append({"name": "independent_actual_mesh_earlier_muzzle_strike_face_and_final_jaw_framing", "passed": True,
                             "cameras": summaries})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=ROOT/"modified_v7")
    parser.add_argument("--modified", type=Path, default=ROOT/"modified_v8")
    parser.add_argument("--baseline-report", type=Path, default=ROOT/"outputs_v7/validation.json")
    parser.add_argument("--reference-zip", type=Path, default=Path("/workspace/attachments/95f5236a-48a8-4297-bb7b-145cb6ec34e3/KumamonKorikakumon_55047.zip"))
    parser.add_argument("--reference-dir", type=Path, default=Path("/workspace/reference_kumamon"))
    parser.add_argument("--effect-report", type=Path, default=ROOT/"work/v8/effects.json")
    parser.add_argument("--framing-audit", type=Path, default=ROOT/"work/v8/camera_framing_audit.json")
    parser.add_argument("--report", type=Path, default=ROOT/"outputs_v8/validation.json")
    args = parser.parse_args()
    report = {"revision": 8, "passed": False, "checks": [], "baseline": str(args.baseline.resolve()),
              "modified": str(args.modified.resolve())}
    try:
        before, after = validate_scope(args.baseline, args.baseline_report, args.modified, report)
        bundles = validate_skill_bindings(args.baseline, args.modified, report)
        validate_effects(args.modified, bundles, args.reference_zip, args.reference_dir, args.effect_report, report)
        validate_cameras(args.baseline, args.modified, report)
        validate_framing(args.framing_audit, args.modified, report)
        report["asset_sha256"] = {relative.as_posix(): sha256(path) for relative, path in sorted(after.items())}
        report["passed"] = True
    except Exception as error:
        report["error"] = str(error); report["traceback"] = traceback.format_exc()
    report["limits"] = ["Main-effect playback, shaders and combat-space attachment need an in-game test.",
                        "Effect-owned sound volumes are muted; this does not alter global game hit/voice audio.",
                        "Actor motion is unchanged V7; tighter framing hides much of the leg motion rather than revising its pose."]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+"\n")
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report}")
    if not report["passed"]:
        print(report["error"], file=sys.stderr); return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
