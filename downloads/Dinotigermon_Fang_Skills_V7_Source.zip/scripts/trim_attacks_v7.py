"""End both attacks on active strike poses, with no recovery/idle tail.

The actor motion is an exact prefix of V6. Ground's jaw close-up is brought
forward to the final tear; Highland's camera is trimmed with its strike.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np

from anim_codec import read, write, sample, sample_track, read_embedded_skeleton, slerp
from author_cameras_v5 import face_points, skinned_face, projected_bounds, zoom_weight
from revise_mod_v6 import jaw_points, framed_view
from geom_preview import read_geom
from motion_math import fk, qrotate, normalize

ROOT = Path(__file__).resolve().parents[1]
COUNTS = {'bs01': 68, 'bs02': 48}
JAW_START, JAW_END = 52, 67


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(folder):
    return {p.relative_to(folder).as_posix(): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}


def trim(anim, frames):
    result = deepcopy(anim)
    for kind in ('positions', 'rotations', 'scales', 'float_channels'):
        setattr(result, kind, {channel: {f: value for f, value in track.items() if f < frames}
                               for channel, track in getattr(result, kind).items()})
    return result


def jaw_weight(frame):
    t = min(1., max(0., (frame-JAW_START)/(JAW_END-JAW_START)))
    return t*t*t*(10+t*(-15+6*t))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT/'modified_v6')
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v7')
    parser.add_argument('--baseline-report', type=Path, default=ROOT/'outputs_v6/validation.json')
    args = parser.parse_args()
    baseline = json.loads(args.baseline_report.read_text())
    if not baseline['passed'] or inventory(args.source) != baseline['asset_sha256']:
        raise ValueError('Source differs from the accepted V6 mod')
    if args.destination.exists():
        raise FileExistsError('Destination exists; use a fresh folder to preserve prior builds')
    patch = args.source/'dsts-loader/patch'
    skeleton = read_embedded_skeleton(patch/'chr424857.geom')
    geom = read_geom(patch/'chr424857.geom')
    face_bindings, face_count, face_selection = face_points(geom, skeleton)
    jaw_bindings, jaw_count, jaw_selection = jaw_points(geom, skeleton)
    out = ROOT/'work/v7'; out.mkdir(parents=True, exist_ok=True)
    for name, selection in [('face_selection.json', face_selection), ('jaw_selection.json', jaw_selection)]:
        selection['geometry_sha256'] = sha(patch/'chr424857.geom')
        (out/name).write_text(json.dumps(selection, indent=2)+'\n')
    shutil.copytree(args.source, args.destination, copy_function=shutil.copy2)
    cameras, actors = [], []
    for stem, count in COUNTS.items():
        actor_name = f'chr424857_{stem}.anim'
        original = read(patch/actor_name, expected_bones=52)
        actor = trim(original, count)
        baked = write(actor, args.destination/'dsts-loader/patch'/actor_name,
                      preserve_duration=False, expected_bones=52)
        if baked._source_frame_count != count:
            raise ValueError('Actor trim failed to set the intended length')
        poses = []
        for f in range(count):
            transforms = [sample(original, bone, f) for bone in range(52)]
            poses.append(fk(skeleton, np.array([t[0] for t in transforms]), np.array([t[1] for t in transforms])))
        forward = poses[-1][0][2]-poses[0][0][2]; forward[1] = 0; forward = normalize(forward)
        actors.append({'path': 'dsts-loader/patch/'+actor_name, 'old_frames': original._source_frame_count,
                       'new_frames': count, 'last_source_frame': count-1,
                       'source_sha256': sha(patch/actor_name), 'modified_sha256': sha(args.destination/'dsts-loader/patch'/actor_name),
                       'fps': baked.playback_rate, 'duration': baked._source_duration,
                       'ending': 'final active tear' if stem == 'bs01' else 'active landing strike'})
        for side in ('pc', 'em'):
            name = f'cam_chr424857_{stem}_{side}.anim'
            old = read(patch/name, expected_bones=2); camera = trim(old, count)
            samples = []; previous = None
            for f, (wp, wq) in enumerate(poses):
                face = skinned_face(face_bindings, face_count, wp, wq)
                jaw = skinned_face(jaw_bindings, jaw_count, wp, wq)
                position, rotation, _ = sample(camera, 0, f)
                fov = float(sample_track(camera.float_channels[0], f))
                weight = jaw_weight(f) if stem == 'bs01' else 0.
                if stem == 'bs01' and f > JAW_START:
                    elevation = max(-.18, .22+.6*min(0., float(qrotate(wq[6], [0., 0., 1.])[1])))
                    fp, fq, _, _ = framed_view(face, -12, elevation, 40.)
                    # A near-frontal side keeps the jaw visible at the strong
                    # final head turn and preserves left-to-right screen travel.
                    jp, jq, _, _ = framed_view(jaw, -7.5, .08, 38., width=.82, height=.68, minimum=1.)
                    position = fp*(1-weight)+jp*weight
                    rotation = slerp(fq, jq, weight)
                    fov = 40.*(1-weight)+38.*weight
                    if previous is not None and np.dot(previous, rotation) < 0: rotation = -rotation
                    camera.positions[0][f] = position.tolist()
                    camera.rotations[0][f] = rotation.tolist()
                    camera.float_channels[0][f] = fov
                previous = rotation
                samples.append({'frame': f, 'face_zoom': zoom_weight(stem, f) if stem == 'bs02' or f <= JAW_START else 1-weight,
                                'jaw_zoom': weight, 'fov': fov,
                                'screen_forward_dot': float(np.dot(forward, qrotate(rotation, [1., 0., 0.]))),
                                'face_bounds': projected_bounds(face, position, rotation, fov),
                                'jaw_bounds': projected_bounds(jaw, position, rotation, fov)})
            rebuilt = write(camera, args.destination/'dsts-loader/patch'/name,
                            preserve_duration=False, expected_bones=2)
            if rebuilt._source_frame_count != count:
                raise ValueError('Camera length does not match the trimmed actor')
            cameras.append({'path': 'dsts-loader/patch/'+name, 'stem': stem, 'side': side,
                            'frames': count, 'samples': samples})
        print(stem, count, 'frames; ends on source frame', count-1, 'without recovery or a held tail', flush=True)
    report = {'revision': 7, 'source_asset_sha256': inventory(args.source),
              'baseline_report_sha256': sha(args.baseline_report), 'actors': actors,
              'face_selection_sha256': sha(out/'face_selection.json'), 'jaw_selection_sha256': sha(out/'jaw_selection.json'),
              'jaw_ending': {'blend_start': JAW_START, 'fully_close': JAW_END, 'last_frame': COUNTS['bs01']-1},
              'cameras': cameras, 'aspect_ratio': 16/9,
              'notes': ['Actor clips contain only the original active prefix; no pose is reauthored or held.',
                        'All four cameras end with their actor; Ground retains a retimed final jaw close-up.',
                        'Left-to-right views, automatic descriptions and native effect references are retained.',
                        'The existing after-animation hit setting now follows the shorter clips.']}
    (out/'cameras.json').write_text(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
