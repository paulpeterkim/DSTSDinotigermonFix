#!/usr/bin/env python3
"""Validate attack-only clip endings and matching V7 cameras.

The actor clips must be exact V6 prefixes, ending in active attack poses rather
than returning to neutral. Camera/jaw framing is checked through an independent
Blender report. These checks do not claim game-engine handoff behavior.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
import traceback

import numpy as np

import anim_codec
from motion_math import fk, normalize, qinv, qrotate
from patch_skills import SKILL_TABLE, GROUND_FANG_ID, HIGHLAND_FANG_ID
from validate_mod import check, inventory, parse_typed_csv, sha256

ROOT = Path(__file__).resolve().parents[1]
COUNTS = {"bs01": 68, "bs02": 48}
ACTORS = {Path(f"dsts-loader/patch/chr424857_{stem}.anim"): stem for stem in COUNTS}
CAMERAS = {Path(f"dsts-loader/patch/cam_chr424857_{stem}_{side}.anim"): stem
           for stem in COUNTS for side in ("pc", "em")}
ALLOWED = {*ACTORS, *CAMERAS}
TOLERANCE = 0.0001


def quat_angles(left, right):
    left, right = np.asarray(left), np.asarray(right)
    dots = np.clip(np.abs(np.sum(left*right, axis=-1)), 0, 1)
    return np.degrees(2*np.arccos(dots))


def prefix_tracks(old, new, count, *, quaternion=False):
    expected = {frame: value for frame, value in old.items() if frame < count}
    check(set(new) == set(expected), "Trimmed track keys differ from the original prefix")
    maximum = 0.
    for frame, value in expected.items():
        a, b = np.asarray(value), np.asarray(new[frame])
        if quaternion and np.dot(a, b) < 0:
            b = -b
        error = float(np.max(np.abs(a-b)))
        check(error <= TOLERANCE, f"Prefix sample changed at frame {frame}: {error}")
        maximum = max(maximum, error)
    return maximum


def metadata(old, new, count, bones):
    check(old.bone_count == new.bone_count == bones, "Animation bone count changed")
    check(new._source_frame_count == count and old._source_frame_count > count,
          "Animation did not end at the selected attack frame")
    check(old.playback_rate == new.playback_rate, "Animation playback rate changed")
    check(math.isclose(new._source_duration, (count-1)/new.playback_rate, rel_tol=0, abs_tol=2e-6),
          "Trimmed duration does not match its last frame")
    check(old.float_channel_count == new.float_channel_count, "Float channel count changed")
    for field in ("unknown_section", "bone_blend_factors", "float_channel_blend_factors"):
        check(np.array_equal(getattr(old, field), getattr(new, field)), f"Animation metadata changed: {field}")
    for kind in ("positions", "rotations", "scales", "float_channels"):
        check(set(getattr(old, kind)) == set(getattr(new, kind)), f"Channel set changed: {kind}")
        for track in getattr(new, kind).values():
            check(all(0 <= frame < count for frame in track), "A key remains after the intended clip end")
    anim_codec.validate(new, expected_bones=bones, expected_frames=count)


def validate_scope(baseline, baseline_report, modified, report):
    accepted = json.loads(baseline_report.read_text())
    check(accepted.get("passed") is True and accepted.get("revision") == 6,
          "V7 needs the accepted V6 baseline")
    before, after = inventory(baseline), inventory(modified)
    hashes = {r.as_posix(): sha256(p) for r, p in sorted(before.items())}
    check(hashes == accepted.get("asset_sha256"), "The V6 baseline inventory changed")
    check(set(before) == set(after) and len(after) == 125, "V7 added or removed game assets")
    changes = []
    for relative in sorted(after):
        digest = sha256(after[relative])
        if digest != hashes[relative.as_posix()]:
            check(relative in ALLOWED, f"Unexpected asset change outside the six clips: {relative}")
            changes.append({"path": relative.as_posix(), "v6_sha256": hashes[relative.as_posix()],
                            "v7_sha256": digest})
    check({row["path"] for row in changes} == {p.as_posix() for p in ALLOWED},
          "Expected exactly two trimmed actors and four matching cameras")
    check(not list((modified/"dsts-loader").glob("patch_text*/text/skill_explanation.mbe/*.csv")),
          "Custom description files were restored")
    _, rows = parse_typed_csv(modified/SKILL_TABLE)
    check({r[0] for r in rows} == {GROUND_FANG_ID, HIGHLAND_FANG_ID} and all(r[5] == "0" for r in rows),
          "Automatic descriptions were not preserved")
    report["baseline_validation_sha256"] = sha256(baseline_report)
    report["file_changes"] = changes
    report["checks"].append({"name": "validated_v6_baseline_and_exact_six_clip_change_scope", "passed": True,
                             "files": 125, "changed": 6, "unchanged": 119,
                             "note": "Geometry, jaw weights, names, automatic descriptions, effects and gameplay data remain byte-identical."})
    return after


def validate_actors(baseline, modified, report):
    skeleton = anim_codec.read_embedded_skeleton(baseline/"dsts-loader/patch/chr424857.geom")
    neutral = anim_codec.read(baseline/"dsts-loader/patch/chr424857_bn01.anim")
    neutral_q = np.asarray([anim_codec.sample(neutral, bone, 0)[1] for bone in range(52)])
    results, actors = [], {}
    for relative, stem in ACTORS.items():
        old, new = anim_codec.read(baseline/relative), anim_codec.read(modified/relative)
        count = COUNTS[stem]
        metadata(old, new, count, 52)
        error = 0.
        for kind in ("positions", "rotations", "scales", "float_channels"):
            for channel, old_track in getattr(old, kind).items():
                error = max(error, prefix_tracks(old_track, getattr(new, kind)[channel], count,
                                                 quaternion=kind == "rotations"))
        sampled = [[anim_codec.sample(new, bone, frame) for bone in range(52)] for frame in range(count)]
        original_samples = [[anim_codec.sample(old, bone, frame) for bone in range(52)] for frame in range(count)]
        sampled_error = 0.
        for original_frame, rebuilt_frame in zip(original_samples, sampled):
            for original_pose, rebuilt_pose in zip(original_frame, rebuilt_frame):
                for index, (a, b) in enumerate(zip(original_pose, rebuilt_pose)):
                    a, b = np.asarray(a), np.asarray(b)
                    if index == 1 and np.dot(a, b) < 0:
                        b = -b
                    sampled_error = max(sampled_error, float(np.max(np.abs(a-b))))
        check(sampled_error <= TOLERANCE, "Actor samples differ from the original retained prefix")
        q = np.asarray([[s[1] for s in frame] for frame in sampled])
        p = np.asarray([[s[0] for s in frame] for frame in sampled])
        end_difference = quat_angles(q[-1], neutral_q)
        end_motion = quat_angles(q[-1], q[-2])
        # The retained final frame must still be an articulated attack with
        # actual motion into it, not a neutral endpoint or appended pose hold.
        check(float(max(end_difference)) >= 15 and float(end_difference[6]) >= 10,
              f"{stem} returns to neutral instead of ending on the attack")
        check(float(max(end_motion)) >= .5 or float(np.max(np.linalg.norm(p[-1]-p[-2], axis=1))) >= .005,
              f"{stem} appends a stationary hold instead of ending with the attack")
        # Explicit endpoint source comparison rules out shortening the header
        # while leaving a different or copied end pose in the exported data.
        old_end_q = np.asarray([anim_codec.sample(old, b, count-1)[1] for b in range(52)])
        check(float(max(quat_angles(q[-1], old_end_q))) < .025,
              "The final actor pose is not the selected original attack frame")
        world_start, _ = fk(skeleton, p[0], q[0]); world_end, _ = fk(skeleton, p[-1], q[-1])
        approach = world_end[2]-world_start[2]; approach[1] = 0
        source_start = [anim_codec.sample(old, b, 0) for b in range(52)]
        source_end = [anim_codec.sample(old, b, count-1) for b in range(52)]
        old_world_start, _ = fk(skeleton, np.asarray([s[0] for s in source_start]), np.asarray([s[1] for s in source_start]))
        old_world_end, _ = fk(skeleton, np.asarray([s[0] for s in source_end]), np.asarray([s[1] for s in source_end]))
        old_approach = old_world_end[2]-old_world_start[2]; old_approach[1] = 0
        check(float(np.linalg.norm(approach-old_approach)) <= .001,
              "The retained attack changed its original close-range approach")
        actors[stem] = new
        results.append({"path": relative.as_posix(), "original_frames": old._source_frame_count,
                        "frames": count, "last_retained_source_frame": count-1,
                        "fps": new.playback_rate, "duration": new._source_duration,
                        "maximum_prefix_component_error": error,
                        "maximum_all_frames_sample_error": sampled_error,
                        "max_endpoint_rotation_from_neutral_degrees": float(max(end_difference)),
                        "head_endpoint_rotation_from_neutral_degrees": float(end_difference[6]),
                        "max_last_frame_joint_step_degrees": float(max(end_motion)),
                        "retained_horizontal_approach": float(np.linalg.norm(approach)),
                        "sha256": sha256(modified/relative)})
    report["actors"] = results
    report["checks"].extend([
        {"name": "actors_are_exact_v6_attack_prefixes_without_recovery_tail", "passed": True, "actors": results},
        {"name": "final_actor_frames_are_non_neutral_and_still_moving", "passed": True,
         "note": "Final poses and adjacent motion are measured from decoded exported clips; no freeze or idle pose was appended."},
    ])
    return actors, skeleton


def validate_cameras(baseline, modified, actors, skeleton, report):
    directions, results = [], []
    forward = {}
    for stem, actor in actors.items():
        poses = []
        for frame in (0, COUNTS[stem]-1):
            transforms = [anim_codec.sample(actor, bone, frame) for bone in range(52)]
            wp, _ = fk(skeleton, np.asarray([s[0] for s in transforms]), np.asarray([s[1] for s in transforms]))
            poses.append(wp)
        vector = poses[1][2]-poses[0][2]; vector[1] = 0; forward[stem] = normalize(vector)
    for relative, stem in CAMERAS.items():
        old, new = anim_codec.read(baseline/relative), anim_codec.read(modified/relative)
        count = COUNTS[stem]
        metadata(old, new, count, 2)
        protected_error = 0.
        for kind in ("positions", "rotations", "scales", "float_channels"):
            for channel, track in getattr(old, kind).items():
                mutable = (kind in ("positions", "rotations") and channel == 0) or (kind == "float_channels" and channel == 0)
                if not mutable:
                    protected_error = max(protected_error, prefix_tracks(track, getattr(new, kind)[channel], count,
                                                                         quaternion=kind == "rotations"))
                elif stem == "bs02":
                    # Highland keeps its current strike framing; only its end
                    # is cut off. Ground's ending is deliberately reframed.
                    protected_error = max(protected_error, prefix_tracks(track, getattr(new, kind)[channel], count,
                                                                         quaternion=kind == "rotations"))
                else:
                    opening = {frame: value for frame, value in getattr(new, kind)[channel].items() if frame <= 52}
                    protected_error = max(protected_error, prefix_tracks(track, opening, 53,
                                                                         quaternion=kind == "rotations"))
        check(set(new.positions[0]) == set(new.rotations[0]) == set(new.float_channels[0]) == set(range(count)),
              "Camera root/FOV keys are missing or sparse")
        samples = [anim_codec.sample(new, 0, f) for f in range(count)]
        positions = np.asarray([s[0] for s in samples]); rotations = np.asarray([s[1] for s in samples])
        fovs = np.asarray([float(anim_codec.sample_track(new.float_channels[0], f)) for f in range(count)])
        check(np.isfinite(positions).all() and np.isfinite(rotations).all() and np.isfinite(fovs).all(), "Nonfinite camera data")
        check(np.all((fovs > 5) & (fovs < 120)), "Camera FOV is invalid")
        steps = np.linalg.norm(np.diff(positions, axis=0), axis=1)
        angles = quat_angles(rotations[1:], rotations[:-1]); lens_steps = np.abs(np.diff(fovs))
        check(float(max(steps)) <= 1.5 and float(max(angles)) <= 30 and float(max(lens_steps)) <= 6,
              f"Camera has an abrupt transition: {relative}")
        projected = [float(np.dot(qrotate(rotations[f], [1., 0., 0.]), forward[stem])) for f in range(9, count)]
        check(min(projected) > .025, f"The attack no longer reads left to right: {relative}")
        directions.append({"path": relative.as_posix(), "minimum_positive_screen_direction": min(projected)})
        check(new._source_frame_count == actors[stem]._source_frame_count and
              math.isclose(new._source_duration, actors[stem]._source_duration, rel_tol=0, abs_tol=2e-6),
              "Actor and camera durations disagree")
        results.append({"path": relative.as_posix(), "frames": count, "duration": new._source_duration,
                        "fps": new.playback_rate, "max_protected_prefix_error": protected_error,
                        "max_position_step": float(max(steps)), "max_rotation_step_degrees": float(max(angles)),
                        "max_fov_step_degrees": float(max(lens_steps)), "sha256": sha256(modified/relative)})
    report["cameras"] = results
    report["checks"].extend([
        {"name": "all_cameras_match_shorter_actors_and_preserve_metadata", "passed": True, "cameras": results},
        {"name": "left_to_right_direction_and_continuous_camera_motion", "passed": True, "cameras": directions},
    ])


def validate_framing(audit_path, modified, report):
    audit = json.loads(audit_path.read_text())
    check(audit.get("passed") is True and audit.get("revision") == 7, "V7 Blender audit did not pass")
    check(audit["projection"]["aspect_ratio"] == "16:9" and audit["projection"]["fov_convention"] == "horizontal",
          "Blender projection convention changed")
    expected = {r.as_posix(): sha256(modified/r) for r in CAMERAS}
    check(audit["camera_sha256"] == expected, "Framing audit references stale camera clips")
    expected_actors = {r.as_posix(): sha256(modified/r) for r in ACTORS}
    check(audit.get("actor_sha256") == expected_actors, "Framing audit references stale actor clips")
    check(audit.get("clip_frame_counts") == COUNTS, "Framing audit uses the wrong shortened clip lengths")
    check(audit["source_geometry_sha256"] == sha256(modified/"dsts-loader/patch/chr424857.geom"),
          "Framing audit references different geometry")
    for field, filename in [("face_selection_sha256", "face_selection.json"), ("jaw_selection_sha256", "jaw_selection.json"),
                            ("camera_diagnostics_sha256", "cameras.json")]:
        check(audit[field] == sha256(audit_path.parent/filename), f"Framing audit references stale {filename}")
        report[field] = audit[field]
    scene = ROOT/"outputs_v3/Dinotigermon_Fang_Attacks_V3.blend"
    if scene.is_file():
        check(audit["source_scene_sha256"] == sha256(scene), "Framing audit uses a different actor scene")
    check(set(audit["cameras"]) == set(expected), "Audit camera inventory differs")
    summaries = []
    for relative, record in audit["cameras"].items():
        stem, count = CAMERAS[Path(relative)], COUNTS[CAMERAS[Path(relative)]]
        rows = record["frames"]
        check(len(rows) == count and [r["frame"] for r in rows] == list(range(count)), "Framing audit has missing frames")
        face_frames, jaw_frames = set(record["full_face_frames"]), set(record["jaw_end_frames"])
        expected_face = set(range(42, 53)) if stem == "bs01" else set(range(41, count))
        check(face_frames == expected_face, "Face framing phase differs from the retained strike window")
        if stem == "bs01":
            check(jaw_frames == set(range(count-3, count)),
                  "Ground's final three attack frames are not the audited jaw ending")
        else:
            check(not jaw_frames, "Highland has an unexpected jaw ending phase")
        for region, phase, minimum in [("face", face_frames, .55), ("jaw", jaw_frames, .45)]:
            for row in rows:
                value = row[region]
                check(math.isfinite(value["min_depth"]) and value["min_depth"] > .05,
                      "Framing geometry intersects the camera near plane")
                if row["frame"] not in phase:
                    continue
                lo, hi = np.asarray(value["bbox_ndc"]["min"]), np.asarray(value["bbox_ndc"]["max"])
                check(lo.shape == hi.shape == (2,) and np.isfinite(lo).all() and np.isfinite(hi).all(), "Invalid audit bounds")
                check(np.all(lo >= .02) and np.all(hi <= .98) and minimum <= value["height_fraction"] <= .96,
                      f"Actual {region} is too small or cropped: {relative}, frame {row['frame']}")
        check(not record.get("near_plane_failure_frames"), "Framing audit reports near-plane failures")
        summaries.append({"path": relative, "face_frames": sorted(face_frames), "jaw_ending_frames": sorted(jaw_frames),
                          "face": record.get("face_summary"), "ending_jaw": record.get("jaw_summary")})
    report["framing_audit_sha256"] = sha256(audit_path)
    report["checks"].append({"name": "independent_blender_face_and_active_jaw_ending_framing", "passed": True,
                             "cameras": summaries,
                             "note": "Actual mesh projection verifies the shortened-camera ending; engine handoff still needs a game test."})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=ROOT/"modified_v6")
    parser.add_argument("--modified", type=Path, default=ROOT/"modified_v7")
    parser.add_argument("--baseline-report", type=Path, default=ROOT/"outputs_v6/validation.json")
    parser.add_argument("--framing-audit", type=Path, default=ROOT/"work/v7/camera_framing_audit.json")
    parser.add_argument("--report", type=Path, default=ROOT/"outputs_v7/validation.json")
    parser.add_argument("--ground-end-frame", type=int, default=67)
    parser.add_argument("--highland-end-frame", type=int, default=47)
    args = parser.parse_args()
    COUNTS.update(bs01=args.ground_end_frame+1, bs02=args.highland_end_frame+1)
    report = {"revision": 7, "passed": False, "checks": [], "baseline": str(args.baseline.resolve()),
              "modified": str(args.modified.resolve()), "retained_source_frames": {stem: [0, count-1] for stem, count in COUNTS.items()}}
    try:
        files = validate_scope(args.baseline, args.baseline_report, args.modified, report)
        actors, skeleton = validate_actors(args.baseline, args.modified, report)
        validate_cameras(args.baseline, args.modified, actors, skeleton, report)
        if args.framing_audit.is_file():
            validate_framing(args.framing_audit, args.modified, report)
        report["asset_sha256"] = {r.as_posix(): sha256(p) for r, p in sorted(files.items())}
        report["passed"] = True
    except Exception as error:
        report["error"] = str(error); report["traceback"] = traceback.format_exc()
    report["limits"] = ["The shorter ending advances the unchanged after-animation game hit event; runtime reaction/handoff behavior remains untested.",
                        "No idle recovery or ending hold was appended to the actor clips; native particle assets themselves are unchanged."]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(f"{'PASS' if report['passed'] else 'FAIL'}: {len(report['checks'])} checks; report: {args.report}")
    if not report["passed"]:
        print(report["error"], file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
