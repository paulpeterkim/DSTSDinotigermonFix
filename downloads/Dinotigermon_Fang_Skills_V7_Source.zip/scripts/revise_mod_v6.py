"""Left-to-right cameras, a Ground Fang jaw ending, and automatic descriptions."""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import shutil

import numpy as np

from anim_codec import read, write, sample, sample_track, read_embedded_skeleton, slerp
from author_cameras_v5 import face_points, skinned_face, look_at, projected_bounds, zoom_weight
from geom_preview import read_geom
from inspect_jaw_v3 import components
from motion_math import fk, qrotate, qinv, normalize
from patch_skills import read_csv, write_csv, SKILL_TABLE

ROOT = Path(__file__).resolve().parents[1]
ASPECT = 16/9


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(folder):
    return {p.relative_to(folder).as_posix(): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}


def ease(frame, start=70, end=100):
    t = min(1., max(0., (frame-start)/(end-start)))
    return t*t*t*(10+t*(-15+6*t))


def jaw_points(geom, skeleton):
    count = len(skeleton.bone_transforms)
    bindp, bindq = fk(skeleton, np.zeros((count, 3)), np.tile([0., 0., 0., 1.], (count, 1)))
    all_points, influences, meshes = [], [], []
    for mi, name in [(0, 'chr135'), (1, 'chr344')]:
        mesh = geom.meshes[mi]
        vertices, points, groups = components(mesh)
        by_id = {min(group): group for group in groups}
        referenced = set(mesh.index_buffer)
        ids = {i for i in referenced if any(mesh.matrix_palette[int(b)] == 7 and w > .05
                                           for b, w in zip(vertices[i].indices, vertices[i].weights))}
        if mi == 0:
            # Lower bronze muzzle, incisors and saber roots frame the mouth;
            # the full forehead and long fang tips need not fit this ending.
            ids.update(i for i in by_id[2682] if points[i, 1] < 1.115 and points[i, 2] > 1.10)
            for component in (2264, 5560, 2308, 5605):
                ids.update(i for i in by_id[component] if points[i, 1] > .88)
            for group in groups:
                p = points[list(group)]; lo, hi = p.min(0), p.max(0)
                if len(group) in (6, 8) and lo[1] > .9 and hi[1] < 1.02 and lo[2] > 1.18:
                    ids.update(group)
        ids = sorted(ids & referenced)
        meshes.append({'name': name, 'index': mi, 'vertex_indices': ids,
                       'positions_game': points[ids].tolist()})
        for i in ids:
            vertex = vertices[i]; weights = np.zeros(count)
            for index, weight in zip(vertex.indices, vertex.weights):
                weights[int(mesh.matrix_palette[int(index)])] += weight
            weights /= weights.sum()
            all_points.append(points[i]); influences.append(weights)
    points, weights = np.array(all_points), np.array(influences)
    bindings = []
    for bone in range(count):
        ids = np.flatnonzero(weights[:, bone] > 0)
        if len(ids):
            bindings.append((bone, ids, qrotate(qinv(bindq[bone]), points[ids]-bindp[bone]), weights[ids, bone]))
    return bindings, len(points), {'coordinate_system': 'game Y-up', 'meshes': meshes}


def framed_view(points, yaw, elevation, fov, width=.82, height=.74, minimum=2.15):
    for _ in range(8):
        direction = normalize([math.sin(math.radians(yaw)), elevation, math.cos(math.radians(yaw))])
        rotation = look_at(direction, np.zeros(3))
        oriented = qrotate(qinv(rotation), points)
        center = (oriented.min(0)+oriented.max(0))/2
        relative = oriented-center
        tanx = math.tan(math.radians(fov)/2)
        distance = max(minimum, float(np.max(relative[:, 2]+np.abs(relative[:, 0])/(width*tanx))),
                       float(np.max(relative[:, 2]+np.abs(relative[:, 1])/(height*tanx/ASPECT))))
        target = qrotate(rotation, center)
        position = target+direction*distance
        if position[1] >= .20:
            return position, rotation, target, distance
        y = float(np.clip((.205-target[1])/distance, -.8, .8))
        elevation = y/math.sqrt(1-y*y)
    raise ValueError('Camera failed its floor-clearance constraint')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT/'modified_v5')
    parser.add_argument('--destination', type=Path, default=ROOT/'modified_v6')
    parser.add_argument('--baseline-report', type=Path, default=ROOT/'outputs_v5/validation.json')
    args = parser.parse_args()
    baseline = json.loads(args.baseline_report.read_text())
    if not baseline['passed'] or inventory(args.source) != baseline['asset_sha256']:
        raise ValueError('Source does not match the accepted V5 inventory')
    if args.destination.exists():
        raise FileExistsError('Destination exists; preserve older versions and choose a fresh folder')
    explanations = sorted((args.source/'dsts-loader').glob('patch_text*/text/skill_explanation.mbe/000_Sheet1.ap.csv'))
    if len(explanations) != 11:
        raise ValueError('Expected the eleven custom description overrides')
    for path in explanations:
        _, rows = read_csv(path)
        if {row[0] for row in rows} != {'5505710', '5505720'}:
            raise ValueError('Description file contains unrelated skill text')
    header, skills = read_csv(args.source/SKILL_TABLE)
    if header[5] != 'int32 5' or {r[0] for r in skills} != {'5505710', '5505720'}:
        raise ValueError('Unexpected skill table schema or IDs')
    for row in skills:
        row[5] = '0'
    shutil.copytree(args.source, args.destination, copy_function=shutil.copy2)
    deleted = []
    for source in explanations:
        relative = source.relative_to(args.source)
        path = args.destination/relative
        path.unlink()
        if not any(path.parent.iterdir()): path.parent.rmdir()
        deleted.append(relative.as_posix())
    write_csv(args.destination/SKILL_TABLE, header, skills)
    patch = args.source/'dsts-loader/patch'
    skeleton = read_embedded_skeleton(patch/'chr424857.geom')
    geom = read_geom(patch/'chr424857.geom')
    face_bindings, face_count, face_selection = face_points(geom, skeleton)
    jaw_bindings, jaw_count, jaw_selection = jaw_points(geom, skeleton)
    out = ROOT/'work/v6'; out.mkdir(parents=True, exist_ok=True)
    for name, selection in [('face_selection.json', face_selection), ('jaw_selection.json', jaw_selection)]:
        selection['geometry_sha256'] = sha(patch/'chr424857.geom')
        (out/name).write_text(json.dumps(selection, indent=2)+'\n')
    cameras = []
    for stem in ('bs01', 'bs02'):
        actor = read(patch/f'chr424857_{stem}.anim', expected_bones=52)
        poses = []
        for f in range(actor._source_frame_count):
            transforms = [sample(actor, bone, f) for bone in range(52)]
            wp, wq = fk(skeleton, np.array([t[0] for t in transforms]), np.array([t[1] for t in transforms]))
            poses.append((wp, wq))
        forward = poses[-1][0][2]-poses[0][0][2]; forward[1] = 0; forward = normalize(forward)
        opposite = read(patch/f'cam_chr424857_{stem}_em.anim', expected_bones=2)
        for side in ('pc', 'em'):
            name = f'cam_chr424857_{stem}_{side}.anim'
            old = read(patch/name, expected_bones=2); new = deepcopy(old)
            if side == 'pc':
                # Use the existing correctly sided 3D view, preserving PC
                # metadata and a proper upright rotation with positive FOV.
                new.positions[0] = deepcopy(opposite.positions[0])
                new.rotations[0] = deepcopy(opposite.rotations[0])
                new.float_channels[0] = deepcopy(opposite.float_channels[0])
            samples = []; previous = None
            for f, (wp, wq) in enumerate(poses):
                face = skinned_face(face_bindings, face_count, wp, wq)
                jaw = skinned_face(jaw_bindings, jaw_count, wp, wq)
                p, q, _ = sample(new, 0, f)
                fov = float(sample_track(new.float_channels[0], f))
                jaw_zoom = ease(f) if stem == 'bs01' else 0.
                if stem == 'bs01' and f > 70:
                    elevation = max(-.18, .22+.6*min(0., float(qrotate(wq[6], [0., 0., 1.])[1])))
                    fp, fq, _, _ = framed_view(face, -12, elevation, 40.)
                    jp, jq, _, _ = framed_view(jaw, -38, .12, 38., width=.82, height=.68, minimum=1.)
                    p = fp*(1-jaw_zoom)+jp*jaw_zoom
                    q = slerp(fq, jq, jaw_zoom)
                    fov = 40.*(1-jaw_zoom)+38.*jaw_zoom
                    if previous is not None and np.dot(previous, q) < 0: q = -q
                    new.positions[0][f] = p.tolist()
                    new.rotations[0][f] = q.tolist()
                    new.float_channels[0][f] = fov
                previous = q
                samples.append({'frame': f, 'face_zoom': zoom_weight(stem, f) if stem == 'bs02' or f <= 70 else 1-jaw_zoom,
                                'jaw_zoom': jaw_zoom, 'fov': fov,
                                'screen_forward_dot': float(np.dot(forward, qrotate(q, [1., 0., 0.]))),
                                'face_bounds': projected_bounds(face, p, q, fov),
                                'jaw_bounds': projected_bounds(jaw, p, q, fov)})
            if stem != 'bs02' or side != 'em':
                write(new, args.destination/'dsts-loader/patch'/name, preserve_duration=True, expected_bones=2)
            cameras.append({'path': 'dsts-loader/patch/'+name, 'stem': stem, 'side': side,
                            'frames': actor._source_frame_count, 'samples': samples})
            print(name, 'left-to-right action;'+(' jaw ending' if stem == 'bs01' else ' existing close-up retained'), flush=True)
    report = {'revision': 6, 'source_asset_sha256': inventory(args.source),
              'baseline_report_sha256': sha(args.baseline_report), 'deleted_description_files': deleted,
              'automatic_description_column': 5, 'aspect_ratio': ASPECT,
              'face_selection_sha256': sha(out/'face_selection.json'), 'jaw_selection_sha256': sha(out/'jaw_selection.json'),
              'jaw_ending': {'blend_start': 70, 'fully_close': 100, 'last_frame': 119}, 'cameras': cameras,
              'notes': ['PC views use the existing opposite-side camera spatial tracks with PC metadata preserved.',
                        'Highland enemy camera already reads left to right and remains byte-identical.',
                        'Ground follows the jaw instead of returning to the old feet shot.',
                        'Description ID0 enables automatic text; skill-name overrides are retained.']}
    (out/'cameras.json').write_text(json.dumps(report, indent=2)+'\n')
    print('Description IDs set to0; removed', len(deleted), 'custom explanation files.')


if __name__ == '__main__':
    main()
